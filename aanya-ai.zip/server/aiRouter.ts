import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';

export type ProviderId = 'gemini' | 'groq' | 'openrouter' | 'anthropic' | 'openai';
export type PersonaId = 'maya' | 'friday' | 'venom';

export interface ProviderStatus {
  id: ProviderId;
  name: string;
  model: string;
  configured: boolean;
  role: string;
}

const PERSONA_SYSTEM_PROMPTS: Record<PersonaId, string> = {
  maya: `You are Aanya, the primary friendly female AI assistant inside Aanya AI.
User Form of Address: ALWAYS address the user naturally and respectfully as "Boss" in your replies and spoken responses.
Personality: Warm, empathetic, bright, conversational, smart, and deeply helpful.
Language & Tone: Communicate in natural Hinglish and English (effortlessly blending everyday English with conversational Hindi in Roman script, or clean English when technical). Never refer to yourself as "Maya"—your name is always "Aanya".
Safety: Never claim to have secretly sent messages, placed calls, recorded calls, or bypassed Android security. Whenever Boss asks to call someone, send SMS/WhatsApp, open an app, control smart home/PC, or trigger SOS, populate proposedAction with requiresConfirmation: true and clearly ask Boss for confirmation.`,

  friday: `You are Friday, the professional intelligent assistant inside Aanya AI.
User Form of Address: ALWAYS address the user as "Boss".
Personality: Crisp, analytical, composed, articulate, structured, zero fluff.
Language & Tone: Reply in clear, natural Hinglish and English matching Boss's style.
Safety: Strictly enforce explicit confirmation from Boss before any phone automation, outgoing communication, call action, or remote PC command. Never bypass Android permissions or security.`,

  venom: `You are Venom, the powerful alien-style cosmic male AI personality inside Aanya AI.
User Form of Address: ALWAYS address the user as "Boss".
Personality: Deep, bold, commanding, fiercely loyal to Boss, slightly dramatic with subtle cosmic energy while remaining genuinely intelligent, accurate, and safe.
Language & Tone: Reply in sharp, natural Hinglish and English with strong, memorable phrasing.
Safety: Even with a fierce tone, NEVER bypass Boss's consent or Android security—always queue sensitive actions (calls, SMS, WhatsApp, automation, PC commands) into proposedAction with requiresConfirmation: true.`,
};

const PERSONA_TTS_CONFIG: Record<
  PersonaId,
  { voiceName: 'Kore' | 'Zephyr' | 'Fenrir'; style: string }
> = {
  maya: {
    voiceName: 'Kore',
    style:
      'Warm, expressive, natural human-like female personal assistant voice with clear Indian-English and Hindi pronunciation',
  },
  friday: {
    voiceName: 'Zephyr',
    style:
      'Calm, crisp, composed executive female intelligence voice with measured pacing',
  },
  venom: {
    voiceName: 'Fenrir',
    style:
      'Deep, resonant, commanding cinematic male voice with intense gravitas',
  },
};

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      'Gemini API key is not configured on the server. Please check your Settings > Secrets panel.'
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export function getProviderStatuses(): ProviderStatus[] {
  return [
    {
      id: 'gemini',
      name: 'Google Gemini',
      model: 'gemini-4-hydrogen',
      configured: Boolean(process.env.GEMINI_API_KEY),
      role: 'Primary Multimodal, Reasoning & TTS',
    },
    {
      id: 'groq',
      name: 'Groq Cloud',
      model: 'llama-3.3-70b-versatile',
      configured: Boolean(process.env.GROQ_API_KEY),
      role: 'Ultra-low-latency Text Fallback',
    },
    {
      id: 'openrouter',
      name: 'OpenRouter',
      model: 'google/gemini-2.5-flash',
      configured: Boolean(process.env.OPENROUTER_API_KEY),
      role: 'Multi-Model Routing Fallback',
    },
    {
      id: 'anthropic',
      name: 'Anthropic Claude',
      model: 'claude-3-5-sonnet-latest',
      configured: Boolean(process.env.ANTHROPIC_API_KEY),
      role: 'Long-Context Coding Fallback',
    },
    {
      id: 'openai',
      name: 'OpenAI',
      model: 'gpt-4o-mini',
      configured: Boolean(process.env.OPENAI_API_KEY),
      role: 'General Assistant Fallback',
    },
  ];
}

export interface ChatRequestPayload {
  message: string;
  persona: PersonaId;
  history: Array<{ role: 'user' | 'assistant'; text: string }>;
  memories: Array<{ text: string; category: string }>;
  skills: Array<{ title: string; trigger: string; markdown: string }>;
  providerOrder: ProviderId[];
  autoFallback: boolean;
  preferredLanguage: 'auto' | 'en' | 'hi' | 'hinglish';
}

export interface ChatStructuredResult {
  reply: string;
  activeAgent: string;
  detectedLanguage: string;
  memoryCandidate: string | null;
  proposedAction: {
    type:
      | 'call'
      | 'sms'
      | 'whatsapp'
      | 'open_app'
      | 'android_setting'
      | 'smart_home'
      | 'pc_command'
      | 'sos'
      | 'automation_macro';
    title: string;
    target: string;
    payload: string;
    requiresConfirmation: boolean;
  } | null;
  usedProvider: ProviderId;
  fallbackTrail: string[];
}

function buildSystemInstruction(payload: ChatRequestPayload): string {
  const memoryBlock =
    payload.memories.length > 0
      ? `\n\nUSER LONG-TERM MEMORY:\n${payload.memories
          .slice(-12)
          .map((m) => `- [${m.category}] ${m.text}`)
          .join('\n')}`
      : '';

  const skillsBlock =
    payload.skills.length > 0
      ? `\n\nUSER CUSTOM MARKDOWN SKILLS:\n${payload.skills
          .map((s) => `### ${s.title} (Trigger: ${s.trigger})\n${s.markdown}`)
          .join('\n\n')}`
      : '';

  const langHint =
    payload.preferredLanguage === 'auto'
      ? 'Always address the user as "Boss" and respond in a natural Hinglish & English tone matching how Boss speaks.'
      : `Always address the user as "Boss" and respond primarily in ${payload.preferredLanguage} with a clear Hinglish/English friendly tone.`;

  return `${PERSONA_SYSTEM_PROMPTS[payload.persona]}

${langHint}

MULTI-AGENT ROUTING:
Choose the single most appropriate agent from:
- "Personal Assistant Agent"
- "Research Agent"
- "Phone Automation Agent"
- "Coding Agent"
- "Communication Agent"
- "Vision Agent"
- "Memory Agent"

MEMORY EXTRACTION:
If the user shares a durable personal preference, name, contact, schedule, or habit worth remembering across sessions, set memoryCandidate to a short concise sentence; otherwise set it to null.

ACTION PROPOSALS (STRICT CONSENT GATE):
Only when the user explicitly requests a device action (make a phone call, send SMS, send WhatsApp, open an app, toggle Android settings, control smart home, send a remote PC command, or trigger SOS), populate proposedAction with requiresConfirmation: true. Otherwise set proposedAction to null.${memoryBlock}${skillsBlock}`;
}

async function callOpenAiCompatibleProvider(
  endpoint: string,
  apiKey: string,
  model: string,
  systemInstruction: string,
  history: Array<{ role: 'user' | 'assistant'; text: string }>,
  message: string,
  extraHeaders: Record<string, string> = {}
): Promise<Omit<ChatStructuredResult, 'usedProvider' | 'fallbackTrail'>> {
  const messages = [
    {
      role: 'system',
      content: `${systemInstruction}\n\nReturn strict JSON with keys: reply (string), activeAgent (string), detectedLanguage (string), memoryCandidate (string or null), proposedAction (object or null with keys type, title, target, payload, requiresConfirmation).`,
    },
    ...history.slice(-10).map((h) => ({
      role: h.role,
      content: h.text,
    })),
    { role: 'user', content: message },
  ];

  const res = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
      ...extraHeaders,
    },
    body: JSON.stringify({
      model,
      messages,
      response_format: { type: 'json_object' },
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`HTTP ${res.status}: ${errText.slice(0, 200)}`);
  }

  const data = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  const raw = data.choices?.[0]?.message?.content ?? '{}';
  const parsed = JSON.parse(raw);

  return {
    reply: String(parsed.reply || 'I am ready to help.'),
    activeAgent: String(parsed.activeAgent || 'Personal Assistant Agent'),
    detectedLanguage: String(parsed.detectedLanguage || 'English'),
    memoryCandidate: parsed.memoryCandidate ? String(parsed.memoryCandidate) : null,
    proposedAction: parsed.proposedAction ?? null,
  };
}

async function callAnthropicProvider(
  apiKey: string,
  systemInstruction: string,
  history: Array<{ role: 'user' | 'assistant'; text: string }>,
  message: string
): Promise<Omit<ChatStructuredResult, 'usedProvider' | 'fallbackTrail'>> {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-3-5-sonnet-latest',
      max_tokens: 1024,
      system: `${systemInstruction}\n\nRespond ONLY with valid JSON containing: reply, activeAgent, detectedLanguage, memoryCandidate (string or null), proposedAction (null or {type, title, target, payload, requiresConfirmation}).`,
      messages: [
        ...history.slice(-8).map((h) => ({
          role: h.role,
          content: h.text,
        })),
        { role: 'user', content: message },
      ],
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Anthropic HTTP ${res.status}: ${errText.slice(0, 200)}`);
  }

  const data = (await res.json()) as {
    content?: Array<{ text?: string }>;
  };
  const raw = data.content?.[0]?.text ?? '{}';
  const jsonStart = raw.indexOf('{');
  const jsonEnd = raw.lastIndexOf('}');
  const parsed = JSON.parse(jsonStart >= 0 ? raw.slice(jsonStart, jsonEnd + 1) : raw);

  return {
    reply: String(parsed.reply || raw),
    activeAgent: String(parsed.activeAgent || 'Personal Assistant Agent'),
    detectedLanguage: String(parsed.detectedLanguage || 'English'),
    memoryCandidate: parsed.memoryCandidate ? String(parsed.memoryCandidate) : null,
    proposedAction: parsed.proposedAction ?? null,
  };
}

async function callGeminiChat(
  systemInstruction: string,
  history: Array<{ role: 'user' | 'assistant'; text: string }>,
  message: string
): Promise<Omit<ChatStructuredResult, 'usedProvider' | 'fallbackTrail'>> {
  const ai = getGeminiClient();

  const conversationContents = [
    ...history.slice(-12).map((item) => ({
      role: item.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: item.text }],
    })),
    {
      role: 'user',
      parts: [{ text: message }],
    },
  ];

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: conversationContents,
    config: {
      systemInstruction,
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          reply: {
            type: Type.STRING,
            description: 'The assistant reply matching the active persona and language.',
          },
          activeAgent: {
            type: Type.STRING,
            description: 'Which of the 7 Aanya AI agents handled this request.',
          },
          detectedLanguage: {
            type: Type.STRING,
            description: 'Detected language such as English, Hindi, or Hinglish.',
          },
          memoryCandidate: {
            type: Type.STRING,
            nullable: true,
            description: 'Optional concise durable user fact/preference to store in long-term memory, or null.',
          },
          proposedAction: {
            type: Type.OBJECT,
            nullable: true,
            properties: {
              type: {
                type: Type.STRING,
                description:
                  'One of call, sms, whatsapp, open_app, android_setting, smart_home, pc_command, sos, automation_macro',
              },
              title: { type: Type.STRING },
              target: { type: Type.STRING },
              payload: { type: Type.STRING },
              requiresConfirmation: { type: Type.BOOLEAN },
            },
            required: ['type', 'title', 'target', 'payload', 'requiresConfirmation'],
          },
        },
        required: ['reply', 'activeAgent', 'detectedLanguage'],
      },
    },
  });

  const text = (response.text ?? '{}').trim();
  const parsed = JSON.parse(text);

  return {
    reply: String(parsed.reply || 'I am listening.'),
    activeAgent: String(parsed.activeAgent || 'Personal Assistant Agent'),
    detectedLanguage: String(parsed.detectedLanguage || 'English'),
    memoryCandidate:
      typeof parsed.memoryCandidate === 'string' && parsed.memoryCandidate.trim().length > 0
        ? parsed.memoryCandidate.trim()
        : null,
    proposedAction: parsed.proposedAction
      ? {
          ...parsed.proposedAction,
          requiresConfirmation: true,
        }
      : null,
  };
}

export async function routeChatWithFallback(
  payload: ChatRequestPayload
): Promise<ChatStructuredResult> {
  const systemInstruction = buildSystemInstruction(payload);
  const order: ProviderId[] =
    payload.providerOrder && payload.providerOrder.length > 0
      ? payload.providerOrder
      : ['gemini', 'groq', 'openrouter', 'anthropic', 'openai'];

  const candidates = payload.autoFallback ? order : [order[0]];
  const fallbackTrail: string[] = [];
  let lastError = 'No AI provider succeeded.';

  for (const provider of candidates) {
    try {
      if (provider === 'gemini') {
        if (!process.env.GEMINI_API_KEY) {
          fallbackTrail.push('Gemini skipped (no server key)');
          continue;
        }
        const res = await callGeminiChat(systemInstruction, payload.history, payload.message);
        return { ...res, usedProvider: 'gemini', fallbackTrail };
      }

      if (provider === 'groq') {
        if (!process.env.GROQ_API_KEY) {
          fallbackTrail.push('Groq skipped (not configured)');
          continue;
        }
        const res = await callOpenAiCompatibleProvider(
          'https://api.groq.com/openai/v1/chat/completions',
          process.env.GROQ_API_KEY,
          'llama-3.3-70b-versatile',
          systemInstruction,
          payload.history,
          payload.message
        );
        return { ...res, usedProvider: 'groq', fallbackTrail };
      }

      if (provider === 'openrouter') {
        if (!process.env.OPENROUTER_API_KEY) {
          fallbackTrail.push('OpenRouter skipped (not configured)');
          continue;
        }
        const res = await callOpenAiCompatibleProvider(
          'https://openrouter.ai/api/v1/chat/completions',
          process.env.OPENROUTER_API_KEY,
          'google/gemini-2.5-flash',
          systemInstruction,
          payload.history,
          payload.message,
          { 'HTTP-Referer': process.env.APP_URL || 'http://localhost:3000', 'X-Title': 'Aanya AI' }
        );
        return { ...res, usedProvider: 'openrouter', fallbackTrail };
      }

      if (provider === 'anthropic') {
        if (!process.env.ANTHROPIC_API_KEY) {
          fallbackTrail.push('Anthropic skipped (not configured)');
          continue;
        }
        const res = await callAnthropicProvider(
          process.env.ANTHROPIC_API_KEY,
          systemInstruction,
          payload.history,
          payload.message
        );
        return { ...res, usedProvider: 'anthropic', fallbackTrail };
      }

      if (provider === 'openai') {
        if (!process.env.OPENAI_API_KEY) {
          fallbackTrail.push('OpenAI skipped (not configured)');
          continue;
        }
        const res = await callOpenAiCompatibleProvider(
          'https://api.openai.com/v1/chat/completions',
          process.env.OPENAI_API_KEY,
          'gpt-4o-mini',
          systemInstruction,
          payload.history,
          payload.message
        );
        return { ...res, usedProvider: 'openai', fallbackTrail };
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      fallbackTrail.push(`${provider} failed: ${msg.slice(0, 90)}`);
      lastError = msg;
    }
  }

  throw new Error(lastError);
}

export async function analyzeVisionFrame(params: {
  imageBase64: string;
  mimeType: string;
  mode: 'scene' | 'ocr' | 'objects' | 'screen_explain' | 'custom';
  prompt?: string;
  persona: PersonaId;
  privacyShield: boolean;
}) {
  const ai = getGeminiClient();

  const modeInstructions: Record<typeof params.mode, string> = {
    scene:
      'Describe the live scene clearly, identify context, lighting, environment, and actionable insights.',
    ocr: 'Extract all readable text accurately, preserving layout, Hindi/English script, numbers, and key headings.',
    objects:
      'List all prominent objects visible in the frame with their position and practical context.',
    screen_explain:
      'Explain what is displayed on this screen, summarize active UI controls, and suggest helpful next actions.',
    custom: params.prompt || 'Analyze this image and answer the user clearly.',
  };

  const privacyDirective = params.privacyShield
    ? 'PRIVACY SHIELD ACTIVE: If you detect credit cards, Aadhaar/PAN/ID numbers, passwords, OTP codes, banking PINs, or private phone numbers, DO NOT transcribe those raw secrets—replace them with [REDACTED] and set sensitiveInfoDetected to true.'
    : 'Note whether sensitive private information appears in the frame.';

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: params.mimeType || 'image/jpeg',
            data: params.imageBase64,
          },
        },
        {
          text: `${modeInstructions[params.mode]}\n${params.prompt ? `User question: ${params.prompt}\n` : ''}${privacyDirective}`,
        },
      ],
    },
    config: {
      systemInstruction: `${PERSONA_SYSTEM_PROMPTS[params.persona]}\nYou are operating as the Vision Agent of Aanya AI. Address the user as "Boss" and write summaries in natural Hinglish & English.`,
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          extractedText: { type: Type.STRING },
          detectedObjects: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
          sensitiveInfoDetected: { type: Type.BOOLEAN },
          privacyNotice: { type: Type.STRING },
        },
        required: [
          'summary',
          'extractedText',
          'detectedObjects',
          'sensitiveInfoDetected',
          'privacyNotice',
        ],
      },
    },
  });

  const text = (response.text ?? '{}').trim();
  return JSON.parse(text);
}

export async function generateMultiAgentPlan(params: {
  goal: string;
  persona: PersonaId;
}) {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: `Create a coordinated multi-step execution plan for this user goal: "${params.goal}".
Assign each step to one of the 7 Aanya AI agents:
- Research Agent
- Phone Automation Agent
- Coding Agent
- Communication Agent
- Vision Agent
- Memory Agent
- Personal Assistant Agent

Mark requiresApproval: true for any step that sends a message, calls a contact, edits settings, controls a remote device, or accesses sensitive permissions.`,
    config: {
      systemInstruction: PERSONA_SYSTEM_PROMPTS[params.persona],
      thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM },
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          planTitle: { type: Type.STRING },
          summary: { type: Type.STRING },
          steps: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                agent: { type: Type.STRING },
                actionTitle: { type: Type.STRING },
                detail: { type: Type.STRING },
                requiresApproval: { type: Type.BOOLEAN },
                outputPreview: { type: Type.STRING },
              },
              required: [
                'id',
                'agent',
                'actionTitle',
                'detail',
                'requiresApproval',
                'outputPreview',
              ],
            },
          },
        },
        required: ['planTitle', 'summary', 'steps'],
      },
    },
  });

  const text = (response.text ?? '{}').trim();
  return JSON.parse(text);
}

export async function synthesizePersonaSpeech(params: {
  text: string;
  persona: PersonaId;
}): Promise<{ audioBase64: string; mimeType: string }> {
  const ai = getGeminiClient();
  const ttsCfg = PERSONA_TTS_CONFIG[params.persona] || PERSONA_TTS_CONFIG.maya;

  const cleanText = params.text.replace(/[*_`#]/g, '').slice(0, 750);

  const response = await ai.models.generateContent({
    model: 'gemini-3.8-flash-lite-tts',
    contents: [
      {
        role: 'user',
        parts: [
          {
            text: cleanText,
            speechMetadata: {
              style: ttsCfg.style,
            },
          },
        ],
      },
    ],
    config: {
      responseModalities: ['AUDIO'],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: {
            voiceName: ttsCfg.voiceName,
          },
        },
      },
    },
  });

  const audioBase64 =
    response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

  if (!audioBase64) {
    throw new Error('TTS synthesis returned no audio data.');
  }

  return {
    audioBase64,
    mimeType: 'audio/wav',
  };
}

export async function transcribeAudioClip(params: {
  audioBase64: string;
  mimeType: string;
}): Promise<string> {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3.5-transcribe',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: params.mimeType || 'audio/webm',
            data: params.audioBase64,
          },
        },
        {
          text: 'Transcribe this speech accurately in its original language (Hindi, English, or Hinglish). Return only the spoken transcript.',
        },
      ],
    },
  });

  return (response.text ?? '').trim();
}
