import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  analyzeVisionFrame,
  generateMultiAgentPlan,
  getProviderStatuses,
  routeChatWithFallback,
  synthesizePersonaSpeech,
  transcribeAudioClip,
  type ChatRequestPayload,
  type PersonaId,
} from './server/aiRouter.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '15mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, app: 'Aanya AI', package: 'com.aanya.ai' });
  });

  app.get('/api/providers', (_req, res) => {
    res.json({ providers: getProviderStatuses() });
  });

  app.post('/api/chat', async (req, res) => {
    try {
      const payload = req.body as ChatRequestPayload;
      if (!payload?.message || typeof payload.message !== 'string') {
        res.status(400).json({ error: 'Message text is required.' });
        return;
      }
      const result = await routeChatWithFallback({
        message: payload.message,
        persona: payload.persona || 'maya',
        history: Array.isArray(payload.history) ? payload.history : [],
        memories: Array.isArray(payload.memories) ? payload.memories : [],
        skills: Array.isArray(payload.skills) ? payload.skills : [],
        providerOrder: Array.isArray(payload.providerOrder)
          ? payload.providerOrder
          : ['gemini', 'groq', 'openrouter', 'anthropic', 'openai'],
        autoFallback: payload.autoFallback !== false,
        preferredLanguage: payload.preferredLanguage || 'auto',
      });
      res.json(result);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Chat generation failed.';
      res.status(500).json({ error: message });
    }
  });

  app.post('/api/vision', async (req, res) => {
    try {
      const { imageBase64, mimeType, mode, prompt, persona, privacyShield } = req.body as {
        imageBase64?: string;
        mimeType?: string;
        mode?: 'scene' | 'ocr' | 'objects' | 'screen_explain' | 'custom';
        prompt?: string;
        persona?: PersonaId;
        privacyShield?: boolean;
      };

      if (!imageBase64) {
        res.status(400).json({ error: 'Captured image data is required.' });
        return;
      }

      const result = await analyzeVisionFrame({
        imageBase64,
        mimeType: mimeType || 'image/jpeg',
        mode: mode || 'scene',
        prompt,
        persona: persona || 'maya',
        privacyShield: privacyShield !== false,
      });
      res.json(result);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Vision analysis failed.';
      res.status(500).json({ error: message });
    }
  });

  app.post('/api/agents/plan', async (req, res) => {
    try {
      const { goal, persona } = req.body as { goal?: string; persona?: PersonaId };
      if (!goal || !goal.trim()) {
        res.status(400).json({ error: 'Goal description is required.' });
        return;
      }
      const plan = await generateMultiAgentPlan({
        goal: goal.trim(),
        persona: persona || 'friday',
      });
      res.json(plan);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Agent planning failed.';
      res.status(500).json({ error: message });
    }
  });

  app.post('/api/tts', async (req, res) => {
    try {
      const { text, persona } = req.body as { text?: string; persona?: PersonaId };
      if (!text || !text.trim()) {
        res.status(400).json({ error: 'Text is required for speech synthesis.' });
        return;
      }
      const audio = await synthesizePersonaSpeech({
        text: text.trim(),
        persona: persona || 'maya',
      });
      res.json(audio);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Speech synthesis failed.';
      res.status(500).json({ error: message });
    }
  });

  app.post('/api/transcribe', async (req, res) => {
    try {
      const { audioBase64, mimeType } = req.body as {
        audioBase64?: string;
        mimeType?: string;
      };
      if (!audioBase64) {
        res.status(400).json({ error: 'Audio data is required.' });
        return;
      }
      const transcript = await transcribeAudioClip({
        audioBase64,
        mimeType: mimeType || 'audio/webm',
      });
      res.json({ transcript });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Audio transcription failed.';
      res.status(500).json({ error: message });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Aanya AI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start Aanya AI server:', err);
  process.exit(1);
});
