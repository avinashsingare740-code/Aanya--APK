import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Camera,
  Code2,
  MessageSquare,
  Mic,
  Settings,
  Workflow,
} from 'lucide-react';
import {
  GALAXY_BACKDROP_PATH,
  INITIAL_ANDROID_PERMISSIONS,
  INITIAL_CALL_REMINDERS,
  INITIAL_EMERGENCY_CONTACTS,
  INITIAL_MEMORIES,
  INITIAL_SKILLS,
  INITIAL_SMART_DEVICES,
  PERSONAS,
} from './data/presets';
import { ChatWorkspace } from './components/ChatWorkspace';
import { VoiceStudio } from './components/VoiceStudio';
import { VisionStudio } from './components/VisionStudio';
import { AutomationHub } from './components/AutomationHub';
import { AndroidCodeStudio } from './components/AndroidCodeStudio';
import { SettingsPrivacy } from './components/SettingsPrivacy';
import { FloatingAiOrb } from './components/FloatingAiOrb';
import { LockScreenModal } from './components/LockScreenModal';
import type {
  AanyaAppStateBackup,
  AndroidPermissionItem,
  CallReminder,
  ChatMessage,
  EmergencyContact,
  LanguageMode,
  MainScreen,
  MarkdownSkill,
  MemoryItem,
  OrbThemeId,
  PersonaId,
  ProviderId,
  ProviderStatus,
  SmartDevice,
  VoiceSettings,
} from './types';

const STORAGE_KEY = 'aanya_ai_max_state_v1';
const PIN_STORAGE_KEY = 'aanya_ai_vault_pin_v1';

const DEFAULT_VOICE_SETTINGS: VoiceSettings = {
  useNeuralTts: true,
  autoSpeakReplies: false,
  continuousMode: false,
  wakeWordEnabled: false,
  echoGuardEnabled: true,
  voiceGuardianEnabled: false,
  voiceprintCentroidHz: null,
  speechLocale: 'en-IN',
};

function makeInitialMessages(persona: PersonaId): ChatMessage[] {
  return [
    {
      id: 'welcome-1',
      role: 'assistant',
      text: PERSONAS[persona].greeting,
      persona,
      timestamp: new Date().toISOString(),
      activeAgent: 'Personal Assistant Agent',
      detectedLanguage: persona === 'maya' ? 'Hinglish' : 'English',
      usedProvider: 'gemini',
    },
  ];
}

export default function App() {
  const [screen, setScreen] = useState<MainScreen>('chat');
  const [persona, setPersona] = useState<PersonaId>('maya');
  const [orbTheme, setOrbTheme] = useState<OrbThemeId>('aanya-galaxy');
  const [languageMode, setLanguageMode] = useState<LanguageMode>('auto');
  const [providerOrder, setProviderOrder] = useState<ProviderId[]>([
    'gemini',
    'groq',
    'openrouter',
    'anthropic',
    'openai',
  ]);
  const [autoFallback, setAutoFallback] = useState(true);
  const [providers, setProviders] = useState<ProviderStatus[]>([]);

  const [messages, setMessages] = useState<ChatMessage[]>(() => makeInitialMessages('maya'));
  const [memories, setMemories] = useState<MemoryItem[]>(INITIAL_MEMORIES);
  const [skills, setSkills] = useState<MarkdownSkill[]>(INITIAL_SKILLS);
  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>(
    INITIAL_EMERGENCY_CONTACTS
  );
  const [smartDevices, setSmartDevices] = useState<SmartDevice[]>(INITIAL_SMART_DEVICES);
  const [callReminders, setCallReminders] = useState<CallReminder[]>(INITIAL_CALL_REMINDERS);
  const [permissions, setPermissions] = useState<AndroidPermissionItem[]>(
    INITIAL_ANDROID_PERMISSIONS
  );
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>(DEFAULT_VOICE_SETTINGS);

  const [isThinking, setIsThinking] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);

  // Vault Lock state
  const [vaultPinRecord, setVaultPinRecord] = useState<{ hash: string; salt: string } | null>(null);
  const [isLocked, setIsLocked] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Hydrate persisted state from localStorage
  useEffect(() => {
    try {
      const savedRaw = localStorage.getItem(STORAGE_KEY);
      if (savedRaw) {
        const parsed = JSON.parse(savedRaw) as Partial<AanyaAppStateBackup>;
        if (parsed.persona) setPersona(parsed.persona);
        if (parsed.orbTheme) setOrbTheme(parsed.orbTheme);
        if (parsed.languageMode) setLanguageMode(parsed.languageMode);
        if (Array.isArray(parsed.providerOrder) && parsed.providerOrder.length > 0) {
          setProviderOrder(parsed.providerOrder);
        }
        if (typeof parsed.autoFallback === 'boolean') setAutoFallback(parsed.autoFallback);
        if (Array.isArray(parsed.messages) && parsed.messages.length > 0) {
          const activeP: PersonaId = parsed.persona || 'maya';
          const refreshed = parsed.messages.map((m) =>
            m.id === 'welcome-1' && m.text.includes('Maya')
              ? { ...m, text: PERSONAS[activeP].greeting, detectedLanguage: 'Hinglish' }
              : m
          );
          setMessages(refreshed);
        }
        if (Array.isArray(parsed.memories)) setMemories(parsed.memories);
        if (Array.isArray(parsed.skills) && parsed.skills.length > 0) setSkills(parsed.skills);
        if (Array.isArray(parsed.emergencyContacts)) {
          setEmergencyContacts(parsed.emergencyContacts);
        }
        if (Array.isArray(parsed.smartDevices)) setSmartDevices(parsed.smartDevices);
        if (Array.isArray(parsed.callReminders)) setCallReminders(parsed.callReminders);
        if (parsed.voiceSettings) {
          setVoiceSettings({ ...DEFAULT_VOICE_SETTINGS, ...parsed.voiceSettings });
        }
      }

      const savedPin = localStorage.getItem(PIN_STORAGE_KEY);
      if (savedPin) {
        const parsedPin = JSON.parse(savedPin) as { hash: string; salt: string };
        if (parsedPin.hash && parsedPin.salt) {
          setVaultPinRecord(parsedPin);
        }
      }
    } catch {
      // Ignore corrupt localStorage entries
    }
  }, []);

  // Persist user state locally
  useEffect(() => {
    try {
      const snapshot: AanyaAppStateBackup = {
        version: 1,
        exportedAt: new Date().toISOString(),
        persona,
        orbTheme,
        languageMode,
        providerOrder,
        autoFallback,
        messages: messages.slice(-60),
        memories,
        skills,
        emergencyContacts,
        smartDevices,
        callReminders,
        voiceSettings,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
    } catch {
      // Ignore storage quota errors
    }
  }, [
    persona,
    orbTheme,
    languageMode,
    providerOrder,
    autoFallback,
    messages,
    memories,
    skills,
    emergencyContacts,
    smartDevices,
    callReminders,
    voiceSettings,
  ]);

  // Fetch server-side AI provider configuration status
  useEffect(() => {
    fetch('/api/providers')
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data?.providers)) {
          setProviders(data.providers);
        }
      })
      .catch(() => {});
  }, []);

  const stopSpeaking = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  }, []);

  const speakBrowserFallback = useCallback(
    (text: string, activePersona: PersonaId) => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
        setIsSpeaking(false);
        return;
      }
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      const cfg = PERSONAS[activePersona];
      utterance.pitch = cfg.speechPitch;
      utterance.rate = cfg.speechRate;
      utterance.lang = voiceSettings.speechLocale;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    },
    [voiceSettings.speechLocale]
  );

  const speakText = useCallback(
    async (text: string, targetPersona: PersonaId = persona) => {
      stopSpeaking();
      if (!text.trim()) return;

      if (!voiceSettings.useNeuralTts) {
        speakBrowserFallback(text, targetPersona);
        return;
      }

      setIsSpeaking(true);
      try {
        const res = await fetch('/api/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text, persona: targetPersona }),
        });
        const data = await res.json();
        if (!res.ok || !data.audioBase64) {
          throw new Error(data.error || 'Neural TTS unavailable');
        }
        const audio = new Audio(`data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`);
        audioRef.current = audio;
        audio.onended = () => setIsSpeaking(false);
        audio.onerror = () => {
          setIsSpeaking(false);
          speakBrowserFallback(text, targetPersona);
        };
        await audio.play();
      } catch {
        speakBrowserFallback(text, targetPersona);
      }
    },
    [persona, stopSpeaking, voiceSettings.useNeuralTts, speakBrowserFallback]
  );

  const handleSelectPersona = (nextPersona: PersonaId) => {
    setPersona(nextPersona);
    setOrbTheme(PERSONAS[nextPersona].defaultOrbTheme);
  };

  const handleSendMessage = async (text: string) => {
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text,
      persona,
      timestamp: new Date().toISOString(),
    };

    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    setIsThinking(true);
    setChatError(null);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          persona,
          history: nextHistory.slice(-12).map((m) => ({ role: m.role, text: m.text })),
          memories: memories.map((m) => ({ text: m.text, category: m.category })),
          skills: skills.map((s) => ({ title: s.title, trigger: s.trigger, markdown: s.markdown })),
          providerOrder,
          autoFallback,
          preferredLanguage: languageMode,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Unable to reach Aanya AI brain.');
      }

      const assistantMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        text: data.reply,
        persona,
        timestamp: new Date().toISOString(),
        activeAgent: data.activeAgent,
        detectedLanguage: data.detectedLanguage,
        usedProvider: data.usedProvider,
        proposedAction: data.proposedAction
          ? {
              id: `act-${Date.now()}`,
              ...data.proposedAction,
              status: 'pending' as const,
            }
          : null,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      if (data.memoryCandidate) {
        setMemories((prev) => {
          const exists = prev.some(
            (item) => item.text.toLowerCase() === String(data.memoryCandidate).toLowerCase()
          );
          if (exists) return prev;
          return [
            {
              id: `mem-${Date.now()}`,
              text: String(data.memoryCandidate),
              category: 'Context',
              createdAt: new Date().toISOString(),
            },
            ...prev,
          ];
        });
      }

      if (voiceSettings.autoSpeakReplies || screen === 'voice') {
        void speakText(data.reply, persona);
      }
    } catch (err) {
      setChatError(err instanceof Error ? err.message : 'Request failed.');
    } finally {
      setIsThinking(false);
    }
  };

  const handleApproveAction = (messageId: string) => {
    setMessages((prev) =>
      prev.map((m) =>
        m.id === messageId && m.proposedAction
          ? {
              ...m,
              proposedAction: {
                ...m.proposedAction,
                status: 'approved',
                executedAt: new Date().toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                }),
              },
            }
          : m
      )
    );
  };

  const handleCancelAction = (messageId: string) => {
    setMessages((prev) =>
      prev.map((m) =>
        m.id === messageId && m.proposedAction
          ? {
              ...m,
              proposedAction: {
                ...m.proposedAction,
                status: 'cancelled',
              },
            }
          : m
      )
    );
  };

  const handleRunSkillInChat = (skill: MarkdownSkill) => {
    setScreen('chat');
    void handleSendMessage(`Execute saved Markdown skill "${skill.title}" (${skill.trigger}).`);
  };

  const handleRestoreBackup = (restored: AanyaAppStateBackup) => {
    if (restored.persona) setPersona(restored.persona);
    if (restored.orbTheme) setOrbTheme(restored.orbTheme);
    if (restored.languageMode) setLanguageMode(restored.languageMode);
    if (Array.isArray(restored.providerOrder)) setProviderOrder(restored.providerOrder);
    if (typeof restored.autoFallback === 'boolean') setAutoFallback(restored.autoFallback);
    if (Array.isArray(restored.messages)) setMessages(restored.messages);
    if (Array.isArray(restored.memories)) setMemories(restored.memories);
    if (Array.isArray(restored.skills)) setSkills(restored.skills);
    if (Array.isArray(restored.emergencyContacts)) {
      setEmergencyContacts(restored.emergencyContacts);
    }
    if (Array.isArray(restored.smartDevices)) setSmartDevices(restored.smartDevices);
    if (Array.isArray(restored.callReminders)) setCallReminders(restored.callReminders);
    if (restored.voiceSettings) setVoiceSettings(restored.voiceSettings);
  };

  const handleEraseAllData = () => {
    localStorage.removeItem(STORAGE_KEY);
    setMessages(makeInitialMessages(persona));
    setMemories([]);
    setSkills(INITIAL_SKILLS);
    setEmergencyContacts([]);
    setCallReminders([]);
  };

  const lastAssistantReply =
    [...messages].reverse().find((m) => m.role === 'assistant')?.text ?? '';

  const backupSnapshot: AanyaAppStateBackup = {
    version: 1,
    exportedAt: new Date().toISOString(),
    persona,
    orbTheme,
    languageMode,
    providerOrder,
    autoFallback,
    messages,
    memories,
    skills,
    emergencyContacts,
    smartDevices,
    callReminders,
    voiceSettings,
  };

  const navItems: Array<{ id: MainScreen; label: string; icon: React.ComponentType<{ className?: string }> }> = [
    { id: 'chat', label: 'Chat', icon: MessageSquare },
    { id: 'voice', label: 'Voice', icon: Mic },
    { id: 'vision', label: 'Vision', icon: Camera },
    { id: 'hub', label: 'Automation', icon: Workflow },
    { id: 'android', label: 'Android Code', icon: Code2 },
  ];

  return (
    <div className="relative min-h-screen bg-[#050814] text-slate-100">
      {/* Deep Galaxy Atmospheric Backdrop */}
      <div
        className="pointer-events-none fixed inset-0 z-0 opacity-35"
        aria-hidden="true"
      >
        <img
          src={GALAXY_BACKDROP_PATH}
          alt=""
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#050814]/70 via-[#050814]/82 to-[#050814]" />
      </div>

      {/* Top Bar Contract: 3 Clean Zones */}
      <header className="sticky top-0 z-30 border-b border-slate-800/80 bg-[#050814]/85 backdrop-blur-lg">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => setScreen('chat')}
            className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-cyan-400"
          >
            Aanya AI
          </button>

          {/* Zone 2: 5 Clean Single-Line Nav Links */}
          <nav
            aria-label="Primary navigation"
            className="hidden md:flex items-center gap-6 text-sm font-medium"
          >
            {navItems.map((item) => {
              const active = screen === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setScreen(item.id)}
                  className={`whitespace-nowrap shrink-0 py-1 transition-colors ${
                    active
                      ? 'text-cyan-400 underline decoration-cyan-400/70 underline-offset-8'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Single Primary Action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => setScreen('settings')}
              className={`inline-flex min-h-[38px] items-center gap-2 rounded-lg px-4 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                screen === 'settings'
                  ? 'bg-cyan-400 text-slate-950'
                  : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400'
              }`}
            >
              <Settings className="h-3.5 w-3.5" />
              <span>Settings</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Canvas */}
      <main className="relative z-10 mx-auto max-w-7xl px-4 pb-24 pt-6 sm:px-6 lg:px-8 lg:pb-12">
        {screen === 'chat' && (
          <ChatWorkspace
            persona={persona}
            onSelectPersona={handleSelectPersona}
            orbTheme={orbTheme}
            onSelectOrbTheme={setOrbTheme}
            languageMode={languageMode}
            onSelectLanguageMode={setLanguageMode}
            messages={messages}
            memories={memories}
            isThinking={isThinking}
            isSpeaking={isSpeaking}
            errorMessage={chatError}
            onSendMessage={handleSendMessage}
            onApproveAction={handleApproveAction}
            onCancelAction={handleCancelAction}
            onSpeakText={(txt) => void speakText(txt)}
            onAddMemory={(text, category) =>
              setMemories((prev) => [
                {
                  id: `mem-${Date.now()}`,
                  text,
                  category,
                  createdAt: new Date().toISOString(),
                },
                ...prev,
              ])
            }
            onDeleteMemory={(id) => setMemories((prev) => prev.filter((m) => m.id !== id))}
            onOpenVoiceScreen={() => setScreen('voice')}
          />
        )}

        {screen === 'voice' && (
          <VoiceStudio
            persona={persona}
            onSelectPersona={handleSelectPersona}
            orbTheme={orbTheme}
            voiceSettings={voiceSettings}
            onUpdateVoiceSettings={(patch) =>
              setVoiceSettings((prev) => ({ ...prev, ...patch }))
            }
            isThinking={isThinking}
            isSpeaking={isSpeaking}
            lastAssistantReply={lastAssistantReply}
            onVoiceTranscript={handleSendMessage}
            onStopSpeaking={stopSpeaking}
            onTestSpeak={(txt) => void speakText(txt)}
          />
        )}

        {screen === 'vision' && (
          <VisionStudio persona={persona} onSpeakText={(txt) => void speakText(txt)} />
        )}

        {screen === 'hub' && (
          <AutomationHub
            persona={persona}
            skills={skills}
            emergencyContacts={emergencyContacts}
            smartDevices={smartDevices}
            callReminders={callReminders}
            onSaveSkill={(skill) => setSkills((prev) => [skill, ...prev])}
            onDeleteSkill={(id) => setSkills((prev) => prev.filter((s) => s.id !== id))}
            onRunSkillInChat={handleRunSkillInChat}
            onAddEmergencyContact={(contact) =>
              setEmergencyContacts((prev) => [
                ...prev,
                { id: `sos-${Date.now()}`, ...contact },
              ])
            }
            onDeleteEmergencyContact={(id) =>
              setEmergencyContacts((prev) => prev.filter((c) => c.id !== id))
            }
            onToggleSmartDeviceAuth={(id) =>
              setSmartDevices((prev) =>
                prev.map((d) =>
                  d.id === id
                    ? {
                        ...d,
                        authenticated: !d.authenticated,
                        state: !d.authenticated ? 'Paired · Ready' : 'Unpaired',
                      }
                    : d
                )
              )
            }
            onUpdateSmartDeviceState={(id, state) =>
              setSmartDevices((prev) => prev.map((d) => (d.id === id ? { ...d, state } : d)))
            }
            onAddCallReminder={(rem) =>
              setCallReminders((prev) => [
                { id: `call-${Date.now()}`, done: false, ...rem },
                ...prev,
              ])
            }
            onToggleCallReminderDone={(id) =>
              setCallReminders((prev) =>
                prev.map((r) => (r.id === id ? { ...r, done: !r.done } : r))
              )
            }
            onDeleteCallReminder={(id) =>
              setCallReminders((prev) => prev.filter((r) => r.id !== id))
            }
          />
        )}

        {screen === 'android' && <AndroidCodeStudio />}

        {screen === 'settings' && (
          <SettingsPrivacy
            orbTheme={orbTheme}
            onSelectOrbTheme={setOrbTheme}
            providers={providers}
            providerOrder={providerOrder}
            autoFallback={autoFallback}
            onChangeProviderOrder={setProviderOrder}
            onToggleAutoFallback={() => setAutoFallback((v) => !v)}
            permissions={permissions}
            onTogglePermission={(id) =>
              setPermissions((prev) =>
                prev.map((p) => (p.id === id ? { ...p, consentGranted: !p.consentGranted } : p))
              )
            }
            backupSnapshot={backupSnapshot}
            onRestoreBackup={handleRestoreBackup}
            onEraseAllData={handleEraseAllData}
            hasVaultPin={Boolean(vaultPinRecord)}
            onSetVaultPin={(hash, salt) => {
              const rec = { hash, salt };
              setVaultPinRecord(rec);
              localStorage.setItem(PIN_STORAGE_KEY, JSON.stringify(rec));
            }}
            onLockNow={() => {
              if (vaultPinRecord) setIsLocked(true);
            }}
          />
        )}
      </main>

      {/* Floating Corner AI Orb Quick Trigger (Desktop, hidden on Voice screen) */}
      {screen !== 'voice' && (
        <div className="fixed bottom-6 right-6 z-30 hidden lg:block">
          <FloatingAiOrb
            themeId={orbTheme}
            size="sm"
            state={isThinking ? 'thinking' : isSpeaking ? 'speaking' : 'idle'}
            onClick={() => setScreen('voice')}
            ariaLabel="Launch Aanya AI Voice Orb"
          />
        </div>
      )}

      {/* Mobile Bottom Navigation Bar (Thumb Zone Ergonomics, <= 15% mobile height cap) */}
      <nav
        aria-label="Mobile navigation"
        className="fixed bottom-0 left-0 right-0 z-40 border-t border-slate-800/90 bg-[#070d1f]/95 backdrop-blur-lg md:hidden"
      >
        <div className="grid h-16 grid-cols-5 items-center px-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = screen === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setScreen(item.id)}
                className={`flex min-h-[44px] flex-col items-center justify-center gap-1 transition-colors ${
                  active ? 'text-cyan-400' : 'text-slate-400'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="text-[10px] font-medium tracking-tight whitespace-nowrap">
                  {item.label === 'Android Code' ? 'Kotlin' : item.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Secure Vault Lock Modal */}
      {vaultPinRecord && (
        <LockScreenModal
          open={isLocked}
          orbTheme={orbTheme}
          pinHash={vaultPinRecord.hash}
          pinSalt={vaultPinRecord.salt}
          onUnlock={() => setIsLocked(false)}
        />
      )}
    </div>
  );
}
