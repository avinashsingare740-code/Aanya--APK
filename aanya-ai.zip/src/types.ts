export type PersonaId = 'maya' | 'friday' | 'venom';

export type OrbThemeId =
  | 'aanya-galaxy'
  | 'maya-2047'
  | 'nova'
  | 'jarvis'
  | 'tron'
  | 'cyber-ai'
  | 'friday'
  | 'venom';

export type ProviderId = 'gemini' | 'groq' | 'openrouter' | 'anthropic' | 'openai';

export type MainScreen = 'chat' | 'voice' | 'vision' | 'hub' | 'android' | 'settings';

export type LanguageMode = 'auto' | 'en' | 'hi' | 'hinglish';

export interface PersonaConfig {
  id: PersonaId;
  name: string;
  role: string;
  tagline: string;
  voiceLabel: string;
  defaultOrbTheme: OrbThemeId;
  avatarPath: string | null;
  accentHex: string;
  speechPitch: number;
  speechRate: number;
  greeting: string;
}

export interface OrbThemeConfig {
  id: OrbThemeId;
  name: string;
  description: string;
  coreFrom: string;
  coreVia: string;
  coreTo: string;
  ringPrimary: string;
  ringSecondary: string;
  glowRgba: string;
  particleHex: string;
}

export interface ProposedAction {
  id: string;
  type:
    | 'call'
    | 'sms'
    | 'whatsapp'
    | 'open_app'
    | 'android_setting'
    | 'smart_home'
    | 'pc_command'
    | 'sos'
    | 'automation_macro';
  title: string;
  target: string;
  payload: string;
  requiresConfirmation: boolean;
  status: 'pending' | 'approved' | 'cancelled';
  executedAt?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  persona: PersonaId;
  timestamp: string;
  activeAgent?: string;
  detectedLanguage?: string;
  usedProvider?: ProviderId;
  proposedAction?: ProposedAction | null;
}

export interface MemoryItem {
  id: string;
  text: string;
  category: 'Preference' | 'Contact' | 'Routine' | 'Context';
  createdAt: string;
}

export interface MarkdownSkill {
  id: string;
  title: string;
  trigger: string;
  category: string;
  requiresApproval: boolean;
  markdown: string;
  lastRunAt?: string;
}

export interface AgentStep {
  id: string;
  agent: string;
  actionTitle: string;
  detail: string;
  requiresApproval: boolean;
  outputPreview: string;
  status: 'pending' | 'approved' | 'completed' | 'skipped';
}

export interface AgentPlan {
  id: string;
  goal: string;
  planTitle: string;
  summary: string;
  steps: AgentStep[];
  createdAt: string;
}

export interface EmergencyContact {
  id: string;
  name: string;
  relation: string;
  phone: string;
}

export interface SmartDevice {
  id: string;
  name: string;
  kind: 'Smart Home' | 'Remote PC';
  host: string;
  authenticated: boolean;
  state: string;
}

export interface CallReminder {
  id: string;
  contactName: string;
  phone: string;
  note: string;
  scheduledFor: string;
  done: boolean;
}

export interface AndroidPermissionItem {
  id: string;
  name: string;
  androidPermission: string;
  purpose: string;
  consentGranted: boolean;
  sensitive: boolean;
  android16Note: string;
}

export interface ProviderStatus {
  id: ProviderId;
  name: string;
  model: string;
  configured: boolean;
  role: string;
}

export interface VoiceSettings {
  useNeuralTts: boolean;
  autoSpeakReplies: boolean;
  continuousMode: boolean;
  wakeWordEnabled: boolean;
  echoGuardEnabled: boolean;
  voiceGuardianEnabled: boolean;
  voiceprintCentroidHz: number | null;
  speechLocale: 'en-IN' | 'hi-IN' | 'en-US';
}

export interface AanyaAppStateBackup {
  version: number;
  exportedAt: string;
  persona: PersonaId;
  orbTheme: OrbThemeId;
  languageMode: LanguageMode;
  providerOrder: ProviderId[];
  autoFallback: boolean;
  messages: ChatMessage[];
  memories: MemoryItem[];
  skills: MarkdownSkill[];
  emergencyContacts: EmergencyContact[];
  smartDevices: SmartDevice[];
  callReminders: CallReminder[];
  voiceSettings: VoiceSettings;
}
