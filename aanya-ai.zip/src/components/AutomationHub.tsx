import React, { useState } from 'react';
import {
  AlertOctagon,
  Bot,
  Check,
  Download,
  FileCode2,
  Home,
  Laptop,
  MapPin,
  PhoneCall,
  Play,
  Plus,
  ShieldAlert,
  Smartphone,
  Trash2,
  Upload,
} from 'lucide-react';
import { AI_AGENTS } from '../data/presets';
import type {
  AgentPlan,
  CallReminder,
  EmergencyContact,
  MarkdownSkill,
  PersonaId,
  SmartDevice,
} from '../types';

interface AutomationHubProps {
  persona: PersonaId;
  skills: MarkdownSkill[];
  emergencyContacts: EmergencyContact[];
  smartDevices: SmartDevice[];
  callReminders: CallReminder[];
  onSaveSkill: (skill: MarkdownSkill) => void;
  onDeleteSkill: (id: string) => void;
  onRunSkillInChat: (skill: MarkdownSkill) => void;
  onAddEmergencyContact: (contact: Omit<EmergencyContact, 'id'>) => void;
  onDeleteEmergencyContact: (id: string) => void;
  onToggleSmartDeviceAuth: (id: string) => void;
  onUpdateSmartDeviceState: (id: string, state: string) => void;
  onAddCallReminder: (rem: Omit<CallReminder, 'id' | 'done'>) => void;
  onToggleCallReminderDone: (id: string) => void;
  onDeleteCallReminder: (id: string) => void;
}

type HubSection = 'agents' | 'automation' | 'skills' | 'sos';

interface AuditLogEntry {
  id: string;
  time: string;
  summary: string;
  category: string;
}

export const AutomationHub: React.FC<AutomationHubProps> = ({
  persona,
  skills,
  emergencyContacts,
  smartDevices,
  callReminders,
  onSaveSkill,
  onDeleteSkill,
  onRunSkillInChat,
  onAddEmergencyContact,
  onDeleteEmergencyContact,
  onToggleSmartDeviceAuth,
  onUpdateSmartDeviceState,
  onAddCallReminder,
  onToggleCallReminderDone,
  onDeleteCallReminder,
}) => {
  const [section, setSection] = useState<HubSection>('agents');

  // 7-Agent Orchestrator state
  const [goalInput, setGoalInput] = useState('');
  const [planning, setPlanning] = useState(false);
  const [planError, setPlanError] = useState<string | null>(null);
  const [activePlan, setActivePlan] = useState<AgentPlan | null>(null);

  // Automation & Smart Call Confirmation Gate state
  const [pendingAction, setPendingAction] = useState<{
    title: string;
    detail: string;
    onConfirm: () => void;
  } | null>(null);
  const [auditLog, setAuditLog] = useState<AuditLogEntry[]>([]);

  // Call Reminder Form
  const [remName, setRemName] = useState('');
  const [remPhone, setRemPhone] = useState('');
  const [remNote, setRemNote] = useState('');
  const [remWhen, setRemWhen] = useState('Today · 8:00 PM');

  // Markdown Skill Editor
  const [selectedSkillId, setSelectedSkillId] = useState<string | null>(skills[0]?.id ?? null);
  const [skillTitle, setSkillTitle] = useState('');
  const [skillTrigger, setSkillTrigger] = useState('');
  const [skillCategory, setSkillCategory] = useState('Custom Macro');
  const [skillMarkdown, setSkillMarkdown] = useState('');
  const [creatingSkill, setCreatingSkill] = useState(false);

  // SOS State
  const [sosName, setSosName] = useState('');
  const [sosRelation, setSosRelation] = useState('Family');
  const [sosPhone, setSosPhone] = useState('');
  const [shareLocationConsent, setShareLocationConsent] = useState(false);
  const [capturedCoords, setCapturedCoords] = useState<string | null>(null);
  const [sosActiveAlert, setSosActiveAlert] = useState<string | null>(null);

  const appendAudit = (category: string, summary: string) => {
    setAuditLog((prev) => [
      {
        id: `log-${Date.now()}`,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        category,
        summary,
      },
      ...prev.slice(0, 14),
    ]);
  };

  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalInput.trim() || planning) return;
    setPlanning(true);
    setPlanError(null);
    try {
      const res = await fetch('/api/agents/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ goal: goalInput.trim(), persona }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Unable to generate multi-agent plan.');
      setActivePlan({
        id: `plan-${Date.now()}`,
        goal: goalInput.trim(),
        planTitle: data.planTitle || 'Multi-Agent Execution Plan',
        summary: data.summary || '',
        createdAt: new Date().toISOString(),
        steps: (data.steps || []).map(
          (
            step: {
              id: string;
              agent: string;
              actionTitle: string;
              detail: string;
              requiresApproval: boolean;
              outputPreview: string;
            },
            idx: number
          ) => ({
            ...step,
            id: step.id || `step-${idx + 1}`,
            status: 'pending' as const,
          })
        ),
      });
    } catch (err) {
      setPlanError(err instanceof Error ? err.message : 'Agent coordinator failed.');
    } finally {
      setPlanning(false);
    }
  };

  const updateStepStatus = (stepId: string, status: 'completed' | 'skipped') => {
    setActivePlan((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        steps: prev.steps.map((s) => (s.id === stepId ? { ...s, status } : s)),
      };
    });
  };

  const handleSaveNewSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!skillTitle.trim() || !skillMarkdown.trim()) return;
    const newSkill: MarkdownSkill = {
      id: `skill-${Date.now()}`,
      title: skillTitle.trim(),
      trigger: skillTrigger.trim() || skillTitle.trim().toLowerCase(),
      category: skillCategory.trim() || 'Custom Macro',
      requiresApproval: true,
      markdown: skillMarkdown.trim(),
    };
    onSaveSkill(newSkill);
    setSelectedSkillId(newSkill.id);
    setCreatingSkill(false);
    setSkillTitle('');
    setSkillTrigger('');
    setSkillMarkdown('');
  };

  const handleImportMarkdownSkill = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const content = String(reader.result || '').trim();
      const firstHeading = content
        .split('\n')
        .find((line) => line.startsWith('# '))
        ?.replace(/^#\s+/, '')
        .trim();
      const imported: MarkdownSkill = {
        id: `skill-${Date.now()}`,
        title: firstHeading || file.name.replace(/\.md$/i, ''),
        trigger: file.name.replace(/\.md$/i, '').replace(/[-_]/g, ' '),
        category: 'Imported Markdown',
        requiresApproval: true,
        markdown: content,
      };
      onSaveSkill(imported);
      setSelectedSkillId(imported.id);
      setCreatingSkill(false);
    };
    reader.readAsText(file);
  };

  const handleExportSkill = (skill: MarkdownSkill) => {
    const blob = new Blob([skill.markdown], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${skill.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleRequestSosLocation = () => {
    if (!navigator.geolocation) {
      setCapturedCoords('Geolocation unavailable in this browser.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude.toFixed(5);
        const lng = pos.coords.longitude.toFixed(5);
        setCapturedCoords(`${lat}, ${lng} (https://maps.google.com/?q=${lat},${lng})`);
      },
      () => {
        setCapturedCoords('Location consent declined by user.');
      }
    );
  };

  const selectedSkill = skills.find((s) => s.id === selectedSkillId) || skills[0] || null;

  return (
    <div className="space-y-6">
      {/* Sub-navigation Segmented Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-white">Agents, Automation, Skills & SOS</h2>
          <p className="text-xs text-slate-400">
            Every sensitive phone call, message, remote PC command, or SOS dispatch enforces explicit user approval.
          </p>
        </div>

        <div
          className="flex flex-wrap items-center gap-1 rounded-xl border border-slate-800 bg-[#070d1f] p-1"
          role="tablist"
        >
          {[
            { id: 'agents' as const, label: '7 AI Agents' },
            { id: 'automation' as const, label: 'Phone, Calls & PC' },
            { id: 'skills' as const, label: 'Markdown Skills' },
            { id: 'sos' as const, label: 'SOS Emergency' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={section === tab.id}
              onClick={() => setSection(tab.id)}
              className={`min-h-[38px] rounded-lg px-3.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                section === tab.id
                  ? 'bg-cyan-500 text-slate-950'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Global Confirmation Gate Banner */}
      {pendingAction && (
        <div
          role="alertdialog"
          className="rounded-2xl border border-amber-500/50 bg-amber-950/25 p-5"
        >
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
            <div className="flex items-start gap-3">
              <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
              <div>
                <div className="text-xs font-semibold text-amber-300">
                  Explicit Confirmation Required
                </div>
                <div className="mt-0.5 text-sm font-semibold text-white">
                  {pendingAction.title}
                </div>
                <p className="mt-1 text-xs text-slate-300">{pendingAction.detail}</p>
              </div>
            </div>
            <div className="flex shrink-0 gap-2.5">
              <button
                type="button"
                onClick={() => {
                  pendingAction.onConfirm();
                  setPendingAction(null);
                }}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-cyan-500 px-4 text-xs font-semibold text-slate-950 hover:bg-cyan-400"
              >
                <Check className="h-4 w-4" />
                <span>Confirm & Execute</span>
              </button>
              <button
                type="button"
                onClick={() => setPendingAction(null)}
                className="min-h-[40px] rounded-xl border border-slate-700 bg-slate-900 px-4 text-xs font-medium text-slate-300 hover:text-white"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 1: 7 COORDINATED AI AGENTS */}
      {section === 'agents' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 lg:col-span-5">
            <h3 className="text-base font-semibold text-white">7 Independent Aanya Agents</h3>
            <p className="mt-1 text-xs text-slate-400">
              Specialized roles that coordinate multi-step objectives with built-in consent policies.
            </p>
            <ul className="mt-4 divide-y divide-slate-800/70">
              {AI_AGENTS.map((ag) => (
                <li key={ag.name} className="py-3 first:pt-0 last:pb-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-medium text-white">{ag.name}</span>
                    <span className="text-[11px] text-cyan-400">{ag.approvalPolicy}</span>
                  </div>
                  <p className="mt-1 text-xs text-slate-400">{ag.focus}</p>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 lg:col-span-7">
            <div className="flex items-center gap-2">
              <Bot className="h-4 w-4 text-cyan-400" />
              <h3 className="text-base font-semibold text-white">Multi-Step Agent Coordinator</h3>
            </div>
            <p className="mt-1 text-xs text-slate-400">
              Describe a multi-step goal. Gemini coordinates the right agents and pauses on every sensitive step for your approval.
            </p>

            <form onSubmit={handleGeneratePlan} className="mt-4 flex flex-col gap-3 sm:flex-row">
              <input
                type="text"
                value={goalInput}
                onChange={(e) => setGoalInput(e.target.value)}
                placeholder="e.g. Research OPPO K12 5G battery tips, save to memory, and draft a WhatsApp summary"
                className="h-11 flex-1 rounded-xl border border-slate-800 bg-[#050a17] px-4 text-sm text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
              />
              <button
                type="submit"
                disabled={planning || !goalInput.trim()}
                className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-cyan-500 px-5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 disabled:opacity-40"
              >
                <Play className="h-3.5 w-3.5" />
                <span>{planning ? 'Coordinating...' : 'Build Plan'}</span>
              </button>
            </form>

            {planError && <p className="mt-3 text-xs text-amber-300">{planError}</p>}

            {!activePlan ? (
              <div className="mt-8 rounded-xl border border-slate-800/70 bg-[#050a17] p-6 text-center">
                <p className="text-sm text-slate-300">No active workflow plan</p>
                <p className="mt-1 text-xs text-slate-500">
                  Enter a goal above to see Aanya coordinate Research, Phone Automation, Coding, Communication, Vision, Memory, and Personal Assistant agents.
                </p>
              </div>
            ) : (
              <div className="mt-5 space-y-4">
                <div className="border-b border-slate-800/80 pb-3">
                  <h4 className="text-base font-semibold text-cyan-300">{activePlan.planTitle}</h4>
                  <p className="mt-1 text-xs text-slate-300">{activePlan.summary}</p>
                </div>

                <div className="space-y-3">
                  {activePlan.steps.map((step, i) => (
                    <div
                      key={step.id}
                      className="rounded-xl border border-slate-800 bg-[#060c1c] p-4"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                        <div className="text-cyan-300 font-medium">
                          0{i + 1}. {step.agent}
                        </div>
                        <div className="text-slate-400">
                          {step.status === 'completed'
                            ? 'Completed'
                            : step.status === 'skipped'
                              ? 'Skipped'
                              : step.requiresApproval
                                ? 'Awaiting User Approval'
                                : 'Ready to Run'}
                        </div>
                      </div>
                      <div className="mt-1 text-sm font-medium text-white">{step.actionTitle}</div>
                      <p className="mt-1 text-xs text-slate-400">{step.detail}</p>
                      <p className="mt-2 font-mono text-xs text-slate-300">{step.outputPreview}</p>

                      {step.status === 'pending' && (
                        <div className="mt-3 flex gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              updateStepStatus(step.id, 'completed');
                              appendAudit(step.agent, `Approved & ran: ${step.actionTitle}`);
                            }}
                            className="min-h-[36px] rounded-lg bg-cyan-500 px-3.5 text-xs font-semibold text-slate-950 hover:bg-cyan-400"
                          >
                            {step.requiresApproval ? 'Approve Step' : 'Run Step'}
                          </button>
                          <button
                            type="button"
                            onClick={() => updateStepStatus(step.id, 'skipped')}
                            className="min-h-[36px] rounded-lg border border-slate-700 px-3.5 text-xs text-slate-300 hover:text-white"
                          >
                            Skip
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 2: PHONE AUTOMATION, SMART CALLS, SMART HOME & REMOTE PC */}
      {section === 'automation' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Android Accessibility & Smart Call Actions */}
          <div className="space-y-6 lg:col-span-7">
            <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5">
              <div className="flex items-center gap-2">
                <Smartphone className="h-4 w-4 text-cyan-400" />
                <h3 className="text-base font-semibold text-white">
                  Phone Automation (Accessibility Consent)
                </h3>
              </div>
              <p className="mt-1 text-xs text-slate-400">
                Queue Android Accessibility actions for installed apps, WhatsApp, SMS, media, and settings. Every sensitive task demands confirmation.
              </p>

              <div className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                {[
                  {
                    title: 'Open WhatsApp & Draft Reply',
                    detail: 'Launch com.whatsapp via AccessibilityService and stage message draft without auto-sending.',
                    cat: 'WhatsApp',
                  },
                  {
                    title: 'Open Android Settings',
                    detail: 'Navigate directly to Android 16 Battery & Accessibility settings on OPPO K12 5G.',
                    cat: 'Android Settings',
                  },
                  {
                    title: 'Pause Music / Video Player',
                    detail: 'Send media pause keyevent to active audio/video application.',
                    cat: 'Media Control',
                  },
                  {
                    title: 'Clear Non-Priority Notifications',
                    detail: 'Dismiss low-priority promotional notifications while keeping calls and messages.',
                    cat: 'Notifications',
                  },
                ].map((act) => (
                  <button
                    key={act.title}
                    type="button"
                    onClick={() =>
                      setPendingAction({
                        title: act.title,
                        detail: act.detail,
                        onConfirm: () => appendAudit(act.cat, `Confirmed: ${act.title}`),
                      })
                    }
                    className="flex min-h-[52px] flex-col items-start justify-center rounded-xl border border-slate-800 bg-[#060c1d] p-3.5 text-left transition-colors hover:border-cyan-500/60"
                  >
                    <span className="text-xs font-semibold text-white">{act.title}</span>
                    <span className="mt-0.5 text-[11px] text-slate-400">{act.cat} · Consent gated</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Smart Call Management & Reminders */}
            <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <PhoneCall className="h-4 w-4 text-cyan-400" />
                  <h3 className="text-base font-semibold text-white">Smart Call Management</h3>
                </div>
                <span className="text-xs text-slate-400">No secret call recording</span>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!remName.trim() || !remPhone.trim()) return;
                  onAddCallReminder({
                    contactName: remName.trim(),
                    phone: remPhone.trim(),
                    note: remNote.trim() || 'Follow-up call',
                    scheduledFor: remWhen.trim() || 'Today',
                  });
                  setRemName('');
                  setRemPhone('');
                  setRemNote('');
                }}
                className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2"
              >
                <input
                  type="text"
                  value={remName}
                  onChange={(e) => setRemName(e.target.value)}
                  placeholder="Contact name"
                  className="h-10 rounded-xl border border-slate-800 bg-[#050a17] px-3 text-xs text-white placeholder:text-slate-500"
                />
                <input
                  type="tel"
                  value={remPhone}
                  onChange={(e) => setRemPhone(e.target.value)}
                  placeholder="+91 phone number"
                  className="h-10 rounded-xl border border-slate-800 bg-[#050a17] px-3 text-xs text-white placeholder:text-slate-500"
                />
                <input
                  type="text"
                  value={remNote}
                  onChange={(e) => setRemNote(e.target.value)}
                  placeholder="Call reminder note"
                  className="h-10 rounded-xl border border-slate-800 bg-[#050a17] px-3 text-xs text-white placeholder:text-slate-500"
                />
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={remWhen}
                    onChange={(e) => setRemWhen(e.target.value)}
                    placeholder="Time"
                    className="h-10 flex-1 rounded-xl border border-slate-800 bg-[#050a17] px-3 text-xs text-white"
                  />
                  <button
                    type="submit"
                    className="inline-flex h-10 shrink-0 items-center gap-1 rounded-xl bg-slate-800 px-3.5 text-xs font-medium text-cyan-300 hover:bg-slate-700"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>Add</span>
                  </button>
                </div>
              </form>

              <ul className="mt-4 divide-y divide-slate-800/70">
                {callReminders.map((rem) => (
                  <li
                    key={rem.id}
                    className="flex flex-wrap items-center justify-between gap-3 py-3"
                  >
                    <div className="min-w-0">
                      <div
                        className={`text-sm font-medium ${
                          rem.done ? 'line-through text-slate-500' : 'text-white'
                        }`}
                      >
                        {rem.contactName} ·{' '}
                        <span className="font-mono text-xs text-slate-400">{rem.phone}</span>
                      </div>
                      <p className="text-xs text-slate-400">
                        {rem.scheduledFor} · {rem.note}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          setPendingAction({
                            title: `Place Call to ${rem.contactName}`,
                            detail: `Dial ${rem.phone} via Android CALL_PHONE / ACTION_DIAL after your approval.`,
                            onConfirm: () => {
                              appendAudit('Smart Call', `Confirmed outgoing call to ${rem.contactName} (${rem.phone})`);
                              onToggleCallReminderDone(rem.id);
                            },
                          })
                        }
                        className="min-h-[36px] rounded-lg bg-cyan-500/15 px-3 text-xs font-medium text-cyan-300 hover:bg-cyan-500/25"
                      >
                        Call (Confirm)
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteCallReminder(rem.id)}
                        aria-label="Delete call reminder"
                        className="p-2 text-slate-500 hover:text-rose-400"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Right Column: Smart Home, Remote PC & Execution Audit */}
          <div className="space-y-6 lg:col-span-5">
            <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5">
              <div className="flex items-center gap-2">
                <Laptop className="h-4 w-4 text-cyan-400" />
                <h3 className="text-base font-semibold text-white">Smart Home & Remote PC</h3>
              </div>
              <p className="mt-1 text-xs text-slate-400">
                Authenticated connections only. All remote commands require confirmation.
              </p>

              <div className="mt-4 space-y-3">
                {smartDevices.map((dev) => (
                  <div
                    key={dev.id}
                    className="rounded-xl border border-slate-800 bg-[#060c1d] p-3.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        {dev.kind === 'Remote PC' ? (
                          <Laptop className="h-4 w-4 shrink-0 text-cyan-400" />
                        ) : (
                          <Home className="h-4 w-4 shrink-0 text-cyan-400" />
                        )}
                        <span className="truncate text-sm font-medium text-white">{dev.name}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => onToggleSmartDeviceAuth(dev.id)}
                        className="text-xs font-medium text-cyan-400 hover:text-cyan-300 shrink-0"
                      >
                        {dev.authenticated ? 'Authenticated' : 'Pair Device'}
                      </button>
                    </div>
                    <div className="mt-1 font-mono text-[11px] text-slate-400">
                      {dev.host} · {dev.state}
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {dev.kind === 'Remote PC' ? (
                        <>
                          <button
                            type="button"
                            disabled={!dev.authenticated}
                            onClick={() =>
                              setPendingAction({
                                title: `Lock ${dev.name}`,
                                detail: `Send authenticated TLS lock command to ${dev.host}.`,
                                onConfirm: () => {
                                  onUpdateSmartDeviceState(dev.id, 'Locked via TLS');
                                  appendAudit('Remote PC', `Locked ${dev.name}`);
                                },
                              })
                            }
                            className="min-h-[34px] rounded-lg border border-slate-700 px-3 text-xs text-slate-200 hover:border-cyan-400 disabled:opacity-40"
                          >
                            Lock PC
                          </button>
                          <button
                            type="button"
                            disabled={!dev.authenticated}
                            onClick={() =>
                              setPendingAction({
                                title: `Pause Media on ${dev.name}`,
                                detail: `Dispatch media pause over authenticated session on ${dev.host}.`,
                                onConfirm: () => {
                                  onUpdateSmartDeviceState(dev.id, 'Media Paused');
                                  appendAudit('Remote PC', `Paused media on ${dev.name}`);
                                },
                              })
                            }
                            className="min-h-[34px] rounded-lg border border-slate-700 px-3 text-xs text-slate-200 hover:border-cyan-400 disabled:opacity-40"
                          >
                            Pause Media
                          </button>
                        </>
                      ) : (
                        <button
                          type="button"
                          disabled={!dev.authenticated}
                          onClick={() =>
                            setPendingAction({
                              title: `Toggle ${dev.name}`,
                              detail: `Send Matter/LAN state change to ${dev.host}.`,
                              onConfirm: () => {
                                const next = dev.state.includes('Off')
                                  ? 'Active · 60% Cool Cyan'
                                  : 'Off · Standby';
                                onUpdateSmartDeviceState(dev.id, next);
                                appendAudit('Smart Home', `${dev.name} set to ${next}`);
                              },
                            })
                          }
                          className="min-h-[34px] rounded-lg border border-slate-700 px-3 text-xs text-slate-200 hover:border-cyan-400 disabled:opacity-40"
                        >
                          Toggle Power
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Approved Action History */}
            <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5">
              <h3 className="text-base font-semibold text-white">Approved Action Log</h3>
              {auditLog.length === 0 ? (
                <p className="mt-3 text-xs text-slate-500">
                  No approved actions executed yet in this session.
                </p>
              ) : (
                <ul className="mt-3 space-y-2 max-h-48 overflow-y-auto">
                  {auditLog.map((entry) => (
                    <li
                      key={entry.id}
                      className="border-b border-slate-800/70 pb-2 text-xs last:border-b-0"
                    >
                      <span className="font-mono text-[11px] tabular-nums text-slate-500">
                        {entry.time}
                      </span>{' '}
                      <span className="text-cyan-400">{entry.category}</span> ·{' '}
                      <span className="text-slate-300">{entry.summary}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: MARKDOWN SKILLS SYSTEM */}
      {section === 'skills' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 lg:col-span-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold text-white">Markdown Skills ({skills.length})</h3>
              <div className="flex items-center gap-2">
                <label className="inline-flex min-h-[36px] cursor-pointer items-center gap-1.5 rounded-lg border border-slate-700 px-3 text-xs text-slate-200 hover:border-cyan-400">
                  <Upload className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Import .md</span>
                  <input
                    type="file"
                    accept=".md,text/markdown,text/plain"
                    onChange={handleImportMarkdownSkill}
                    className="hidden"
                  />
                </label>
                <button
                  type="button"
                  onClick={() => setCreatingSkill(true)}
                  className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-cyan-500 px-3 text-xs font-semibold text-slate-950 hover:bg-cyan-400"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>New Skill</span>
                </button>
              </div>
            </div>

            <ul className="mt-4 space-y-2">
              {skills.map((skill) => {
                const active = !creatingSkill && selectedSkill?.id === skill.id;
                return (
                  <li key={skill.id}>
                    <button
                      type="button"
                      onClick={() => {
                        setCreatingSkill(false);
                        setSelectedSkillId(skill.id);
                      }}
                      className={`w-full rounded-xl border p-3.5 text-left transition-colors ${
                        active
                          ? 'border-cyan-400/70 bg-cyan-500/10'
                          : 'border-slate-800 bg-[#060c1d] hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-medium text-white">{skill.title}</span>
                        <span className="text-[11px] text-cyan-400">{skill.category}</span>
                      </div>
                      <p className="mt-1 font-mono text-[11px] text-slate-400">
                        Trigger: {skill.trigger}
                      </p>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>

          <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 lg:col-span-7">
            {creatingSkill ? (
              <form onSubmit={handleSaveNewSkill} className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-semibold text-white">Teach Aanya a New Skill (.md)</h3>
                  <button
                    type="button"
                    onClick={() => setCreatingSkill(false)}
                    className="text-xs text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <input
                    type="text"
                    value={skillTitle}
                    onChange={(e) => setSkillTitle(e.target.value)}
                    placeholder="Skill title (e.g. Evening Wrap-Up)"
                    className="h-10 rounded-xl border border-slate-800 bg-[#050a17] px-3 text-sm text-white"
                  />
                  <input
                    type="text"
                    value={skillTrigger}
                    onChange={(e) => setSkillTrigger(e.target.value)}
                    placeholder="Voice / text trigger phrase"
                    className="h-10 rounded-xl border border-slate-800 bg-[#050a17] px-3 text-sm text-white"
                  />
                </div>

                <input
                  type="text"
                  value={skillCategory}
                  onChange={(e) => setSkillCategory(e.target.value)}
                  placeholder="Category"
                  className="h-10 w-full rounded-xl border border-slate-800 bg-[#050a17] px-3 text-sm text-white"
                />

                <textarea
                  rows={10}
                  value={skillMarkdown}
                  onChange={(e) => setSkillMarkdown(e.target.value)}
                  placeholder={`# Evening Wrap-Up\n## Steps\n1. Review pending call reminders.\n2. Ask before enabling Do Not Disturb.\n3. Wish the user good night in Hinglish.`}
                  className="w-full rounded-xl border border-slate-800 bg-[#050a17] p-3.5 font-mono text-xs text-slate-200 focus:border-cyan-400 focus:outline-none"
                />

                <button
                  type="submit"
                  className="min-h-[42px] rounded-xl bg-cyan-500 px-5 text-xs font-semibold text-slate-950 hover:bg-cyan-400"
                >
                  Save Markdown Skill
                </button>
              </form>
            ) : selectedSkill ? (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <FileCode2 className="h-4 w-4 text-cyan-400" />
                      <h3 className="text-base font-semibold text-white">{selectedSkill.title}</h3>
                    </div>
                    <p className="mt-0.5 text-xs text-slate-400">
                      Trigger: {selectedSkill.trigger} · {selectedSkill.category}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => onRunSkillInChat(selectedSkill)}
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl bg-cyan-500 px-4 text-xs font-semibold text-slate-950 hover:bg-cyan-400"
                    >
                      <Play className="h-3.5 w-3.5" />
                      <span>Replay Workflow</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleExportSkill(selectedSkill)}
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-slate-700 px-3.5 text-xs text-slate-200 hover:border-cyan-400"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>Export .md</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteSkill(selectedSkill.id)}
                      aria-label="Delete skill"
                      className="inline-flex min-h-[38px] items-center rounded-xl border border-slate-800 px-3 text-slate-400 hover:text-rose-400"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                <pre className="max-h-[380px] overflow-y-auto whitespace-pre-wrap rounded-xl border border-slate-800 bg-[#050a17] p-4 font-mono text-xs leading-relaxed text-slate-200">
                  {selectedSkill.markdown}
                </pre>
              </div>
            ) : (
              <p className="text-sm text-slate-400">Select or create a Markdown skill.</p>
            )}
          </div>
        </div>
      )}

      {/* SECTION 4: SOS EMERGENCY MODE */}
      {section === 'sos' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="rounded-2xl border border-rose-500/30 bg-[#120918]/90 p-6 lg:col-span-6">
            <div className="flex items-center gap-2 text-rose-400">
              <AlertOctagon className="h-5 w-5" />
              <h3 className="text-lg font-semibold text-white">SOS Emergency Mode</h3>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-slate-300">
              Emergency SMS, calling, and optional location sharing are strictly confirmation-gated. Tap Emergency Stop at any time to halt all alerts.
            </p>

            {/* Location Consent Toggle */}
            <div className="mt-5 rounded-xl border border-slate-800 bg-[#070b18] p-4">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-cyan-400" />
                  <span className="text-xs font-medium text-white">
                    Include GPS Location (Explicit Consent)
                  </span>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={shareLocationConsent}
                  onClick={() => {
                    const next = !shareLocationConsent;
                    setShareLocationConsent(next);
                    if (next) handleRequestSosLocation();
                    else setCapturedCoords(null);
                  }}
                  className={`h-6 w-11 rounded-full transition-colors ${
                    shareLocationConsent ? 'bg-cyan-500' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`block h-4 w-4 rounded-full bg-slate-950 transition-transform ${
                      shareLocationConsent ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              {capturedCoords && (
                <p className="mt-2 font-mono text-[11px] text-cyan-300 break-all">
                  {capturedCoords}
                </p>
              )}
            </div>

            {sosActiveAlert && (
              <div
                role="alert"
                className="mt-4 rounded-xl border border-rose-500/60 bg-rose-950/50 p-4 text-xs text-rose-100"
              >
                {sosActiveAlert}
              </div>
            )}

            <div className="mt-5 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() =>
                  setPendingAction({
                    title: 'Dispatch SOS Alert to Emergency Contacts',
                    detail: `Prepare emergency SMS to ${emergencyContacts.length} contact(s)${
                      shareLocationConsent && capturedCoords
                        ? ` with GPS coordinates (${capturedCoords})`
                        : ' without location'
                    }.`,
                    onConfirm: () => {
                      setSosActiveAlert(
                        `SOS Alert confirmed for ${emergencyContacts
                          .map((c) => c.name)
                          .join(', ')}. Ready for Android SmsManager & Dialer.`
                      );
                      appendAudit('SOS Emergency', 'User confirmed SOS emergency dispatch');
                    },
                  })
                }
                className="min-h-[46px] flex-1 rounded-xl bg-rose-600 px-5 text-sm font-semibold text-white hover:bg-rose-500"
              >
                Trigger SOS (Confirm)
              </button>

              <button
                type="button"
                onClick={() => {
                  setSosActiveAlert(null);
                  setPendingAction(null);
                  appendAudit('SOS Emergency', 'Emergency Stop activated — all alerts halted');
                }}
                className="min-h-[46px] rounded-xl border border-rose-400/60 bg-[#080d1d] px-5 text-sm font-semibold text-rose-200 hover:bg-rose-950/60"
              >
                Emergency Stop
              </button>
            </div>
          </div>

          {/* Emergency Contacts List */}
          <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-6 lg:col-span-6">
            <h3 className="text-base font-semibold text-white">Emergency Contacts</h3>
            <p className="mt-1 text-xs text-slate-400">
              Stored locally and included in encrypted Aanya backups.
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!sosName.trim() || !sosPhone.trim()) return;
                onAddEmergencyContact({
                  name: sosName.trim(),
                  relation: sosRelation.trim() || 'Contact',
                  phone: sosPhone.trim(),
                });
                setSosName('');
                setSosPhone('');
              }}
              className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-3"
            >
              <input
                type="text"
                value={sosName}
                onChange={(e) => setSosName(e.target.value)}
                placeholder="Contact name"
                className="h-10 rounded-xl border border-slate-800 bg-[#050a17] px-3 text-xs text-white"
              />
              <input
                type="text"
                value={sosRelation}
                onChange={(e) => setSosRelation(e.target.value)}
                placeholder="Relation"
                className="h-10 rounded-xl border border-slate-800 bg-[#050a17] px-3 text-xs text-white"
              />
              <div className="flex gap-2">
                <input
                  type="tel"
                  value={sosPhone}
                  onChange={(e) => setSosPhone(e.target.value)}
                  placeholder="Phone"
                  className="h-10 flex-1 rounded-xl border border-slate-800 bg-[#050a17] px-3 text-xs text-white"
                />
                <button
                  type="submit"
                  className="h-10 shrink-0 rounded-xl bg-slate-800 px-3 text-xs font-medium text-cyan-300 hover:bg-slate-700"
                >
                  Add
                </button>
              </div>
            </form>

            <ul className="mt-4 divide-y divide-slate-800/70">
              {emergencyContacts.map((contact) => (
                <li
                  key={contact.id}
                  className="flex items-center justify-between gap-3 py-3"
                >
                  <div>
                    <div className="text-sm font-medium text-white">
                      {contact.name} ·{' '}
                      <span className="text-xs font-normal text-slate-400">{contact.relation}</span>
                    </div>
                    <div className="font-mono text-xs text-cyan-300">{contact.phone}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onDeleteEmergencyContact(contact.id)}
                    aria-label="Remove emergency contact"
                    className="p-2 text-slate-500 hover:text-rose-400"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
