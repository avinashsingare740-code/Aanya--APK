import React, { useEffect, useRef, useState } from 'react';
import {
  BookmarkPlus,
  Check,
  Mic,
  Send,
  ShieldAlert,
  Trash2,
  Volume2,
  X,
} from 'lucide-react';
import { ORB_THEME_LIST, PERSONAS } from '../data/presets';
import { FloatingAiOrb } from './FloatingAiOrb';
import { PersonaAvatar } from './PersonaAvatar';
import type {
  ChatMessage,
  LanguageMode,
  MemoryItem,
  OrbThemeId,
  PersonaId,
} from '../types';

interface ChatWorkspaceProps {
  persona: PersonaId;
  onSelectPersona: (id: PersonaId) => void;
  orbTheme: OrbThemeId;
  onSelectOrbTheme: (id: OrbThemeId) => void;
  languageMode: LanguageMode;
  onSelectLanguageMode: (lang: LanguageMode) => void;
  messages: ChatMessage[];
  memories: MemoryItem[];
  isThinking: boolean;
  isSpeaking: boolean;
  errorMessage: string | null;
  onSendMessage: (text: string) => Promise<void>;
  onApproveAction: (messageId: string) => void;
  onCancelAction: (messageId: string) => void;
  onSpeakText: (text: string) => void;
  onAddMemory: (text: string, category: MemoryItem['category']) => void;
  onDeleteMemory: (id: string) => void;
  onOpenVoiceScreen: () => void;
}

const QUICK_PROMPTS = [
  'Hey Aanya, aaj ka schedule aur study plan Hinglish mein banao',
  'Rohan ko 6 PM sync ke liye WhatsApp message draft karo',
  'Android 16 permissions ke liye Kotlin Jetpack Compose snippet likho',
  'Morning briefing do aur Focus Mode ready karo',
];

export const ChatWorkspace: React.FC<ChatWorkspaceProps> = ({
  persona,
  onSelectPersona,
  orbTheme,
  onSelectOrbTheme,
  languageMode,
  onSelectLanguageMode,
  messages,
  memories,
  isThinking,
  isSpeaking,
  errorMessage,
  onSendMessage,
  onApproveAction,
  onCancelAction,
  onSpeakText,
  onAddMemory,
  onDeleteMemory,
  onOpenVoiceScreen,
}) => {
  const [input, setInput] = useState('');
  const [newMemoryText, setNewMemoryText] = useState('');
  const [newMemoryCat, setNewMemoryCat] = useState<MemoryItem['category']>('Preference');
  const endRef = useRef<HTMLDivElement | null>(null);
  const currentPersona = PERSONAS[persona];

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, isThinking]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || isThinking) return;
    setInput('');
    await onSendMessage(trimmed);
  };

  const handleSaveMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemoryText.trim()) return;
    onAddMemory(newMemoryText.trim(), newMemoryCat);
    setNewMemoryText('');
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Main Conversational Column */}
      <section className="flex flex-col rounded-2xl border border-slate-800/80 bg-[#091024]/85 backdrop-blur-md lg:col-span-8">
        {/* Persona & Language Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 px-5 py-4">
          <div className="flex items-center gap-3.5 min-w-0">
            <PersonaAvatar personaId={persona} size="md" active={isThinking || isSpeaking} />
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="truncate text-lg font-semibold text-white">{currentPersona.name}</h2>
                <span className="text-xs text-slate-400">·</span>
                <span className="truncate text-xs text-cyan-300">{currentPersona.role}</span>
              </div>
              <p className="mt-0.5 truncate text-xs text-slate-400">{currentPersona.voiceLabel}</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Persona Segmented Switcher */}
            <div
              className="flex items-center rounded-lg bg-[#050a18] p-1 border border-slate-800"
              role="group"
              aria-label="Select AI Persona"
            >
              {(['maya', 'friday', 'venom'] as PersonaId[]).map((id) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => onSelectPersona(id)}
                  className={`min-h-[36px] rounded-md px-3 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                    persona === id
                      ? 'bg-cyan-500 text-slate-950'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {PERSONAS[id].name}
                </button>
              ))}
            </div>

            {/* Language Preference Selector */}
            <select
              aria-label="Conversation Language"
              value={languageMode}
              onChange={(e) => onSelectLanguageMode(e.target.value as LanguageMode)}
              className="min-h-[38px] rounded-lg border border-slate-800 bg-[#050a18] px-3 text-xs font-medium text-slate-200 focus:border-cyan-400 focus:outline-none"
            >
              <option value="auto">Auto (EN / HI / Hinglish)</option>
              <option value="hinglish">Hinglish</option>
              <option value="hi">Hindi</option>
              <option value="en">English</option>
            </select>
          </div>
        </div>

        {/* Message Thread */}
        <div className="flex-1 space-y-5 overflow-y-auto px-5 py-5 min-h-[360px] max-h-[540px]">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[88%] rounded-2xl px-4 py-3.5 text-sm leading-relaxed ${
                    isUser
                      ? 'bg-cyan-500/15 text-cyan-50 border border-cyan-500/30'
                      : 'bg-[#0e1730] text-slate-100 border border-slate-800/90'
                  }`}
                >
                  {!isUser && (
                    <div className="mb-1.5 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-medium text-cyan-300">
                          {PERSONAS[msg.persona].name}
                        </span>
                        {msg.activeAgent && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{msg.activeAgent}</span>
                          </>
                        )}
                        {msg.detectedLanguage && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{msg.detectedLanguage}</span>
                          </>
                        )}
                        {msg.usedProvider && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="capitalize">{msg.usedProvider}</span>
                          </>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => onSpeakText(msg.text)}
                        className="inline-flex items-center gap-1 text-slate-400 transition-colors hover:text-cyan-300"
                        title="Read aloud"
                      >
                        <Volume2 className="h-3.5 w-3.5" />
                        <span>Speak</span>
                      </button>
                    </div>
                  )}

                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  {/* Explicit Confirmation Gate for Proposed Phone / Messaging / Remote Actions */}
                  {msg.proposedAction && (
                    <div className="mt-3.5 rounded-xl border border-amber-500/35 bg-[#080f22] p-3.5">
                      <div className="flex items-start gap-2.5">
                        <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-semibold text-amber-300">
                            User Confirmation Required · {msg.proposedAction.type.replace('_', ' ')}
                          </div>
                          <div className="mt-1 text-sm font-medium text-white">
                            {msg.proposedAction.title}
                          </div>
                          <div className="mt-1 text-xs text-slate-300">
                            Target: <span className="text-cyan-200">{msg.proposedAction.target}</span>
                          </div>
                          {msg.proposedAction.payload && (
                            <div className="mt-1.5 rounded-lg bg-[#050915] px-3 py-2 font-mono text-xs text-slate-300">
                              {msg.proposedAction.payload}
                            </div>
                          )}

                          {msg.proposedAction.status === 'pending' ? (
                            <div className="mt-3 flex flex-wrap gap-2">
                              <button
                                type="button"
                                onClick={() => onApproveAction(msg.id)}
                                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-cyan-500 px-3.5 text-xs font-semibold text-slate-950 transition-colors hover:bg-cyan-400"
                              >
                                <Check className="h-3.5 w-3.5" />
                                <span>Approve & Execute</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => onCancelAction(msg.id)}
                                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3.5 text-xs font-medium text-slate-300 transition-colors hover:text-white"
                              >
                                <X className="h-3.5 w-3.5" />
                                <span>Cancel</span>
                              </button>
                            </div>
                          ) : (
                            <div className="mt-2.5 text-xs font-medium text-slate-400">
                              {msg.proposedAction.status === 'approved'
                                ? `Approved and dispatched at ${msg.proposedAction.executedAt ?? 'just now'}`
                                : 'Cancelled by user — no action executed'}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <span className="mt-1 px-1 font-mono text-[11px] tabular-nums text-slate-500">
                  {new Date(msg.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>
            );
          })}

          {isThinking && (
            <div className="flex items-center gap-3 text-xs text-cyan-300">
              <FloatingAiOrb themeId={orbTheme} size="sm" state="thinking" />
              <span>Boss, {currentPersona.name} aapka response taiyaar kar rahi hai...</span>
            </div>
          )}

          {errorMessage && (
            <div
              role="alert"
              className="rounded-xl border border-rose-500/40 bg-rose-950/30 px-4 py-3 text-xs text-rose-200"
            >
              {errorMessage}
            </div>
          )}
          <div ref={endRef} />
        </div>

        {/* Quick Prompt Bar */}
        <div className="border-t border-slate-800/70 px-5 py-3">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {QUICK_PROMPTS.map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => onSendMessage(q)}
                disabled={isThinking}
                className="shrink-0 rounded-lg border border-slate-800 bg-[#060c1d] px-3 py-1.5 text-xs text-slate-300 transition-colors hover:border-cyan-500/50 hover:text-cyan-200 disabled:opacity-50"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Composer */}
        <form
          onSubmit={handleSubmit}
          className="flex items-center gap-2.5 border-t border-slate-800/80 px-5 py-4"
        >
          <button
            type="button"
            onClick={onOpenVoiceScreen}
            aria-label="Open Voice Studio"
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-slate-700/80 bg-[#060c1d] text-cyan-300 transition-colors hover:border-cyan-400 hover:bg-cyan-500/10"
          >
            <Mic className="h-4 w-4" />
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={`Bolo Boss, ${currentPersona.name} se Hinglish ya English mein kuch bhi poocho...`}
            className="h-11 flex-1 rounded-xl border border-slate-800 bg-[#050a17] px-4 text-sm text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
          />

          <button
            type="submit"
            disabled={!input.trim() || isThinking}
            className="inline-flex h-11 shrink-0 items-center gap-2 rounded-xl bg-cyan-500 px-5 text-sm font-semibold text-slate-950 transition-colors hover:bg-cyan-400 disabled:opacity-40"
          >
            <Send className="h-4 w-4" />
            <span>Send</span>
          </button>
        </form>
      </section>

      {/* Right Column: Live Floating Orb Showcase + Long-Term Memory */}
      <aside className="flex flex-col gap-6 lg:col-span-4">
        {/* Interactive Floating AI Orb Panel */}
        <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-white">Floating AI Orb</h3>
              <p className="text-xs text-slate-400">8 switchable galaxy themes</p>
            </div>
            <button
              type="button"
              onClick={onOpenVoiceScreen}
              className="text-xs font-medium text-cyan-400 hover:text-cyan-300 whitespace-nowrap shrink-0"
            >
              Voice Mode
            </button>
          </div>

          <div className="my-4 flex flex-col items-center justify-center rounded-2xl bg-[#050917]/90 py-5">
            <FloatingAiOrb
              themeId={orbTheme}
              size="lg"
              state={isThinking ? 'thinking' : isSpeaking ? 'speaking' : 'idle'}
              onClick={onOpenVoiceScreen}
              ariaLabel="Open Aanya Voice Mode"
            />
            <div className="mt-2 text-xs text-slate-300">
              {ORB_THEME_LIST.find((t) => t.id === orbTheme)?.name}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {ORB_THEME_LIST.map((theme) => {
              const selected = theme.id === orbTheme;
              return (
                <button
                  key={theme.id}
                  type="button"
                  onClick={() => onSelectOrbTheme(theme.id)}
                  className={`flex min-h-[40px] items-center gap-2 rounded-xl border px-3 text-left text-xs font-medium transition-colors ${
                    selected
                      ? 'border-cyan-400/80 bg-cyan-500/15 text-white'
                      : 'border-slate-800 bg-[#060c1c] text-slate-400 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <span
                    className="h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{ backgroundColor: theme.ringPrimary }}
                    aria-hidden="true"
                  />
                  <span className="truncate">{theme.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Long-Term Memory Panel */}
        <div className="flex-1 rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-white">Long-Term Memory</h3>
              <p className="text-xs text-slate-400 tabular-nums">
                {memories.length} stored facts · injected into context
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveMemory} className="mt-4 space-y-2.5">
            <input
              type="text"
              value={newMemoryText}
              onChange={(e) => setNewMemoryText(e.target.value)}
              placeholder="Teach Aanya a preference or fact..."
              className="h-10 w-full rounded-xl border border-slate-800 bg-[#050a17] px-3 text-xs text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
            />
            <div className="flex gap-2">
              <select
                aria-label="Memory Category"
                value={newMemoryCat}
                onChange={(e) => setNewMemoryCat(e.target.value as MemoryItem['category'])}
                className="h-9 flex-1 rounded-lg border border-slate-800 bg-[#050a17] px-2.5 text-xs text-slate-300"
              >
                <option value="Preference">Preference</option>
                <option value="Context">Context</option>
                <option value="Routine">Routine</option>
                <option value="Contact">Contact</option>
              </select>
              <button
                type="submit"
                disabled={!newMemoryText.trim()}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-slate-800 px-3 text-xs font-medium text-cyan-300 transition-colors hover:bg-slate-700 disabled:opacity-40"
              >
                <BookmarkPlus className="h-3.5 w-3.5" />
                <span>Remember</span>
              </button>
            </div>
          </form>

          <ul className="mt-4 space-y-2.5 max-h-[240px] overflow-y-auto pr-1">
            {memories.length === 0 ? (
              <li className="text-xs text-slate-500 py-4 text-center">
                No memories saved yet. Facts you share or save will appear here.
              </li>
            ) : (
              memories.map((mem) => (
                <li
                  key={mem.id}
                  className="flex items-start justify-between gap-2 border-b border-slate-800/70 pb-2.5 last:border-b-0"
                >
                  <div className="min-w-0">
                    <div className="text-[11px] font-medium text-cyan-400">{mem.category}</div>
                    <p className="mt-0.5 text-xs leading-relaxed text-slate-300">{mem.text}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onDeleteMemory(mem.id)}
                    aria-label="Delete memory"
                    className="p-1.5 text-slate-500 transition-colors hover:text-rose-400"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))
            )}
          </ul>
        </div>
      </aside>
    </div>
  );
};
