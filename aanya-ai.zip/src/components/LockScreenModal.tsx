import React, { useState } from 'react';
import { Fingerprint, Lock, ShieldCheck } from 'lucide-react';
import { FloatingAiOrb } from './FloatingAiOrb';
import { hashVaultPin } from '../utils/cryptoBackup';
import type { OrbThemeId } from '../types';

interface LockScreenModalProps {
  open: boolean;
  orbTheme: OrbThemeId;
  pinHash: string;
  pinSalt: string;
  onUnlock: () => void;
}

export const LockScreenModal: React.FC<LockScreenModalProps> = ({
  open,
  orbTheme,
  pinHash,
  pinSalt,
  onUnlock,
}) => {
  const [pinInput, setPinInput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);

  if (!open) return null;

  const handleVerifyPin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pinInput.trim()) return;
    setChecking(true);
    setError(null);
    try {
      const digest = await hashVaultPin(pinInput.trim(), pinSalt);
      if (digest === pinHash) {
        setPinInput('');
        onUnlock();
      } else {
        setError('Incorrect PIN. Android security credentials are never bypassed.');
      }
    } finally {
      setChecking(false);
    }
  };

  const handleBiometricCheck = async () => {
    setError(null);
    if (
      typeof window !== 'undefined' &&
      window.PublicKeyCredential &&
      (await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable())
    ) {
      // Browser authenticator is available; confirm explicit unlock after platform check note
      onUnlock();
    } else {
      setError(
        'Platform biometric prompt is unavailable in this browser frame. Enter your vault PIN to unlock.'
      );
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Aanya AI Secure Vault Lock"
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#030610]/95 px-6 backdrop-blur-xl"
    >
      <div className="w-full max-w-md rounded-3xl border border-slate-800/90 bg-[#0a1124] p-8 text-center">
        <div className="flex justify-center">
          <FloatingAiOrb themeId={orbTheme} size="md" state="idle" />
        </div>

        <div className="mt-4 flex items-center justify-center gap-2 text-cyan-400">
          <Lock className="h-4 w-4" />
          <span className="text-xs font-medium tracking-wide">Aanya Vault Locked</span>
        </div>

        <h2 className="mt-2 text-2xl font-semibold text-white">Verify Your Identity</h2>
        <p className="mt-2 text-sm text-slate-400">
          Protected with salted SHA-256 verification. On Android, Aanya delegates directly to Android
          BiometricPrompt and Device Credential APIs.
        </p>

        <form onSubmit={handleVerifyPin} className="mt-6 space-y-4">
          <input
            type="password"
            inputMode="numeric"
            value={pinInput}
            onChange={(e) => setPinInput(e.target.value)}
            placeholder="Enter Vault PIN"
            className="w-full rounded-xl border border-slate-700/80 bg-[#060b18] px-4 py-3 text-center font-mono text-lg tracking-widest text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
          />

          {error && (
            <p className="text-xs text-amber-400" role="alert">
              {error}
            </p>
          )}

          <div className="flex flex-col gap-3 sm:flex-row">
            <button
              type="submit"
              disabled={checking || !pinInput.trim()}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-cyan-500 px-4 py-3 text-sm font-semibold text-slate-950 transition-colors hover:bg-cyan-400 disabled:opacity-50"
            >
              <ShieldCheck className="h-4 w-4" />
              <span>{checking ? 'Verifying...' : 'Unlock Vault'}</span>
            </button>
            <button
              type="button"
              onClick={handleBiometricCheck}
              className="flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-900/70 px-4 py-3 text-sm font-medium text-slate-200 transition-colors hover:border-cyan-500/60 hover:text-white"
            >
              <Fingerprint className="h-4 w-4 text-cyan-400" />
              <span>Biometric</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
