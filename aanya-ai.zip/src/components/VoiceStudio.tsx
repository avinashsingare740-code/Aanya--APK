import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Mic,
  MicOff,
  Radio,
  ShieldCheck,
  Volume2,
  VolumeX,
  Waves,
} from 'lucide-react';
import { ORB_THEMES, PERSONAS } from '../data/presets';
import { FloatingAiOrb } from './FloatingAiOrb';
import { PersonaAvatar } from './PersonaAvatar';
import type { OrbThemeId, PersonaId, VoiceSettings } from '../types';

interface VoiceStudioProps {
  persona: PersonaId;
  onSelectPersona: (id: PersonaId) => void;
  orbTheme: OrbThemeId;
  voiceSettings: VoiceSettings;
  onUpdateVoiceSettings: (patch: Partial<VoiceSettings>) => void;
  isThinking: boolean;
  isSpeaking: boolean;
  lastAssistantReply: string;
  onVoiceTranscript: (text: string) => Promise<void>;
  onStopSpeaking: () => void;
  onTestSpeak: (text: string) => void;
}

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  0: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: ArrayLike<SpeechRecognitionResultLike>;
}

interface SpeechRecognitionInstanceLike {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((e: SpeechRecognitionEventLike) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

export const VoiceStudio: React.FC<VoiceStudioProps> = ({
  persona,
  onSelectPersona,
  orbTheme,
  voiceSettings,
  onUpdateVoiceSettings,
  isThinking,
  isSpeaking,
  lastAssistantReply,
  onVoiceTranscript,
  onStopSpeaking,
  onTestSpeak,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [interimText, setInterimText] = useState('');
  const [finalTranscript, setFinalTranscript] = useState('');
  const [audioLevel, setAudioLevel] = useState(0);
  const [statusNote, setStatusNote] = useState<string>(
    'Hey Boss, Orb pe tap karo ya Start Listening dabao — Hinglish ya English mein baat karo.'
  );
  const [guardianStatus, setGuardianStatus] = useState<string | null>(null);
  const [enrollingVoiceprint, setEnrollingVoiceprint] = useState(false);

  const recognitionRef = useRef<SpeechRecognitionInstanceLike | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number>(0);
  const currentCentroidRef = useRef<number>(0);

  const stopAudioMeter = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (audioCtxRef.current && audioCtxRef.current.state !== 'closed') {
      audioCtxRef.current.close().catch(() => {});
    }
    audioCtxRef.current = null;
    setAudioLevel(0);
  }, []);

  const startAudioMeter = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const ctx = new AudioContext();
      audioCtxRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      source.connect(analyser);

      const freqData = new Uint8Array(analyser.frequencyBinCount);
      const sampleRate = ctx.sampleRate;

      const tick = () => {
        analyser.getByteFrequencyData(freqData);
        let sum = 0;
        let weightedSum = 0;
        for (let i = 0; i < freqData.length; i++) {
          const val = freqData[i];
          sum += val;
          weightedSum += val * ((i * sampleRate) / (2 * freqData.length));
        }
        const avg = sum / freqData.length;
        setAudioLevel(Math.min(1, avg / 95));
        if (sum > 250) {
          currentCentroidRef.current = Math.round(weightedSum / sum);
        }
        rafRef.current = requestAnimationFrame(tick);
      };
      tick();
    } catch {
      setStatusNote(
        'Microphone permission is required for live waveform and Voice Guardian calibration.'
      );
    }
  }, []);

  const stopListening = useCallback(() => {
    setIsListening(false);
    try {
      recognitionRef.current?.stop();
    } catch {
      // ignore
    }
    recognitionRef.current = null;
    stopAudioMeter();
  }, [stopAudioMeter]);

  // Echo Guard: suspend recognition while Aanya is speaking so she never triggers herself
  useEffect(() => {
    if (voiceSettings.echoGuardEnabled && isSpeaking && isListening) {
      setStatusNote('Echo Guard paused microphone capture while Aanya speaks.');
      try {
        recognitionRef.current?.abort();
      } catch {
        // ignore
      }
    }
  }, [isSpeaking, isListening, voiceSettings.echoGuardEnabled]);

  useEffect(() => {
    return () => {
      stopListening();
    };
  }, [stopListening]);

  const startListening = async () => {
    if (isListening) {
      stopListening();
      setStatusNote('Microphone stopped.');
      return;
    }

    const SpeechRecCtor =
      (window as unknown as { SpeechRecognition?: new () => SpeechRecognitionInstanceLike })
        .SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognitionInstanceLike })
        .webkitSpeechRecognition;

    if (!SpeechRecCtor) {
      setStatusNote(
        'Web Speech Recognition is unavailable in this browser. Use Chrome/Edge or chat directly in the Chat screen.'
      );
      return;
    }

    await startAudioMeter();

    const recognition = new SpeechRecCtor();
    recognition.continuous = voiceSettings.continuousMode;
    recognition.interimResults = true;
    recognition.lang = voiceSettings.speechLocale;

    recognition.onresult = (event) => {
      if (voiceSettings.echoGuardEnabled && isSpeaking) {
        return;
      }

      let interim = '';
      let finalChunk = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        const transcript = res[0]?.transcript ?? '';
        if (res.isFinal) {
          finalChunk += transcript;
        } else {
          interim += transcript;
        }
      }

      setInterimText(interim);

      if (finalChunk.trim()) {
        const cleaned = finalChunk.trim();
        setFinalTranscript(cleaned);
        setInterimText('');

        // Voice Guardian speaker profile verification
        if (voiceSettings.voiceGuardianEnabled && voiceSettings.voiceprintCentroidHz) {
          const observed = currentCentroidRef.current || voiceSettings.voiceprintCentroidHz;
          const delta = Math.abs(observed - voiceSettings.voiceprintCentroidHz);
          if (delta > 1100) {
            setGuardianStatus(
              `Voice Guardian flagged acoustic mismatch (${observed} Hz vs enrolled ${voiceSettings.voiceprintCentroidHz} Hz). Command held for safety.`
            );
            return;
          }
          setGuardianStatus(`Voice Guardian verified speaker profile (${observed} Hz).`);
        }

        // Wake word check
        if (voiceSettings.wakeWordEnabled) {
          const lower = cleaned.toLowerCase();
          const hasWake =
            lower.includes('hey aanya') ||
            lower.includes('hey anya') ||
            lower.includes('हे आन्या');
          if (!hasWake) {
            setStatusNote(
              `Heard "${cleaned}" — waiting for wake phrase "Hey Aanya" before responding.`
            );
            return;
          }
          const stripped = cleaned.replace(/hey\s+a+nya|हे\s+आन्या/gi, '').trim() || cleaned;
          setStatusNote(`Wake word detected. Sending to ${PERSONAS[persona].name}...`);
          void onVoiceTranscript(stripped);
        } else {
          setStatusNote(`Processing voice request with ${PERSONAS[persona].name}...`);
          void onVoiceTranscript(cleaned);
        }
      }
    };

    recognition.onerror = (e) => {
      if (e.error !== 'aborted') {
        setStatusNote(`Speech recognition notice: ${e.error}`);
      }
    };

    recognition.onend = () => {
      if (voiceSettings.continuousMode && recognitionRef.current && !isSpeaking) {
        try {
          recognition.start();
          return;
        } catch {
          // fall through
        }
      }
      setIsListening(false);
    };

    recognitionRef.current = recognition;
    setIsListening(true);
    setStatusNote(
      voiceSettings.wakeWordEnabled
        ? 'Listening for "Hey Aanya"...'
        : `Listening in ${voiceSettings.speechLocale}...`
    );
    try {
      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  const handleEnrollVoiceGuardian = async () => {
    setEnrollingVoiceprint(true);
    setGuardianStatus('Say "Hey Aanya, verify my voice" for 3 seconds...');
    await startAudioMeter();
    setTimeout(() => {
      const captured = currentCentroidRef.current || 1420;
      onUpdateVoiceSettings({
        voiceGuardianEnabled: true,
        voiceprintCentroidHz: captured,
      });
      setGuardianStatus(`Speaker acoustic profile enrolled at ${captured} Hz.`);
      setEnrollingVoiceprint(false);
      if (!isListening) stopAudioMeter();
    }, 3000);
  };

  const orbState = isThinking
    ? 'thinking'
    : isSpeaking
      ? 'speaking'
      : isListening
        ? 'listening'
        : 'idle';

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Center Reactive Orb Stage */}
      <section className="flex flex-col items-center justify-between rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-6 text-center backdrop-blur-md lg:col-span-7">
        <div className="flex w-full flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div className="flex items-center gap-3 text-left">
            <PersonaAvatar personaId={persona} size="sm" active={isSpeaking || isListening} />
            <div>
              <h2 className="text-base font-semibold text-white">
                {PERSONAS[persona].name} Voice Studio
              </h2>
              <p className="text-xs text-slate-400">
                {ORB_THEMES[orbTheme].name} · {voiceSettings.useNeuralTts ? 'Gemini Neural TTS' : 'Browser TTS'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 rounded-lg border border-slate-800 bg-[#050a18] p-1">
            {(['maya', 'friday', 'venom'] as PersonaId[]).map((id) => (
              <button
                key={id}
                type="button"
                onClick={() => onSelectPersona(id)}
                className={`min-h-[36px] rounded-md px-3 text-xs font-medium transition-colors ${
                  persona === id ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'
                }`}
              >
                {PERSONAS[id].name}
              </button>
            ))}
          </div>
        </div>

        {/* Giant Orb */}
        <div className="my-8 flex flex-col items-center">
          <FloatingAiOrb
            themeId={orbTheme}
            size="xl"
            state={orbState}
            audioLevel={audioLevel}
            onClick={startListening}
            ariaLabel={isListening ? 'Stop listening' : 'Start listening'}
          />

          <p className="mt-4 max-w-md text-sm text-cyan-200">{statusNote}</p>

          {(interimText || finalTranscript) && (
            <div className="mt-4 w-full max-w-lg rounded-xl border border-slate-800 bg-[#050a17] px-4 py-3 text-left">
              <div className="text-[11px] font-medium text-slate-500">Captured Speech</div>
              <p className="mt-1 text-sm text-white">
                {interimText || finalTranscript}
              </p>
            </div>
          )}

          {lastAssistantReply && (
            <div className="mt-3 w-full max-w-lg rounded-xl border border-cyan-500/20 bg-cyan-950/20 px-4 py-3 text-left">
              <div className="text-[11px] font-medium text-cyan-400">
                Latest {PERSONAS[persona].name} Response
              </div>
              <p className="mt-1 text-xs leading-relaxed text-slate-200 line-clamp-4">
                {lastAssistantReply}
              </p>
            </div>
          )}
        </div>

        {/* Primary Voice Controls */}
        <div className="flex flex-wrap items-center justify-center gap-3">
          <button
            type="button"
            onClick={startListening}
            className={`inline-flex min-h-[46px] items-center gap-2 rounded-xl px-6 text-sm font-semibold transition-colors ${
              isListening
                ? 'bg-rose-500 text-white hover:bg-rose-400'
                : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400'
            }`}
          >
            {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            <span>{isListening ? 'Stop Listening' : 'Start Listening'}</span>
          </button>

          {isSpeaking ? (
            <button
              type="button"
              onClick={onStopSpeaking}
              className="inline-flex min-h-[46px] items-center gap-2 rounded-xl border border-amber-500/50 bg-amber-500/15 px-5 text-sm font-medium text-amber-200 hover:bg-amber-500/25"
            >
              <VolumeX className="h-4 w-4" />
              <span>Mute Speech</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onTestSpeak(PERSONAS[persona].greeting)}
              className="inline-flex min-h-[46px] items-center gap-2 rounded-xl border border-slate-700 bg-[#060c1d] px-5 text-sm font-medium text-slate-200 hover:border-cyan-400 hover:text-white"
            >
              <Volume2 className="h-4 w-4 text-cyan-400" />
              <span>Test {PERSONAS[persona].name} Voice</span>
            </button>
          )}
        </div>
      </section>

      {/* Right Column: Voice Engine, Echo Guard & Voice Guardian Controls */}
      <aside className="space-y-5 lg:col-span-5">
        <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 backdrop-blur-md">
          <h3 className="text-base font-semibold text-white">Voice Activation & Guard Controls</h3>
          <p className="mt-1 text-xs text-slate-400">
            Configure multilingual recognition, Echo Guard self-trigger protection, and Android
            foreground voice behavior.
          </p>

          <div className="mt-5 space-y-4">
            <div>
              <label
                htmlFor="speech-locale"
                className="block text-xs font-medium text-slate-300"
              >
                Speech Recognition Locale
              </label>
              <select
                id="speech-locale"
                value={voiceSettings.speechLocale}
                onChange={(e) =>
                  onUpdateVoiceSettings({
                    speechLocale: e.target.value as VoiceSettings['speechLocale'],
                  })
                }
                className="mt-1.5 h-10 w-full rounded-xl border border-slate-800 bg-[#050a17] px-3 text-xs text-white focus:border-cyan-400 focus:outline-none"
              >
                <option value="en-IN">English + Hinglish (India · en-IN)</option>
                <option value="hi-IN">Hindi (Devanagari · hi-IN)</option>
                <option value="en-US">English (International · en-US)</option>
              </select>
            </div>

            {[
              {
                key: 'useNeuralTts' as const,
                title: 'Natural Neural Voice (Gemini 3.8 TTS)',
                desc: 'Synthesizes human-like studio voices for Aanya, Friday, and Venom.',
              },
              {
                key: 'autoSpeakReplies' as const,
                title: 'Auto-Speak Assistant Replies',
                desc: 'Automatically read responses aloud when conversing.',
              },
              {
                key: 'wakeWordEnabled' as const,
                title: 'Require "Hey Aanya" Wake Word',
                desc: 'Ignores ambient speech until "Hey Aanya" or "हे आन्या" is spoken.',
              },
              {
                key: 'continuousMode' as const,
                title: 'Continuous Conversation Mode',
                desc: 'Keeps listening seamlessly after each response.',
              },
              {
                key: 'echoGuardEnabled' as const,
                title: 'Echo Guard Anti-Self-Trigger',
                desc: 'Suspends microphone recognition while Aanya speaks.',
              },
            ].map((item) => (
              <div
                key={item.key}
                className="flex items-start justify-between gap-4 border-t border-slate-800/70 pt-3.5"
              >
                <div>
                  <div className="text-sm font-medium text-slate-100">{item.title}</div>
                  <p className="mt-0.5 text-xs text-slate-400">{item.desc}</p>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={voiceSettings[item.key]}
                  onClick={() =>
                    onUpdateVoiceSettings({ [item.key]: !voiceSettings[item.key] })
                  }
                  className={`relative mt-0.5 h-6 w-11 shrink-0 rounded-full transition-colors ${
                    voiceSettings[item.key] ? 'bg-cyan-500' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`block h-4 w-4 translate-y-1 rounded-full bg-slate-950 transition-transform ${
                      voiceSettings[item.key] ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Voice Guardian Speaker Profile */}
        <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 backdrop-blur-md">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-cyan-400" />
              <h3 className="text-base font-semibold text-white">Voice Guardian</h3>
            </div>
            <span className="font-mono text-xs tabular-nums text-slate-400">
              {voiceSettings.voiceprintCentroidHz
                ? `${voiceSettings.voiceprintCentroidHz} Hz enrolled`
                : 'Not enrolled'}
            </span>
          </div>
          <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
            Optional acoustic speaker verification that checks your voice centroid before approving
            spoken commands. Stored locally only.
          </p>

          {guardianStatus && (
            <p className="mt-3 rounded-lg bg-[#050a17] px-3 py-2 text-xs text-cyan-200">
              {guardianStatus}
            </p>
          )}

          <div className="mt-4 flex flex-wrap gap-2.5">
            <button
              type="button"
              onClick={handleEnrollVoiceGuardian}
              disabled={enrollingVoiceprint}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-xl bg-slate-800 px-4 text-xs font-medium text-cyan-300 transition-colors hover:bg-slate-700 disabled:opacity-50"
            >
              <Waves className="h-3.5 w-3.5" />
              <span>{enrollingVoiceprint ? 'Sampling Voice...' : 'Enroll Voice Profile'}</span>
            </button>

            <button
              type="button"
              onClick={() =>
                onUpdateVoiceSettings({
                  voiceGuardianEnabled: !voiceSettings.voiceGuardianEnabled,
                })
              }
              className="inline-flex min-h-[40px] items-center gap-2 rounded-xl border border-slate-700 px-4 text-xs font-medium text-slate-300 hover:border-cyan-500/60 hover:text-white"
            >
              <Radio className="h-3.5 w-3.5" />
              <span>
                {voiceSettings.voiceGuardianEnabled ? 'Disable Guardian' : 'Enable Guardian'}
              </span>
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
};
