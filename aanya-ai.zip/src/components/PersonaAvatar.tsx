import React, { useState } from 'react';
import { PERSONAS } from '../data/presets';
import type { PersonaId } from '../types';

interface PersonaAvatarProps {
  personaId: PersonaId;
  size?: 'sm' | 'md' | 'lg';
  active?: boolean;
}

const SIZE_CLASSES = {
  sm: 'w-10 h-10',
  md: 'w-14 h-14',
  lg: 'w-24 h-24',
};

export const PersonaAvatar: React.FC<PersonaAvatarProps> = ({
  personaId,
  size = 'md',
  active = false,
}) => {
  const persona = PERSONAS[personaId];
  const [imgFailed, setImgFailed] = useState(false);

  const ringClass = active
    ? 'ring-2 ring-cyan-400/80 shadow-[0_0_24px_rgba(34,211,238,0.35)]'
    : 'ring-1 ring-slate-700/80';

  return (
    <div
      className={`relative shrink-0 overflow-hidden rounded-2xl bg-[#070d1f] ${SIZE_CLASSES[size]} ${ringClass} transition-all duration-200`}
    >
      {persona.avatarPath && !imgFailed ? (
        <img
          src={persona.avatarPath}
          alt={`${persona.name} — ${persona.role}`}
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className="h-full w-full object-cover"
        />
      ) : (
        /* Bespoke sculptural obsidian-cyan cosmic crest for Venom (and resilient fallback) */
        <div className="relative flex h-full w-full items-center justify-center bg-gradient-to-br from-[#020617] via-[#0a162c] to-[#083344]">
          <svg
            viewBox="0 0 100 100"
            className="h-full w-full"
            aria-label={`${persona.name} holographic avatar`}
          >
            <defs>
              <radialGradient id={`venomGlow-${size}`} cx="50%" cy="42%" r="55%">
                <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.45" />
                <stop offset="60%" stopColor="#0e7490" stopOpacity="0.18" />
                <stop offset="100%" stopColor="#020617" stopOpacity="0" />
              </radialGradient>
            </defs>
            <rect width="100" height="100" fill={`url(#venomGlow-${size})`} />
            {/* Obsidian crest silhouette */}
            <path
              d="M50 14 C68 14 78 28 76 48 C74 68 62 84 50 88 C38 84 26 68 24 48 C22 28 32 14 50 14 Z"
              fill="#050b18"
              stroke="#06b6d4"
              strokeWidth="1.6"
              strokeOpacity="0.7"
            />
            {/* Bioluminescent cosmic eyes */}
            <path
              d="M31 44 Q39 39 45 48 Q38 51 31 44 Z"
              fill="#67e8f9"
            />
            <path
              d="M69 44 Q61 39 55 48 Q62 51 69 44 Z"
              fill="#67e8f9"
            />
            {/* Energy veins */}
            <path
              d="M50 20 L50 38 M34 62 Q50 72 66 62 M26 50 Q38 58 50 56 Q62 58 74 50"
              fill="none"
              stroke="#22d3ee"
              strokeWidth="1.2"
              strokeOpacity="0.55"
            />
          </svg>
        </div>
      )}
    </div>
  );
};
