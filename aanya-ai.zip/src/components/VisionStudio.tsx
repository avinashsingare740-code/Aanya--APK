import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Camera,
  CameraOff,
  Eye,
  FileText,
  Monitor,
  ScanSearch,
  Shield,
  Upload,
} from 'lucide-react';
import type { PersonaId } from '../types';

interface VisionStudioProps {
  persona: PersonaId;
  onSpeakText: (text: string) => void;
}

interface VisionAnalysisResult {
  summary: string;
  extractedText: string;
  detectedObjects: string[];
  sensitiveInfoDetected: boolean;
  privacyNotice: string;
}

export const VisionStudio: React.FC<VisionStudioProps> = ({ persona, onSpeakText }) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [sourceKind, setSourceKind] = useState<'none' | 'camera' | 'screen' | 'upload'>('none');
  const [uploadedPreview, setUploadedPreview] = useState<string | null>(null);
  const [uploadedBase64, setUploadedBase64] = useState<{ data: string; mimeType: string } | null>(
    null
  );
  const [privacyShield, setPrivacyShield] = useState(true);
  const [customPrompt, setCustomPrompt] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<VisionAnalysisResult | null>(null);

  const stopStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  useEffect(() => {
    return () => stopStream();
  }, [stopStream]);

  const startCamera = async () => {
    setError(null);
    stopStream();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      setSourceKind('camera');
      setUploadedPreview(null);
      setUploadedBase64(null);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
    } catch {
      setError(
        'Camera access was denied or unavailable. You can upload an image instead to test Vision Agent.'
      );
    }
  };

  const startScreenVision = async () => {
    setError(null);
    stopStream();
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: false,
      });
      streamRef.current = stream;
      setSourceKind('screen');
      setUploadedPreview(null);
      setUploadedBase64(null);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      stream.getVideoTracks()[0].onended = () => {
        setSourceKind('none');
      };
    } catch {
      setError(
        'Screen capture consent was cancelled or is restricted in this frame. Upload a screenshot to inspect Screen Vision.'
      );
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    stopStream();
    setError(null);
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || '');
      const commaIdx = dataUrl.indexOf(',');
      if (commaIdx > 0) {
        setUploadedPreview(dataUrl);
        setUploadedBase64({
          data: dataUrl.slice(commaIdx + 1),
          mimeType: file.type || 'image/jpeg',
        });
        setSourceKind('upload');
      }
    };
    reader.readAsDataURL(file);
  };

  const captureCurrentImage = (): { imageBase64: string; mimeType: string } | null => {
    if (sourceKind === 'upload' && uploadedBase64) {
      return { imageBase64: uploadedBase64.data, mimeType: uploadedBase64.mimeType };
    }
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.videoWidth === 0) return null;

    canvas.width = Math.min(video.videoWidth, 1280);
    canvas.height = Math.round((video.videoHeight / video.videoWidth) * canvas.width);
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    return {
      imageBase64: dataUrl.split(',')[1],
      mimeType: 'image/jpeg',
    };
  };

  const runAnalysis = async (
    mode: 'scene' | 'ocr' | 'objects' | 'screen_explain' | 'custom'
  ) => {
    const captured = captureCurrentImage();
    if (!captured) {
      setError('Start your camera, share your screen, or upload an image first.');
      return;
    }

    setAnalyzing(true);
    setError(null);
    try {
      const res = await fetch('/api/vision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: captured.imageBase64,
          mimeType: captured.mimeType,
          mode,
          prompt: customPrompt.trim() || undefined,
          persona,
          privacyShield,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Vision analysis failed.');
      }
      setResult(data as VisionAnalysisResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Vision request failed.');
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Live Camera / Screen Viewport */}
      <section className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 backdrop-blur-md lg:col-span-7">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold text-white">Camera Vision & Screen Vision</h2>
            <p className="text-xs text-slate-400">
              Live object recognition, Hindi/English OCR, and MediaProjection screen understanding
            </p>
          </div>

          <button
            type="button"
            onClick={() => setPrivacyShield((p) => !p)}
            className={`inline-flex min-h-[38px] items-center gap-2 rounded-xl border px-3.5 text-xs font-medium transition-colors ${
              privacyShield
                ? 'border-cyan-400/70 bg-cyan-500/15 text-cyan-200'
                : 'border-slate-700 bg-[#060c1c] text-slate-400'
            }`}
          >
            <Shield className="h-3.5 w-3.5" />
            <span>Privacy Shield: {privacyShield ? 'Active' : 'Off'}</span>
          </button>
        </div>

        {/* Source Action Row */}
        <div className="mt-4 flex flex-wrap gap-2.5">
          <button
            type="button"
            onClick={sourceKind === 'camera' ? () => { stopStream(); setSourceKind('none'); } : startCamera}
            className="inline-flex min-h-[42px] items-center gap-2 rounded-xl bg-cyan-500 px-4 text-xs font-semibold text-slate-950 transition-colors hover:bg-cyan-400"
          >
            {sourceKind === 'camera' ? <CameraOff className="h-4 w-4" /> : <Camera className="h-4 w-4" />}
            <span>{sourceKind === 'camera' ? 'Stop Camera' : 'Start Live Camera'}</span>
          </button>

          <button
            type="button"
            onClick={sourceKind === 'screen' ? () => { stopStream(); setSourceKind('none'); } : startScreenVision}
            className="inline-flex min-h-[42px] items-center gap-2 rounded-xl border border-slate-700 bg-[#060c1d] px-4 text-xs font-medium text-slate-200 transition-colors hover:border-cyan-400 hover:text-white"
          >
            <Monitor className="h-4 w-4 text-cyan-400" />
            <span>{sourceKind === 'screen' ? 'Stop Screen Scan' : 'Screen Vision (Consent)'}</span>
          </button>

          <label className="inline-flex min-h-[42px] cursor-pointer items-center gap-2 rounded-xl border border-slate-700 bg-[#060c1d] px-4 text-xs font-medium text-slate-200 transition-colors hover:border-cyan-400 hover:text-white">
            <Upload className="h-4 w-4 text-cyan-400" />
            <span>Upload Image</span>
            <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
          </label>
        </div>

        {/* Preview Stage */}
        <div className="relative mt-4 aspect-video w-full overflow-hidden rounded-2xl border border-slate-800 bg-[#040712]">
          <video
            ref={videoRef}
            playsInline
            muted
            className={`h-full w-full object-cover ${
              sourceKind === 'camera' || sourceKind === 'screen' ? 'block' : 'hidden'
            }`}
          />

          {sourceKind === 'upload' && uploadedPreview && (
            <img
              src={uploadedPreview}
              alt="Uploaded frame for Aanya Vision analysis"
              referrerPolicy="no-referrer"
              className="h-full w-full object-contain"
            />
          )}

          {sourceKind === 'none' && (
            <div className="flex h-full flex-col items-center justify-center p-6 text-center">
              <Eye className="h-10 w-10 text-cyan-500/60" />
              <p className="mt-3 text-sm font-medium text-slate-200">
                No active camera or screen feed
              </p>
              <p className="mt-1 max-w-sm text-xs text-slate-500">
                Enable Live Camera, grant one-session Screen Vision consent, or upload a photo to
                analyze objects, read text, or explain what is on screen.
              </p>
            </div>
          )}

          <canvas ref={canvasRef} className="hidden" />
        </div>

        {/* Camera Conversation Question */}
        <div className="mt-4 flex flex-col gap-3 sm:flex-row">
          <input
            type="text"
            value={customPrompt}
            onChange={(e) => setCustomPrompt(e.target.value)}
            placeholder="Ask Aanya about what she sees (English, Hindi, or Hinglish)..."
            className="h-11 flex-1 rounded-xl border border-slate-800 bg-[#050a17] px-4 text-sm text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
          />
          <button
            type="button"
            disabled={analyzing || sourceKind === 'none'}
            onClick={() => runAnalysis('custom')}
            className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-cyan-500 px-5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 disabled:opacity-40"
          >
            <ScanSearch className="h-4 w-4" />
            <span>{analyzing ? 'Analyzing...' : 'Ask Vision'}</span>
          </button>
        </div>

        {/* Quick Mode Buttons */}
        <div className="mt-3 flex flex-wrap gap-2">
          {[
            { id: 'scene' as const, label: 'Understand Scene' },
            { id: 'objects' as const, label: 'Recognize Objects' },
            { id: 'ocr' as const, label: 'Read Text (OCR)' },
            { id: 'screen_explain' as const, label: 'Explain Screen' },
          ].map((btn) => (
            <button
              key={btn.id}
              type="button"
              disabled={analyzing || sourceKind === 'none'}
              onClick={() => runAnalysis(btn.id)}
              className="min-h-[38px] rounded-xl border border-slate-800 bg-[#060c1d] px-3.5 text-xs font-medium text-slate-300 transition-colors hover:border-cyan-500/60 hover:text-cyan-200 disabled:opacity-40"
            >
              {btn.label}
            </button>
          ))}
        </div>

        {error && (
          <p role="alert" className="mt-3 text-xs text-amber-300">
            {error}
          </p>
        )}
      </section>

      {/* Right Column: Structured Vision Analysis Output */}
      <aside className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 backdrop-blur-md lg:col-span-5">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3.5">
          <div>
            <h3 className="text-base font-semibold text-white">Vision Agent Findings</h3>
            <p className="text-xs text-slate-400">Multimodal analysis with automatic privacy protection</p>
          </div>
          {result?.summary && (
            <button
              type="button"
              onClick={() => onSpeakText(result.summary)}
              className="text-xs font-medium text-cyan-400 hover:text-cyan-300 whitespace-nowrap shrink-0"
            >
              Speak Summary
            </button>
          )}
        </div>

        {!result ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <FileText className="h-8 w-8 text-slate-600" />
            <p className="mt-3 text-sm text-slate-300">Ready to inspect a frame</p>
            <p className="mt-1 max-w-xs text-xs text-slate-500">
              Capture from Camera, Screen Vision, or upload a photo. Sensitive credentials or OTPs
              are automatically redacted when Privacy Shield is active.
            </p>
          </div>
        ) : (
          <div className="mt-4 space-y-5">
            {result.sensitiveInfoDetected && (
              <div className="rounded-xl border border-amber-500/40 bg-amber-950/30 p-3.5 text-xs text-amber-200">
                <div className="font-semibold text-amber-300">Privacy Shield Alert</div>
                <p className="mt-1">{result.privacyNotice}</p>
              </div>
            )}

            <div>
              <h4 className="text-xs font-medium text-cyan-400">Scene & Screen Summary</h4>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-200">{result.summary}</p>
            </div>

            {result.detectedObjects?.length > 0 && (
              <div className="border-t border-slate-800/80 pt-4">
                <h4 className="text-xs font-medium text-cyan-400">Detected Objects</h4>
                <p className="mt-1.5 text-xs leading-relaxed text-slate-300">
                  {result.detectedObjects.join(' · ')}
                </p>
              </div>
            )}

            {result.extractedText && (
              <div className="border-t border-slate-800/80 pt-4">
                <h4 className="text-xs font-medium text-cyan-400">Extracted Text (OCR)</h4>
                <pre className="mt-2 max-h-56 overflow-y-auto whitespace-pre-wrap rounded-xl bg-[#050a17] p-3.5 font-mono text-xs text-slate-300">
                  {result.extractedText}
                </pre>
              </div>
            )}
          </div>
        )}
      </aside>
    </div>
  );
};
