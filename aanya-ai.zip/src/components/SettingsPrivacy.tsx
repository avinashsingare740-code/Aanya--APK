import React, { useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Download,
  Lock,
  ShieldCheck,
  Trash2,
  Upload,
} from 'lucide-react';
import { ORB_THEME_LIST } from '../data/presets';
import { FloatingAiOrb } from './FloatingAiOrb';
import {
  decryptBackupPayload,
  encryptBackupPayload,
  generateSaltHex,
  hashVaultPin,
  type EncryptedBackupEnvelope,
} from '../utils/cryptoBackup';
import type {
  AanyaAppStateBackup,
  AndroidPermissionItem,
  OrbThemeId,
  ProviderId,
  ProviderStatus,
} from '../types';

interface SettingsPrivacyProps {
  orbTheme: OrbThemeId;
  onSelectOrbTheme: (id: OrbThemeId) => void;
  providers: ProviderStatus[];
  providerOrder: ProviderId[];
  autoFallback: boolean;
  onChangeProviderOrder: (order: ProviderId[]) => void;
  onToggleAutoFallback: () => void;
  permissions: AndroidPermissionItem[];
  onTogglePermission: (id: string) => void;
  backupSnapshot: AanyaAppStateBackup;
  onRestoreBackup: (restored: AanyaAppStateBackup) => void;
  onEraseAllData: () => void;
  hasVaultPin: boolean;
  onSetVaultPin: (pinHash: string, pinSalt: string) => void;
  onLockNow: () => void;
}

export const SettingsPrivacy: React.FC<SettingsPrivacyProps> = ({
  orbTheme,
  onSelectOrbTheme,
  providers,
  providerOrder,
  autoFallback,
  onChangeProviderOrder,
  onToggleAutoFallback,
  permissions,
  onTogglePermission,
  backupSnapshot,
  onRestoreBackup,
  onEraseAllData,
  hasVaultPin,
  onSetVaultPin,
  onLockNow,
}) => {
  const [backupPassphrase, setBackupPassphrase] = useState('');
  const [restorePassphrase, setRestorePassphrase] = useState('');
  const [pendingRestoreFile, setPendingRestoreFile] = useState<EncryptedBackupEnvelope | null>(null);
  const [backupMessage, setBackupMessage] = useState<string | null>(null);
  const [newPin, setNewPin] = useState('');
  const [pinSavedMsg, setPinSavedMsg] = useState<string | null>(null);
  const [confirmErase, setConfirmErase] = useState(false);

  const moveProvider = (index: number, direction: -1 | 1) => {
    const nextIdx = index + direction;
    if (nextIdx < 0 || nextIdx >= providerOrder.length) return;
    const copy = [...providerOrder];
    [copy[index], copy[nextIdx]] = [copy[nextIdx], copy[index]];
    onChangeProviderOrder(copy);
  };

  const handleExportEncryptedBackup = async () => {
    setBackupMessage(null);
    try {
      const envelope = await encryptBackupPayload(backupSnapshot, backupPassphrase);
      const blob = new Blob([JSON.stringify(envelope, null, 2)], {
        type: 'application/json;charset=utf-8',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `aanya-memory-backup-${new Date().toISOString().slice(0, 10)}.aanya.enc.json`;
      a.click();
      URL.revokeObjectURL(url);
      setBackupMessage('AES-256-GCM encrypted backup downloaded successfully.');
      setBackupPassphrase('');
    } catch (err) {
      setBackupMessage(err instanceof Error ? err.message : 'Backup encryption failed.');
    }
  };

  const handleLoadBackupFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result || '')) as EncryptedBackupEnvelope;
        setPendingRestoreFile(parsed);
        setBackupMessage(`Loaded "${file.name}". Enter passphrase to decrypt and restore.`);
      } catch {
        setBackupMessage('Selected file is not a valid JSON backup envelope.');
      }
    };
    reader.readAsText(file);
  };

  const handleDecryptAndRestore = async () => {
    if (!pendingRestoreFile) return;
    setBackupMessage(null);
    try {
      const restored = await decryptBackupPayload(pendingRestoreFile, restorePassphrase);
      onRestoreBackup(restored);
      setPendingRestoreFile(null);
      setRestorePassphrase('');
      setBackupMessage('Backup decrypted and restored across conversations, memories, and skills.');
    } catch (err) {
      setBackupMessage(err instanceof Error ? err.message : 'Restore failed.');
    }
  };

  const handleSaveVaultPin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.trim().length < 4) {
      setPinSavedMsg('PIN must be at least 4 digits.');
      return;
    }
    const salt = generateSaltHex();
    const hash = await hashVaultPin(newPin.trim(), salt);
    onSetVaultPin(hash, salt);
    setNewPin('');
    setPinSavedMsg('Salted SHA-256 vault PIN updated. Plaintext PIN is never stored.');
  };

  return (
    <div className="space-y-6">
      {/* 8 Floating AI Orb Themes Gallery */}
      <section className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-lg font-semibold text-white">Floating AI Orb Themes</h2>
            <p className="text-xs text-slate-400">
              Select any of the 8 signature themes for Aanya&apos;s interactive orb and Android overlay.
            </p>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {ORB_THEME_LIST.map((theme) => {
            const active = theme.id === orbTheme;
            return (
              <button
                key={theme.id}
                type="button"
                onClick={() => onSelectOrbTheme(theme.id)}
                className={`flex items-center gap-3.5 rounded-2xl border p-3.5 text-left transition-colors ${
                  active
                    ? 'border-cyan-400/80 bg-cyan-500/12'
                    : 'border-slate-800 bg-[#060c1d] hover:border-slate-700'
                }`}
              >
                <FloatingAiOrb themeId={theme.id} size="sm" state={active ? 'speaking' : 'idle'} />
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-white">{theme.name}</div>
                  <p className="mt-0.5 text-[11px] leading-snug text-slate-400 line-clamp-2">
                    {theme.description}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Multi-Provider AI Routing & Automatic Fallback */}
        <section className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 lg:col-span-6">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-semibold text-white">
                Multi-Provider AI Brain & Fallback
              </h3>
              <p className="mt-0.5 text-xs text-slate-400">
                Server-managed keys via secure environment configuration (never exposed to browser).
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={autoFallback}
              onClick={onToggleAutoFallback}
              className="inline-flex min-h-[36px] shrink-0 items-center gap-2 rounded-lg border border-slate-700 bg-[#060c1d] px-3 text-xs font-medium text-slate-200"
            >
              <span>Auto-Fallback: {autoFallback ? 'On' : 'Off'}</span>
            </button>
          </div>

          <ul className="mt-4 divide-y divide-slate-800/70">
            {providerOrder.map((id, idx) => {
              const info = providers.find((p) => p.id === id);
              return (
                <li
                  key={id}
                  className="flex items-center justify-between gap-3 py-3"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-slate-500">0{idx + 1}.</span>
                      <span className="text-sm font-medium text-white">
                        {info?.name || id}
                      </span>
                      <span className="text-xs text-slate-500">·</span>
                      <span
                        className={`text-xs ${
                          info?.configured ? 'text-cyan-400' : 'text-slate-500'
                        }`}
                      >
                        {info?.configured ? 'Active on Server' : 'Fallback Ready'}
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs text-slate-400">
                      {info?.model} · {info?.role}
                    </p>
                  </div>

                  <div className="flex shrink-0 items-center gap-1">
                    <button
                      type="button"
                      onClick={() => moveProvider(idx, -1)}
                      disabled={idx === 0}
                      aria-label={`Move ${id} up`}
                      className="p-2 text-slate-400 hover:text-white disabled:opacity-30"
                    >
                      <ArrowUp className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => moveProvider(idx, 1)}
                      disabled={idx === providerOrder.length - 1}
                      aria-label={`Move ${id} down`}
                      className="p-2 text-slate-400 hover:text-white disabled:opacity-30"
                    >
                      <ArrowDown className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        {/* Encrypted Memory Backup, Restore & Secure Vault Lock */}
        <section className="space-y-6 lg:col-span-6">
          <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-cyan-400" />
              <h3 className="text-base font-semibold text-white">
                Encrypted Memory Backup & Restore
              </h3>
            </div>
            <p className="mt-1 text-xs text-slate-400">
              Encrypts conversations, long-term memory, skills, and preferences locally using PBKDF2-SHA256 + AES-256-GCM before export.
            </p>

            <div className="mt-4 flex flex-col gap-2.5 sm:flex-row">
              <input
                type="password"
                value={backupPassphrase}
                onChange={(e) => setBackupPassphrase(e.target.value)}
                placeholder="Backup passphrase (min 6 chars)"
                className="h-10 flex-1 rounded-xl border border-slate-800 bg-[#050a17] px-3 text-xs text-white placeholder:text-slate-500"
              />
              <button
                type="button"
                onClick={handleExportEncryptedBackup}
                disabled={backupPassphrase.length < 6}
                className="inline-flex h-10 shrink-0 items-center justify-center gap-1.5 rounded-xl bg-cyan-500 px-4 text-xs font-semibold text-slate-950 hover:bg-cyan-400 disabled:opacity-40"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Export Encrypted</span>
              </button>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2.5 border-t border-slate-800/70 pt-3">
              <label className="inline-flex min-h-[38px] cursor-pointer items-center gap-1.5 rounded-xl border border-slate-700 bg-[#060c1d] px-3.5 text-xs text-slate-200 hover:border-cyan-400">
                <Upload className="h-3.5 w-3.5 text-cyan-400" />
                <span>Load .aanya.enc.json</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleLoadBackupFile}
                  className="hidden"
                />
              </label>

              {pendingRestoreFile && (
                <>
                  <input
                    type="password"
                    value={restorePassphrase}
                    onChange={(e) => setRestorePassphrase(e.target.value)}
                    placeholder="Enter passphrase"
                    className="h-9 flex-1 rounded-lg border border-slate-800 bg-[#050a17] px-3 text-xs text-white"
                  />
                  <button
                    type="button"
                    onClick={handleDecryptAndRestore}
                    className="h-9 rounded-lg bg-slate-800 px-3.5 text-xs font-medium text-cyan-300 hover:bg-slate-700"
                  >
                    Decrypt & Restore
                  </button>
                </>
              )}
            </div>

            {backupMessage && (
              <p className="mt-3 text-xs text-cyan-200">{backupMessage}</p>
            )}

            <div className="mt-4 flex items-center justify-between border-t border-slate-800/70 pt-3">
              <span className="text-xs text-slate-400">User-controlled permanent erasure</span>
              {!confirmErase ? (
                <button
                  type="button"
                  onClick={() => setConfirmErase(true)}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-400 hover:text-rose-300"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  <span>Delete All Local Data</span>
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      onEraseAllData();
                      setConfirmErase(false);
                      setBackupMessage('All local memories, chats, and custom skills erased.');
                    }}
                    className="rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-semibold text-white"
                  >
                    Confirm Erase
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmErase(false)}
                    className="text-xs text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Secure Lock System */}
          <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Lock className="h-4 w-4 text-cyan-400" />
                <h3 className="text-base font-semibold text-white">Secure Lock System</h3>
              </div>
              {hasVaultPin && (
                <button
                  type="button"
                  onClick={onLockNow}
                  className="rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-medium text-cyan-300 hover:bg-slate-700"
                >
                  Lock Now
                </button>
              )}
            </div>
            <p className="mt-1 text-xs text-slate-400">
              Android BiometricPrompt + Device Credential lock policy. Never extracts or stores raw PINs or biometrics.
            </p>
            <form onSubmit={handleSaveVaultPin} className="mt-3 flex gap-2.5">
              <input
                type="password"
                inputMode="numeric"
                value={newPin}
                onChange={(e) => setNewPin(e.target.value)}
                placeholder={hasVaultPin ? 'Enter new 4+ digit PIN' : 'Set 4+ digit Vault PIN'}
                className="h-10 flex-1 rounded-xl border border-slate-800 bg-[#050a17] px-3 text-xs text-white placeholder:text-slate-500"
              />
              <button
                type="submit"
                className="h-10 shrink-0 rounded-xl bg-slate-800 px-4 text-xs font-medium text-white hover:bg-slate-700"
              >
                Save PIN
              </button>
            </form>
            {pinSavedMsg && <p className="mt-2 text-xs text-cyan-300">{pinSavedMsg}</p>}
          </div>
        </section>
      </div>

      {/* Permission & Privacy Dashboard */}
      <section className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5">
        <h3 className="text-base font-semibold text-white">
          Android 16 Permission & Privacy Dashboard
        </h3>
        <p className="mt-1 text-xs text-slate-400">
          Transparent permission audit with zero hidden monitoring and OPPO K12 5G / ColorOS battery optimization guidance.
        </p>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[680px] text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5 pr-4 font-medium">Capability</th>
                <th className="py-2.5 pr-4 font-medium">Android Permission</th>
                <th className="py-2.5 pr-4 font-medium">Android 16 & Privacy Policy</th>
                <th className="py-2.5 text-right font-medium">Consent</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {permissions.map((perm) => (
                <tr key={perm.id} className="hover:bg-slate-900/40">
                  <td className="py-3 pr-4">
                    <div className="font-medium text-white">{perm.name}</div>
                    <div className="mt-0.5 text-[11px] text-slate-400">{perm.purpose}</div>
                  </td>
                  <td className="py-3 pr-4 font-mono text-[11px] text-cyan-300/90">
                    {perm.androidPermission}
                  </td>
                  <td className="py-3 pr-4 text-[11px] text-slate-400">{perm.android16Note}</td>
                  <td className="py-3 text-right">
                    <button
                      type="button"
                      role="switch"
                      aria-checked={perm.consentGranted}
                      onClick={() => onTogglePermission(perm.id)}
                      className={`inline-flex min-h-[34px] items-center rounded-lg px-3 text-xs font-medium transition-colors ${
                        perm.consentGranted
                          ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40'
                          : 'bg-slate-900 text-slate-400 border border-slate-800'
                      }`}
                    >
                      {perm.consentGranted ? 'Granted' : 'Denied'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
