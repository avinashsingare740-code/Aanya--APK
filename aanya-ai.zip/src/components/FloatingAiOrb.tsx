import React, { useEffect, useRef } from 'react';
import { ORB_THEMES } from '../data/presets';
import type { OrbThemeId } from '../types';

interface FloatingAiOrbProps {
  themeId: OrbThemeId;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  state?: 'idle' | 'listening' | 'thinking' | 'speaking';
  audioLevel?: number;
  onClick?: () => void;
  ariaLabel?: string;
}

const SIZE_MAP = {
  sm: 56,
  md: 108,
  lg: 172,
  xl: 224,
};

export const FloatingAiOrb: React.FC<FloatingAiOrbProps> = ({
  themeId,
  size = 'md',
  state = 'idle',
  audioLevel = 0,
  onClick,
  ariaLabel = 'Activate Aanya AI Orb',
}) => {
  const theme = ORB_THEMES[themeId] || ORB_THEMES['aanya-galaxy'];
  const dim = SIZE_MAP[size];
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = dim * dpr;
    canvas.height = dim * dpr;
    ctx.scale(dpr, dpr);

    let rafId = 0;
    let phase = 0;
    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const render = () => {
      ctx.clearRect(0, 0, dim, dim);
      const cx = dim / 2;
      const cy = dim / 2;
      const baseR = dim * 0.29;
      const boost =
        state === 'listening'
          ? 0.14 + audioLevel * 0.18
          : state === 'speaking'
            ? 0.12 + Math.abs(Math.sin(phase * 3.5)) * 0.12
            : state === 'thinking'
              ? 0.08 + Math.sin(phase * 4.5) * 0.05
              : Math.sin(phase) * 0.03;

      const r = baseR * (1 + boost);

      // Outer atmospheric halo
      const halo = ctx.createRadialGradient(cx, cy, r * 0.35, cx, cy, dim * 0.49);
      halo.addColorStop(0, theme.glowRgba);
      halo.addColorStop(0.55, `${theme.ringPrimary}26`);
      halo.addColorStop(1, 'rgba(5, 8, 20, 0)');
      ctx.fillStyle = halo;
      ctx.beginPath();
      ctx.arc(cx, cy, dim * 0.49, 0, Math.PI * 2);
      ctx.fill();

      // Theme-specific geometric or organic orbital rings
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(phase * (state === 'thinking' ? 1.5 : 0.45));
      ctx.strokeStyle = `${theme.ringPrimary}aa`;
      ctx.lineWidth = size === 'sm' ? 1.2 : 1.75;
      ctx.beginPath();
      if (themeId === 'tron' || themeId === 'jarvis') {
        ctx.setLineDash([dim * 0.12, dim * 0.06, dim * 0.04, dim * 0.06]);
      } else if (themeId === 'cyber-ai') {
        ctx.setLineDash([dim * 0.08, dim * 0.04]);
      }
      ctx.ellipse(0, 0, r * 1.38, r * 0.96, 0.35, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(-phase * (state === 'speaking' ? 1.3 : 0.35));
      ctx.strokeStyle = `${theme.ringSecondary}88`;
      ctx.lineWidth = size === 'sm' ? 1 : 1.4;
      ctx.beginPath();
      ctx.ellipse(0, 0, r * 1.26, r * 1.08, -0.5, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // Core plasma sphere
      const coreGrad = ctx.createRadialGradient(
        cx - r * 0.28,
        cy - r * 0.28,
        r * 0.1,
        cx,
        cy,
        r
      );
      coreGrad.addColorStop(0, theme.coreTo);
      coreGrad.addColorStop(0.5, theme.coreVia);
      coreGrad.addColorStop(1, theme.coreFrom);
      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();

      // Subtle inner waveform / energy crest
      if (size !== 'sm') {
        ctx.save();
        ctx.beginPath();
        ctx.arc(cx, cy, r * 0.88, 0, Math.PI * 2);
        ctx.clip();

        ctx.strokeStyle = `${theme.particleHex}cc`;
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        const waveAmp =
          state === 'speaking'
            ? r * 0.22
            : state === 'listening'
              ? r * (0.14 + audioLevel * 0.32)
              : state === 'thinking'
                ? r * 0.16
                : r * 0.06;

        for (let x = -r; x <= r; x += 3) {
          const y =
            Math.sin(x * 0.09 + phase * (state === 'thinking' ? 5 : 3)) *
            waveAmp *
            Math.cos((x / r) * (Math.PI / 2));
          if (x === -r) ctx.moveTo(cx + x, cy + y);
          else ctx.lineTo(cx + x, cy + y);
        }
        ctx.stroke();
        ctx.restore();
      }

      // Orbiting starlight nodes
      const nodeCount = size === 'sm' ? 2 : 4;
      for (let i = 0; i < nodeCount; i++) {
        const angle = phase * (0.7 + i * 0.18) + (i * Math.PI * 2) / nodeCount;
        const orbitR = r * (1.28 + (i % 2) * 0.12);
        const px = cx + Math.cos(angle) * orbitR;
        const py = cy + Math.sin(angle) * orbitR * 0.78;
        ctx.fillStyle = theme.particleHex;
        ctx.beginPath();
        ctx.arc(px, py, size === 'sm' ? 1.6 : 2.3, 0, Math.PI * 2);
        ctx.fill();
      }

      if (!prefersReduced) {
        phase += state === 'thinking' ? 0.045 : state === 'speaking' ? 0.038 : 0.02;
        rafId = requestAnimationFrame(render);
      }
    };

    render();
    return () => {
      if (rafId) cancelAnimationFrame(rafId);
    };
  }, [dim, theme, themeId, size, state, audioLevel]);

  const Wrapper = onClick ? 'button' : 'div';

  return (
    <Wrapper
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      aria-label={onClick ? ariaLabel : undefined}
      className={`relative inline-flex items-center justify-center rounded-full focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-cyan-400 ${
        onClick ? 'cursor-pointer transition-transform duration-200 hover:scale-105 active:scale-95' : ''
      }`}
      style={{ width: dim, height: dim }}
    >
      <canvas
        ref={canvasRef}
        style={{ width: dim, height: dim }}
        className="block pointer-events-none"
      />
    </Wrapper>
  );
};
