import React, { useMemo, useState } from 'react';
import JSZip from 'jszip';
import { Check, CheckCircle2, Copy, Download, FileCode2, FolderTree } from 'lucide-react';
import { ANDROID_PROJECT_FILES, type AndroidProjectFile } from '../data/androidProjectFiles';
import { DEVELOPMENT_CHECKLIST } from '../data/presets';

export const AndroidCodeStudio: React.FC = () => {
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [selectedPath, setSelectedPath] = useState<string>(ANDROID_PROJECT_FILES[0].path);
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const categories = useMemo(
    () => ['All', ...Array.from(new Set(ANDROID_PROJECT_FILES.map((f) => f.category)))],
    []
  );

  const filteredFiles = useMemo(
    () =>
      categoryFilter === 'All'
        ? ANDROID_PROJECT_FILES
        : ANDROID_PROJECT_FILES.filter((f) => f.category === categoryFilter),
    [categoryFilter]
  );

  const selectedFile: AndroidProjectFile =
    ANDROID_PROJECT_FILES.find((f) => f.path === selectedPath) || ANDROID_PROJECT_FILES[0];

  const handleCopy = async () => {
    await navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const handleDownloadZip = async () => {
    setDownloading(true);
    try {
      const zip = new JSZip();
      const root = zip.folder('AanyaAI-AndroidStudio');
      if (root) {
        for (const file of ANDROID_PROJECT_FILES) {
          root.file(file.path, file.content);
        }
        // Add Android string resource required by accessibility XML
        root.file(
          'app/src/main/res/values/strings.xml',
          `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Aanya AI</string>
    <string name="accessibility_service_description">Allows Aanya AI to perform explicit user-approved app navigation, taps, scrolling, and text entry.</string>
</resources>
`
        );
      }

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'AanyaAI-AndroidStudio-com.aanya.ai.zip';
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Direct ZIP Download */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5">
        <div>
          <h2 className="text-xl font-semibold text-white">
            Native Android Studio Project (com.aanya.ai)
          </h2>
          <p className="mt-1 text-xs text-slate-400">
            Kotlin 2.1 · Jetpack Compose · Min Android 8.0 (API 26) · Target Android 16 (API 36) · OPPO K12 5G Profile
          </p>
        </div>

        <button
          type="button"
          onClick={handleDownloadZip}
          disabled={downloading}
          className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-cyan-500 px-5 text-xs font-semibold text-slate-950 transition-colors hover:bg-cyan-400 disabled:opacity-50"
        >
          <Download className="h-4 w-4" />
          <span>{downloading ? 'Packaging Project...' : 'Download Android Project (.zip)'}</span>
        </button>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setCategoryFilter(cat)}
            className={`min-h-[36px] rounded-lg px-3.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
              categoryFilter === cat
                ? 'bg-cyan-500 text-slate-950'
                : 'border border-slate-800 bg-[#070d1f] text-slate-400 hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* File Tree + Code Viewer */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <aside className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-4 lg:col-span-4">
          <div className="mb-3 flex items-center gap-2 text-xs font-medium text-slate-400">
            <FolderTree className="h-4 w-4 text-cyan-400" />
            <span className="tabular-nums">{filteredFiles.length} Project Files</span>
          </div>
          <ul className="space-y-1.5 max-h-[540px] overflow-y-auto pr-1">
            {filteredFiles.map((file) => {
              const active = file.path === selectedFile.path;
              return (
                <li key={file.path}>
                  <button
                    type="button"
                    onClick={() => setSelectedPath(file.path)}
                    className={`w-full rounded-xl px-3 py-2.5 text-left transition-colors ${
                      active
                        ? 'bg-cyan-500/15 text-cyan-200 border border-cyan-500/40'
                        : 'text-slate-300 hover:bg-slate-800/60 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <FileCode2 className="h-3.5 w-3.5 shrink-0 text-cyan-400" />
                      <span className="truncate font-mono text-xs">{file.path.split('/').pop()}</span>
                    </div>
                    <div className="mt-0.5 truncate font-mono text-[10px] text-slate-500">
                      {file.path}
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        </aside>

        <section className="flex flex-col rounded-2xl border border-slate-800/80 bg-[#091024]/85 lg:col-span-8">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 px-5 py-3.5">
            <div className="min-w-0">
              <div className="truncate font-mono text-xs font-medium text-cyan-300">
                {selectedFile.path}
              </div>
              <p className="mt-0.5 text-xs text-slate-400">{selectedFile.summary}</p>
            </div>
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex min-h-[36px] shrink-0 items-center gap-1.5 rounded-lg border border-slate-700 bg-[#050a17] px-3 text-xs text-slate-200 hover:border-cyan-400"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-cyan-400" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Code'}</span>
            </button>
          </div>

          <pre className="max-h-[520px] flex-1 overflow-auto p-5 font-mono text-xs leading-relaxed text-slate-200">
            <code>{selectedFile.content}</code>
          </pre>
        </section>
      </div>

      {/* Development Checklist & Build Instructions */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 lg:col-span-7">
          <h3 className="text-base font-semibold text-white">Module Development Checklist</h3>
          <p className="mt-1 text-xs text-slate-400">
            Verified across the interactive web assistant and the exported Kotlin Android Studio codebase.
          </p>
          <ul className="mt-4 divide-y divide-slate-800/70">
            {DEVELOPMENT_CHECKLIST.map((item) => (
              <li key={item.module} className="flex items-center justify-between gap-3 py-2.5 text-xs">
                <span className="text-slate-200">{item.module}</span>
                <span className="inline-flex shrink-0 items-center gap-1.5 text-cyan-400">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Web + Kotlin Ready</span>
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-2xl border border-slate-800/80 bg-[#091024]/85 p-5 lg:col-span-5">
          <h3 className="text-base font-semibold text-white">Compile Debug APK for OPPO K12 5G</h3>
          <p className="mt-1 text-xs text-slate-400">
            Because this browser sandbox runs Node.js rather than the Android SDK/Gradle daemon, download the ZIP above to generate the signed debug APK in Android Studio:
          </p>
          <ol className="mt-4 space-y-3 text-xs leading-relaxed text-slate-300">
            <li>
              <span className="font-semibold text-white">1. Extract & Open:</span> Unzip{' '}
              <code className="font-mono text-cyan-300">AanyaAI-AndroidStudio-com.aanya.ai.zip</code>{' '}
              in Android Studio Ladybug / Meerkat+ (JDK 17).
            </li>
            <li>
              <span className="font-semibold text-white">2. Build Debug APK:</span> Run{' '}
              <code className="font-mono text-cyan-300">./gradlew assembleDebug</code> or choose{' '}
              Build &gt; Build APK(s). Output:{' '}
              <code className="font-mono text-slate-400">app/build/outputs/apk/debug/app-debug.apk</code>.
            </li>
            <li>
              <span className="font-semibold text-white">3. OPPO K12 5G / ColorOS Stability:</span>{' '}
              Enable Allow Background Activity and Auto-Launch so ColorOS does not terminate Aanya&apos;s
              foreground voice notification.
            </li>
          </ol>
        </div>
      </section>
    </div>
  );
};
