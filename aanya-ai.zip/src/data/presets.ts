import type {
  AndroidPermissionItem,
  CallReminder,
  EmergencyContact,
  MarkdownSkill,
  MemoryItem,
  OrbThemeConfig,
  OrbThemeId,
  PersonaConfig,
  PersonaId,
  SmartDevice,
} from '../types';

export const GALAXY_BACKDROP_PATH =
  '/src/assets/images/aanya_galaxy_backdrop_1795101981569.jpg';

export const PERSONAS: Record<PersonaId, PersonaConfig> = {
  maya: {
    id: 'maya',
    name: 'Aanya',
    role: 'Friendly Female AI Assistant',
    tagline: 'Warm, smart personal companion in Hinglish & English',
    voiceLabel: 'Aanya Voice · Natural Female (Hinglish & English)',
    defaultOrbTheme: 'aanya-galaxy',
    avatarPath: '/src/assets/images/aanya_maya_avatar_1795102093091.jpg',
    accentHex: '#38bdf8',
    speechPitch: 1.08,
    speechRate: 1.0,
    greeting:
      'Hey Boss! Main Aanya hoon, aapki personal AI assistant. Hinglish ya English mein bolo — aaj main aapki kya help karoon, Boss?',
  },
  friday: {
    id: 'friday',
    name: 'Friday',
    role: 'Professional Intelligent Assistant',
    tagline: 'Precision executive briefing, coding, and multi-agent coordination',
    voiceLabel: 'Friday Voice · Executive Calm (Hinglish & English)',
    defaultOrbTheme: 'friday',
    avatarPath: '/src/assets/images/aanya_friday_avatar_1795101966883.jpg',
    accentHex: '#60a5fa',
    speechPitch: 0.98,
    speechRate: 1.04,
    greeting:
      'Friday standing by, Boss. Multi-agent systems, phone automation approvals, aur workspace controls sab ready hain.',
  },
  venom: {
    id: 'venom',
    name: 'Venom',
    role: 'Powerful Cosmic Male Personality',
    tagline: 'Commanding deep voice with fierce loyalty and full safety guards',
    voiceLabel: 'Venom Voice · Deep Resonant Male',
    defaultOrbTheme: 'venom',
    avatarPath: null,
    accentHex: '#22d3ee',
    speechPitch: 0.72,
    speechRate: 0.94,
    greeting:
      'We are awake, Boss. Target, code ya task batao — aapke confirmation ke bina kuch nahi chalega.',
  },
};

export const ORB_THEMES: Record<OrbThemeId, OrbThemeConfig> = {
  'aanya-galaxy': {
    id: 'aanya-galaxy',
    name: 'Aanya Galaxy',
    description: 'Deep sapphire nebula core with twin cyan stellar rings',
    coreFrom: '#0c4a6e',
    coreVia: '#0284c7',
    coreTo: '#22d3ee',
    ringPrimary: '#38bdf8',
    ringSecondary: '#818cf8',
    glowRgba: 'rgba(56, 189, 248, 0.42)',
    particleHex: '#7dd3fc',
  },
  'maya-2047': {
    id: 'maya-2047',
    name: 'Maya 2047',
    description: 'Luminous cerulean holo-iris with warm aurora refraction',
    coreFrom: '#164e63',
    coreVia: '#06b6d4',
    coreTo: '#a5f3fc',
    ringPrimary: '#22d3ee',
    ringSecondary: '#67e8f9',
    glowRgba: 'rgba(34, 211, 238, 0.46)',
    particleHex: '#cffafe',
  },
  nova: {
    id: 'nova',
    name: 'Nova',
    description: 'High-energy blue-white starburst corona and polar flare',
    coreFrom: '#1e3a8a',
    coreVia: '#3b82f6',
    coreTo: '#e0f2fe',
    ringPrimary: '#60a5fa',
    ringSecondary: '#38bdf8',
    glowRgba: 'rgba(96, 165, 250, 0.48)',
    particleHex: '#bae6fd',
  },
  jarvis: {
    id: 'jarvis',
    name: 'Jarvis',
    description: 'Precision holographic HUD rings with crisp electric telemetry arcs',
    coreFrom: '#0f2942',
    coreVia: '#0ea5e9',
    coreTo: '#7dd3fc',
    ringPrimary: '#0ea5e9',
    ringSecondary: '#f59e0b',
    glowRgba: 'rgba(14, 165, 233, 0.42)',
    particleHex: '#fde68a',
  },
  tron: {
    id: 'tron',
    name: 'Tron',
    description: 'Razor-sharp light-grid geometry with pure ice-cyan pulse lines',
    coreFrom: '#082f49',
    coreVia: '#00d4ff',
    coreTo: '#ecfeff',
    ringPrimary: '#00e5ff',
    ringSecondary: '#0284c7',
    glowRgba: 'rgba(0, 229, 255, 0.5)',
    particleHex: '#00e5ff',
  },
  'cyber-ai': {
    id: 'cyber-ai',
    name: 'Cyber AI',
    description: 'High-voltage cobalt matrix sphere with dual phase rings',
    coreFrom: '#172554',
    coreVia: '#2563eb',
    coreTo: '#22d3ee',
    ringPrimary: '#3b82f6',
    ringSecondary: '#06b6d4',
    glowRgba: 'rgba(37, 99, 235, 0.46)',
    particleHex: '#60a5fa',
  },
  friday: {
    id: 'friday',
    name: 'Friday',
    description: 'Brushed silver-blue optical aperture with calm orbital balance',
    coreFrom: '#1e293b',
    coreVia: '#38bdf8',
    coreTo: '#f1f5f9',
    ringPrimary: '#93c5fd',
    ringSecondary: '#38bdf8',
    glowRgba: 'rgba(147, 197, 253, 0.4)',
    particleHex: '#e2e8f0',
  },
  venom: {
    id: 'venom',
    name: 'Venom',
    description: 'Dark liquid obsidian core veined with electric abyssal cyan',
    coreFrom: '#020617',
    coreVia: '#0f172a',
    coreTo: '#0891b2',
    ringPrimary: '#06b6d4',
    ringSecondary: '#334155',
    glowRgba: 'rgba(6, 182, 212, 0.36)',
    particleHex: '#22d3ee',
  },
};

export const ORB_THEME_LIST: OrbThemeConfig[] = Object.values(ORB_THEMES);

export const AI_AGENTS = [
  {
    name: 'Research Agent',
    focus: 'Deep synthesis, multilingual fact verification, and structured summaries',
    approvalPolicy: 'Autonomous read-only',
  },
  {
    name: 'Phone Automation Agent',
    focus: 'Android Accessibility UI navigation, app launch, scrolling, and typing',
    approvalPolicy: 'Requires explicit consent',
  },
  {
    name: 'Coding Agent',
    focus: 'Kotlin, Jetpack Compose, Android 16 APIs, debugging, and scripts',
    approvalPolicy: 'Autonomous generation',
  },
  {
    name: 'Communication Agent',
    focus: 'Drafting WhatsApp replies, SMS messages, call reminders, and summaries',
    approvalPolicy: 'Confirm before sending',
  },
  {
    name: 'Vision Agent',
    focus: 'Live camera object recognition, Hindi/English OCR, and Screen Vision',
    approvalPolicy: 'Privacy Shield active',
  },
  {
    name: 'Memory Agent',
    focus: 'Long-term recall, preference indexing, and AES-256 encrypted backups',
    approvalPolicy: 'User-controlled erase',
  },
  {
    name: 'Personal Assistant Agent',
    focus: 'Daily planning, reminders, smart home routines, and remote PC requests',
    approvalPolicy: 'Confirm sensitive actions',
  },
] as const;

export const INITIAL_MEMORIES: MemoryItem[] = [
  {
    id: 'mem-1',
    text: 'Primary target Android device is OPPO K12 5G running ColorOS / Android 16 compatibility profile.',
    category: 'Context',
    createdAt: '2026-11-18T09:00:00Z',
  },
  {
    id: 'mem-2',
    text: 'Always address the user as "Boss" and reply in a natural Hinglish & English tone, with explicit approval before sending WhatsApp or SMS.',
    category: 'Preference',
    createdAt: '2026-11-18T09:05:00Z',
  },
];

export const INITIAL_SKILLS: MarkdownSkill[] = [
  {
    id: 'skill-morning',
    title: 'Morning Briefing Routine',
    trigger: 'good morning / subah briefing',
    category: 'Daily Routine',
    requiresApproval: false,
    markdown: `# Morning Briefing Routine
## Trigger
When user says "Good morning" or "Subah ka briefing do".

## Steps
1. Greet the user warmly in their active persona voice.
2. Summarize pending call reminders and saved priorities from Long-Term Memory.
3. Offer to check Wi-Fi, Bluetooth, and battery optimization readiness.
4. Keep response under 4 concise bullet points.`,
  },
  {
    id: 'skill-whatsapp-draft',
    title: 'WhatsApp Safe Reply Macro',
    trigger: 'whatsapp message / msg bhejo',
    category: 'Communication',
    requiresApproval: true,
    markdown: `# WhatsApp Safe Reply Macro
## Policy
NEVER send a WhatsApp message automatically without showing the recipient and message draft first.

## Steps
1. Identify recipient name and message body in Hindi, English, or Hinglish.
2. Populate a confirmation card with target app "WhatsApp".
3. Wait for explicit tap on "Approve & Execute" before invoking Android Accessibility Service.`,
  },
  {
    id: 'skill-focus-guard',
    title: 'OPPO K12 Focus Mode',
    trigger: 'focus mode / study mode',
    category: 'Phone Automation',
    requiresApproval: true,
    markdown: `# OPPO K12 Focus Mode
## Steps
1. Propose enabling Do Not Disturb via Android Notification Policy access.
2. Silence non-priority social app notifications while keeping SOS contacts allowed.
3. Start a 45-minute focus timer and confirm with user before applying.`,
  },
  {
    id: 'skill-pc-media',
    title: 'Remote PC Workspace Lock',
    trigger: 'lock my pc / pause desktop',
    category: 'Remote PC',
    requiresApproval: true,
    markdown: `# Remote PC Workspace Lock
## Security
Only dispatch to an authenticated paired PC over TLS with explicit user confirmation.

## Steps
1. Verify paired workstation connection status.
2. Prompt user to confirm Lock Screen or Media Pause command.
3. Log executed command with timestamp in local audit history.`,
  },
];

export const INITIAL_EMERGENCY_CONTACTS: EmergencyContact[] = [
  {
    id: 'sos-1',
    name: 'Primary Family Contact',
    relation: 'Family',
    phone: '+91 98000 00001',
  },
  {
    id: 'sos-2',
    name: 'Emergency Services (India)',
    relation: 'National Helpline',
    phone: '112',
  },
];

export const INITIAL_SMART_DEVICES: SmartDevice[] = [
  {
    id: 'dev-pc-1',
    name: 'Workstation PC (LAN TLS)',
    kind: 'Remote PC',
    host: '192.168.1.42:8443',
    authenticated: true,
    state: 'Paired · Ready',
  },
  {
    id: 'dev-home-1',
    name: 'Desk Ambient Lighting',
    kind: 'Smart Home',
    host: 'matter://desk-lamp.local',
    authenticated: true,
    state: 'Dimmed 35% · Cool Cyan',
  },
  {
    id: 'dev-home-2',
    name: 'Bedroom AC Thermostat',
    kind: 'Smart Home',
    host: 'matter://ac-node.local',
    authenticated: false,
    state: 'Awaiting Pairing Token',
  },
];

export const INITIAL_CALL_REMINDERS: CallReminder[] = [
  {
    id: 'call-1',
    contactName: 'Rohan Sharma',
    phone: '+91 98201 11223',
    note: 'Confirm weekend project sync and APK test on OPPO K12 5G',
    scheduledFor: 'Today · 6:30 PM',
    done: false,
  },
  {
    id: 'call-2',
    contactName: 'Priya Verma',
    phone: '+91 98114 44556',
    note: 'Follow up on Hindi voice prompt recordings',
    scheduledFor: 'Tomorrow · 11:00 AM',
    done: false,
  },
];

export const INITIAL_ANDROID_PERMISSIONS: AndroidPermissionItem[] = [
  {
    id: 'perm-mic',
    name: 'Microphone & Speech Recognition',
    androidPermission: 'android.permission.RECORD_AUDIO + FOREGROUND_SERVICE_MICROPHONE',
    purpose: 'Voice commands, Hindi/English speech recognition, and foreground wake listener.',
    consentGranted: true,
    sensitive: true,
    android16Note: 'Requires active foreground service notification while listening on Android 14–16.',
  },
  {
    id: 'perm-camera',
    name: 'Camera Vision',
    androidPermission: 'android.permission.CAMERA',
    purpose: 'Live object recognition, scene understanding, and text OCR.',
    consentGranted: true,
    sensitive: true,
    android16Note: 'Camera indicator remains visible in Android status bar whenever active.',
  },
  {
    id: 'perm-a11y',
    name: 'Accessibility Service Automation',
    androidPermission: 'android.permission.BIND_ACCESSIBILITY_SERVICE',
    purpose: 'User-approved app navigation, button taps, scrolling, and text entry.',
    consentGranted: false,
    sensitive: true,
    android16Note: 'Must be explicitly enabled in Settings > Accessibility; never silently activated.',
  },
  {
    id: 'perm-projection',
    name: 'Screen Vision (MediaProjection)',
    androidPermission: 'android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION',
    purpose: 'One-session screen capture to explain on-screen content with Privacy Shield.',
    consentGranted: false,
    sensitive: true,
    android16Note: 'Android 14–16 enforces per-session system consent dialog before every capture.',
  },
  {
    id: 'perm-overlay',
    name: 'Floating AI Orb Overlay',
    androidPermission: 'android.permission.SYSTEM_ALERT_WINDOW',
    purpose: 'Displays the themed Floating AI Orb above active apps.',
    consentGranted: true,
    sensitive: false,
    android16Note: 'Granted via Settings > Display over other apps.',
  },
  {
    id: 'perm-biometric',
    name: 'Biometric & Secure Lock',
    androidPermission: 'android.permission.USE_BIOMETRIC',
    purpose: 'Fingerprint/Face authentication via Android BiometricPrompt (never extracts biometrics).',
    consentGranted: true,
    sensitive: false,
    android16Note: 'Backed by Android Keystore hardware strongbox where available.',
  },
  {
    id: 'perm-calls',
    name: 'Calls, Contacts & SMS (Confirmed)',
    androidPermission: 'READ_CONTACTS + CALL_PHONE + SEND_SMS',
    purpose: 'Caller identification, SOS SMS, and user-confirmed outgoing calls. Never secretly records calls.',
    consentGranted: false,
    sensitive: true,
    android16Note: 'Every outgoing call or message requires explicit tap confirmation.',
  },
  {
    id: 'perm-location',
    name: 'SOS Location Sharing',
    androidPermission: 'android.permission.ACCESS_FINE_LOCATION',
    purpose: 'Included in SOS alerts strictly when user explicitly toggles location sharing.',
    consentGranted: false,
    sensitive: true,
    android16Note: 'Foreground-only consent recommended; off by default.',
  },
  {
    id: 'perm-battery',
    name: 'OPPO K12 5G / ColorOS Background Stability',
    androidPermission: 'REQUEST_IGNORE_BATTERY_OPTIMIZATIONS + RECEIVE_BOOT_COMPLETED',
    purpose: 'Guides user to exempt Aanya AI from ColorOS aggressive background killing.',
    consentGranted: true,
    sensitive: false,
    android16Note: 'Android 15/16 restricts BOOT_COMPLETED foreground mic starts; posts tap-to-resume notification.',
  },
];

export const DEVELOPMENT_CHECKLIST = [
  { module: '01. Dark Galaxy UI, 3 Personas & 8 Floating AI Orb Themes', webLive: true, androidKotlin: true },
  { module: '02. Multi-Provider AI Brain (Gemini + Fallback Router)', webLive: true, androidKotlin: true },
  { module: '03. Multilingual Hindi / English / Hinglish Conversations', webLive: true, androidKotlin: true },
  { module: '04. Voice Studio (Neural TTS, Wake Word, Echo Guard, Voice Guardian)', webLive: true, androidKotlin: true },
  { module: '05. Live Camera Vision, OCR & Screen Vision with Privacy Shield', webLive: true, androidKotlin: true },
  { module: '06. 7 Coordinated AI Agents with Step-by-Step User Approval', webLive: true, androidKotlin: true },
  { module: '07. Phone Automation, Smart Calls & Confirmation Gates', webLive: true, androidKotlin: true },
  { module: '08. Custom Markdown Skills Loader, Editor, Import & Export', webLive: true, androidKotlin: true },
  { module: '09. SOS Emergency Mode with Location Consent & Stop Control', webLive: true, androidKotlin: true },
  { module: '10. AES-256-GCM Encrypted Memory Backup & Restore', webLive: true, androidKotlin: true },
  { module: '11. Secure Vault Lock (Salted Hash + BiometricPrompt API)', webLive: true, androidKotlin: true },
  { module: '12. Smart Home & Authenticated Remote PC Control Console', webLive: true, androidKotlin: true },
  { module: '13. Android Studio Gradle + Kotlin Project (OPPO K12 5G / API 36)', webLive: true, androidKotlin: true },
];
