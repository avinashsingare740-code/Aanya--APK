export interface AndroidProjectFile {
  path: string;
  category:
    | 'Gradle & Build'
    | 'Manifest & Resources'
    | 'Core UI & Orb'
    | 'AI Brain & Agents'
    | 'Voice & Vision'
    | 'Automation & Calls'
    | 'Security & Backup';
  language: 'kotlin' | 'xml' | 'properties' | 'markdown';
  summary: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidProjectFile[] = [
  {
    path: 'settings.gradle.kts',
    category: 'Gradle & Build',
    language: 'kotlin',
    summary: 'Root Gradle settings defining Aanya AI repositories and :app module.',
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "AanyaAI"
include(":app")
`,
  },
  {
    path: 'build.gradle.kts',
    category: 'Gradle & Build',
    language: 'kotlin',
    summary: 'Top-level Gradle build script using AGP 8.9+ and Kotlin 2.1.',
    content: `plugins {
    id("com.android.application") version "8.9.1" apply false
    id("org.jetbrains.kotlin.android") version "2.1.10" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.10" apply false
}
`,
  },
  {
    path: 'gradle.properties',
    category: 'Gradle & Build',
    language: 'properties',
    summary: 'JVM memory tuning, AndroidX enablement, and configuration cache.',
    content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`,
  },
  {
    path: 'app/build.gradle.kts',
    category: 'Gradle & Build',
    language: 'kotlin',
    summary: 'App module targeting Android 16 (SDK 36), minSdk 26 (Android 8.0), Compose, CameraX, Biometric, Security-Crypto & OkHttp.',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.aanya.ai"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.aanya.ai"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0-max"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.04.00")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.9")

    // Coroutines & Networking (Multi-Provider AI Router)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // CameraX for Live Camera Vision
    val cameraxVersion = "1.4.2"
    implementation("androidx.camera:camera-core:$cameraxVersion")
    implementation("androidx.camera:camera-camera2:$cameraxVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraxVersion")
    implementation("androidx.camera:camera-view:$cameraxVersion")

    // Biometrics & Encrypted Storage (Android Keystore AES-256-GCM)
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // Testing
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
}
`,
  },
  {
    path: 'app/proguard-rules.pro',
    category: 'Gradle & Build',
    language: 'properties',
    summary: 'ProGuard keep rules for OkHttp, Security-Crypto, and Android services.',
    content: `-keep class com.aanya.ai.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
`,
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    category: 'Manifest & Resources',
    language: 'xml',
    summary: 'Complete Android 16 manifest declaring runtime permissions, Foreground Services (microphone & mediaProjection), AccessibilityService, and BootReceiver.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <!-- Core AI, Voice & Vision Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <!-- Android 14-16 Foreground Service Types -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />

    <!-- Floating Orb & Boot / Battery Guidance -->
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />

    <!-- Biometric Authentication (Never extracts credentials) -->
    <uses-permission android:name="android.permission.USE_BIOMETRIC" />

    <!-- User-Confirmed Calls, Contacts, SMS & Optional SOS Location -->
    <uses-permission android:name="android.permission.READ_CONTACTS" />
    <uses-permission android:name="android.permission.CALL_PHONE" />
    <uses-permission android:name="android.permission.SEND_SMS" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />

    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.telephony" android:required="false" />

    <application
        android:name=".AanyaApplication"
        android:allowBackup="false"
        android:fullBackupContent="@xml/backup_rules"
        android:label="Aanya AI"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.Material.NoActionBar"
        tools:targetApi="36">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Foreground Voice, Wake Word & Echo Guard Service -->
        <service
            android:name=".voice.AanyaVoiceForegroundService"
            android:exported="false"
            android:foregroundServiceType="microphone" />

        <!-- MediaProjection Screen Vision Service -->
        <service
            android:name=".vision.ScreenVisionMediaProjectionService"
            android:exported="false"
            android:foregroundServiceType="mediaProjection" />

        <!-- Floating AI Orb Overlay Service -->
        <service
            android:name=".overlay.FloatingOrbOverlayService"
            android:exported="false" />

        <!-- Consent-Gated Phone Automation Accessibility Service -->
        <service
            android:name=".automation.AanyaAccessibilityService"
            android:exported="false"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice.accessibilityservice"
                android:resource="@xml/aanya_accessibility_config" />
        </service>

        <!-- Boot Receiver (Android 15/16 compliant notification prompt) -->
        <receiver
            android:name=".receiver.BootCompletedReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>
    </application>
</manifest>
`,
  },
  {
    path: 'app/src/main/res/xml/aanya_accessibility_config.xml',
    category: 'Manifest & Resources',
    language: 'xml',
    summary: 'Accessibility Service descriptor allowing user-approved UI navigation and window inspection.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeWindowStateChanged|typeWindowContentChanged|typeViewClicked"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:accessibilityFlags="flagReportViewIds|flagRetrieveInteractiveWindows|flagIncludeNotImportantViews"
    android:canPerformGestures="true"
    android:canRetrieveWindowContent="true"
    android:description="@string/accessibility_service_description"
    android:notificationTimeout="120" />
`,
  },
  {
    path: 'app/src/main/res/xml/backup_rules.xml',
    category: 'Manifest & Resources',
    language: 'xml',
    summary: 'Excludes encrypted keystore preferences from unencrypted cloud auto-backup.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<full-backup-content>
    <exclude domain="sharedpref" path="aanya_secure_vault.xml" />
</full-backup-content>
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/AanyaApplication.kt',
    category: 'Core UI & Orb',
    language: 'kotlin',
    summary: 'Application bootstrap initializing notification channels and crash-safe encrypted storage.',
    content: `package com.aanya.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class AanyaApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java) ?: return

            val voiceChannel = NotificationChannel(
                CHANNEL_VOICE,
                "Aanya Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Active while Aanya AI listens with microphone consent"
            }

            val visionChannel = NotificationChannel(
                CHANNEL_VISION,
                "Aanya Screen Vision",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Active during MediaProjection screen analysis sessions"
            }

            val sosChannel = NotificationChannel(
                CHANNEL_SOS,
                "Aanya SOS & Safety Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Urgent safety confirmations and call reminders"
            }

            manager.createNotificationChannels(listOf(voiceChannel, visionChannel, sosChannel))
        }
    }

    companion object {
        const val CHANNEL_VOICE = "aanya_voice_channel"
        const val CHANNEL_VISION = "aanya_vision_channel"
        const val CHANNEL_SOS = "aanya_sos_channel"
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/MainActivity.kt',
    category: 'Core UI & Orb',
    language: 'kotlin',
    summary: 'Jetpack Compose Dark Galaxy home activity with 8 Orb themes, Chat/Voice/Camera/Settings navigation, and Android 16 runtime permissions.',
    content: `package com.aanya.ai

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.aanya.ai.brain.MultiProviderAiRouter
import com.aanya.ai.brain.PersonaId
import com.aanya.ai.brain.PersonaManager
import com.aanya.ai.security.BiometricLockManager
import com.aanya.ai.security.EncryptedMemoryBackupManager
import kotlinx.coroutines.launch

enum class OrbTheme(val label: String, val core: Color, val ring: Color) {
    AANYA_GALAXY("Aanya Galaxy", Color(0xFF0284C7), Color(0xFF38BDF8)),
    MAYA_2047("Maya 2047", Color(0xFF06B6D4), Color(0xFF67E8F9)),
    NOVA("Nova", Color(0xFF2563EB), Color(0xFF93C5FD)),
    JARVIS("Jarvis", Color(0xFF0EA5E9), Color(0xFFF59E0B)),
    TRON("Tron", Color(0xFF00D4FF), Color(0xFF0284C7)),
    CYBER_AI("Cyber AI", Color(0xFF1D4ED8), Color(0xFF22D3EE)),
    FRIDAY("Friday", Color(0xFF334155), Color(0xFF93C5FD)),
    VENOM("Venom", Color(0xFF020617), Color(0xFF06B6D4))
}

class MainActivity : FragmentActivity() {

    private lateinit var vaultManager: EncryptedMemoryBackupManager
    private lateinit var aiRouter: MultiProviderAiRouter
    private lateinit var biometricLockManager: BiometricLockManager

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* Permission grant state reflected in Settings Dashboard */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        vaultManager = EncryptedMemoryBackupManager(this)
        aiRouter = MultiProviderAiRouter(vaultManager)
        biometricLockManager = BiometricLockManager(this)

        requestCorePermissions()

        setContent {
            AanyaGalaxyApp(
                aiRouter = aiRouter,
                onOpenAccessibility = {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                },
                onOpenOverlayPermission = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                        startActivity(intent)
                    }
                },
                onBiometricVerify = { onResult ->
                    biometricLockManager.authenticate(
                        title = "Unlock Aanya AI Vault",
                        subtitle = "Verify using Android Fingerprint or Face authentication",
                        onSuccess = { onResult(true) },
                        onFailure = { onResult(false) }
                    )
                }
            )
        }
    }

    private fun requestCorePermissions() {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(perms.toTypedArray())
    }
}

@Composable
fun AanyaGalaxyApp(
    aiRouter: MultiProviderAiRouter,
    onOpenAccessibility: () -> Unit,
    onOpenOverlayPermission: () -> Unit,
    onBiometricVerify: ((Boolean) -> Unit) -> Unit
) {
    var selectedTab by remember { mutableStateOf("Chat") }
    var activePersona by remember { mutableStateOf(PersonaId.AANYA) }
    var activeOrbTheme by remember { mutableStateOf(OrbTheme.AANYA_GALAXY) }
    var inputText by remember { mutableStateOf("") }
    var isThinking by remember { mutableStateOf(false) }
    val messages = remember {
        mutableStateListOf(
            "\${activePersona.displayName}: " + PersonaManager.getProfile(PersonaId.AANYA).greeting
        )
    }
    val scope = rememberCoroutineScope()

    val darkCanvas = Color(0xFF050814)
    val surfaceColor = Color(0xFF0C1326)

    Scaffold(
        containerColor = darkCanvas,
        bottomBar = {
            NavigationBar(containerColor = surfaceColor) {
                listOf("Chat", "Voice", "Camera", "Settings").forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        label = { Text(tab, color = if (selectedTab == tab) Color(0xFF38BDF8) else Color(0xFF94A3B8)) },
                        icon = {
                            Box(
                                Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (selectedTab == tab) Color(0xFF38BDF8) else Color(0xFF334155))
                            )
                        }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Aanya AI",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PersonaId.entries.forEach { persona ->
                        val active = persona == activePersona
                        Text(
                            text = persona.displayName,
                            color = if (active) Color(0xFF050814) else Color(0xFFCBD5E1),
                            fontSize = 12.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) Color(0xFF38BDF8) else surfaceColor)
                                .clickable { activePersona = persona }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Animated Floating AI Orb
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                contentAlignment = Alignment.Center
            ) {
                AanyaOrbCanvas(theme = activeOrbTheme, active = isThinking)
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(OrbTheme.entries) { theme ->
                    val selected = theme == activeOrbTheme
                    Text(
                        text = theme.label,
                        color = if (selected) Color(0xFF38BDF8) else Color(0xFF94A3B8),
                        fontSize = 12.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .border(
                                1.dp,
                                if (selected) theme.ring else Color(0xFF1E293B),
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { activeOrbTheme = theme }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            if (selectedTab == "Settings") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onOpenAccessibility) {
                        Text("Configure Accessibility Automation Consent")
                    }
                    Button(onClick = onOpenOverlayPermission) {
                        Text("Enable Floating AI Orb Overlay")
                    }
                    Button(onClick = { onBiometricVerify {} }) {
                        Text("Test Android BiometricPrompt Lock")
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages) { msg ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(surfaceColor)
                                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(14.dp))
                                .padding(12.dp)
                        ) {
                            Text(text = msg, color = Color(0xFFE2E8F0), fontSize = 14.sp)
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text("Bolo Boss, Aanya se Hinglish ya English mein poocho...", color = Color(0xFF64748B)) },
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        enabled = inputText.isNotBlank() && !isThinking,
                        onClick = {
                            val prompt = inputText.trim()
                            inputText = ""
                            messages.add("You: $prompt")
                            isThinking = true
                            scope.launch {
                                val reply = aiRouter.generateReply(prompt, activePersona)
                                messages.add("\${activePersona.displayName}: $reply")
                                isThinking = false
                            }
                        }
                    ) {
                        Text(if (isThinking) "..." else "Send")
                    }
                }
            }
        }
    }
}

@Composable
fun AanyaOrbCanvas(theme: OrbTheme, active: Boolean) {
    val infinite = rememberInfiniteTransition(label = "orb")
    val pulse by infinite.animateFloat(
        initialValue = 0.92f,
        targetValue = if (active) 1.12f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (active) 900 else 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Canvas(modifier = Modifier.size(116.dp)) {
        val radius = (size.minDimension / 2.6f) * pulse
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(theme.ring, theme.core, Color.Transparent)
            ),
            radius = radius * 1.45f
        )
        drawCircle(
            color = theme.core,
            radius = radius
        )
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/brain/PersonaManager.kt',
    category: 'AI Brain & Agents',
    language: 'kotlin',
    summary: 'Independent persona profiles for Aanya, Friday, and Venom addressing the user as Boss in Hinglish & English.',
    content: `package com.aanya.ai.brain

enum class PersonaId(val displayName: String) {
    AANYA("Aanya"),
    FRIDAY("Friday"),
    VENOM("Venom")
}

data class PersonaProfile(
    val id: PersonaId,
    val title: String,
    val ttsPitch: Float,
    val ttsSpeechRate: Float,
    val greeting: String,
    val systemPrompt: String
)

object PersonaManager {
    private val profiles = mapOf(
        PersonaId.AANYA to PersonaProfile(
            id = PersonaId.AANYA,
            title = "Friendly Female AI Assistant",
            ttsPitch = 1.08f,
            ttsSpeechRate = 1.0f,
            greeting = "Hey Boss! Main Aanya hoon, aapki personal AI assistant. Hinglish ya English mein bolo — aaj kya help karoon, Boss?",
            systemPrompt = "You are Aanya, a warm, smart multilingual assistant. Always address the user as Boss and respond in natural Hinglish and English. Always request explicit confirmation from Boss before any call, SMS, WhatsApp, or phone automation."
        ),
        PersonaId.FRIDAY to PersonaProfile(
            id = PersonaId.FRIDAY,
            title = "Professional Intelligent Assistant",
            ttsPitch = 0.98f,
            ttsSpeechRate = 1.05f,
            greeting = "Friday online, Boss. Ready to execute approved tasks with precision.",
            systemPrompt = "You are Friday, a sharp executive AI assistant. Always address the user as Boss and keep replies crisp in Hinglish and English. Enforce user consent for every sensitive Android operation."
        ),
        PersonaId.VENOM to PersonaProfile(
            id = PersonaId.VENOM,
            title = "Powerful Cosmic Male Personality",
            ttsPitch = 0.72f,
            ttsSpeechRate = 0.92f,
            greeting = "We are online, Boss. Speak your command.",
            systemPrompt = "You are Venom, a deep, commanding cosmic male AI personality fiercely loyal to Boss in Hinglish and English while strictly respecting Android security and consent."
        )
    )

    fun getProfile(id: PersonaId): PersonaProfile = profiles.getValue(id)
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/brain/MultiProviderAiRouter.kt',
    category: 'AI Brain & Agents',
    language: 'kotlin',
    summary: 'Multi-provider AI router supporting Google Gemini, Groq, OpenRouter, Claude, and OpenAI with automatic fallback and Keystore-backed keys.',
    content: `package com.aanya.ai.brain

import com.aanya.ai.security.EncryptedMemoryBackupManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class AiProvider { GEMINI, GROQ, OPENROUTER, ANTHROPIC, OPENAI }

class MultiProviderAiRouter(
    private val vault: EncryptedMemoryBackupManager
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val jsonType = "application/json; charset=utf-8".toMediaType()

    suspend fun generateReply(
        userMessage: String,
        persona: PersonaId,
        providerPriority: List<AiProvider> = listOf(
            AiProvider.GEMINI,
            AiProvider.GROQ,
            AiProvider.OPENROUTER,
            AiProvider.ANTHROPIC,
            AiProvider.OPENAI
        )
    ): String = withContext(Dispatchers.IO) {
        val profile = PersonaManager.getProfile(persona)
        var lastError = "No AI provider key configured in encrypted vault."

        for (provider in providerPriority) {
            val apiKey = vault.getProviderSecret(provider.name) ?: continue
            try {
                return@withContext when (provider) {
                    AiProvider.GEMINI -> callGemini(apiKey, profile.systemPrompt, userMessage)
                    AiProvider.GROQ -> callOpenAiCompatible(
                        "https://api.groq.com/openai/v1/chat/completions",
                        apiKey,
                        "llama-3.3-70b-versatile",
                        profile.systemPrompt,
                        userMessage
                    )
                    AiProvider.OPENROUTER -> callOpenAiCompatible(
                        "https://openrouter.ai/api/v1/chat/completions",
                        apiKey,
                        "google/gemini-2.5-flash",
                        profile.systemPrompt,
                        userMessage
                    )
                    AiProvider.OPENAI -> callOpenAiCompatible(
                        "https://api.openai.com/v1/chat/completions",
                        apiKey,
                        "gpt-4o-mini",
                        profile.systemPrompt,
                        userMessage
                    )
                    AiProvider.ANTHROPIC -> callAnthropic(apiKey, profile.systemPrompt, userMessage)
                }
            } catch (e: Exception) {
                lastError = "\${provider.name} fallback triggered: \${e.message}"
            }
        }
        "Unable to reach AI providers ($lastError). Configure a key inside your encrypted device vault."
    }

    private fun callGemini(apiKey: String, systemPrompt: String, userMessage: String): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", userMessage)))))
        }
        val req = Request.Builder().url(url).post(body.toString().toRequestBody(jsonType)).build()
        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) error("Gemini HTTP \${res.code}")
            val root = JSONObject(res.body?.string().orEmpty())
            return root.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        }
    }

    private fun callOpenAiCompatible(
        endpoint: String,
        apiKey: String,
        model: String,
        systemPrompt: String,
        userMessage: String
    ): String {
        val body = JSONObject().apply {
            put("model", model)
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", systemPrompt))
                put(JSONObject().put("role", "user").put("content", userMessage))
            })
        }
        val req = Request.Builder()
            .url(endpoint)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(body.toString().toRequestBody(jsonType))
            .build()
        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) error("HTTP \${res.code}")
            val root = JSONObject(res.body?.string().orEmpty())
            return root.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
        }
    }

    private fun callAnthropic(apiKey: String, systemPrompt: String, userMessage: String): String {
        val body = JSONObject().apply {
            put("model", "claude-3-5-sonnet-latest")
            put("max_tokens", 1024)
            put("system", systemPrompt)
            put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", userMessage)))
        }
        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody(jsonType))
            .build()
        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) error("Anthropic HTTP \${res.code}")
            val root = JSONObject(res.body?.string().orEmpty())
            return root.getJSONArray("content").getJSONObject(0).getString("text")
        }
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/agents/AgentCoordinator.kt',
    category: 'AI Brain & Agents',
    language: 'kotlin',
    summary: 'Coordinator for the 7 independent AI agents (Research, Phone Automation, Coding, Communication, Vision, Memory, Personal Assistant).',
    content: `package com.aanya.ai.agents

enum class AanyaAgentRole(val title: String, val requiresConsent: Boolean) {
    RESEARCH("Research Agent", false),
    PHONE_AUTOMATION("Phone Automation Agent", true),
    CODING("Coding Agent", false),
    COMMUNICATION("Communication Agent", true),
    VISION("Vision Agent", true),
    MEMORY("Memory Agent", false),
    PERSONAL_ASSISTANT("Personal Assistant Agent", true)
}

data class AgentTaskStep(
    val id: String,
    val role: AanyaAgentRole,
    val description: String,
    val approvedByUser: Boolean = false
)

class AgentCoordinator {
    fun routeIntent(command: String): AanyaAgentRole {
        val lower = command.lowercase()
        return when {
            lower.contains("whatsapp") || lower.contains("sms") || lower.contains("call") -> AanyaAgentRole.COMMUNICATION
            lower.contains("open ") || lower.contains("click") || lower.contains("scroll") || lower.contains("settings") -> AanyaAgentRole.PHONE_AUTOMATION
            lower.contains("code") || lower.contains("kotlin") || lower.contains("bug") -> AanyaAgentRole.CODING
            lower.contains("camera") || lower.contains("screen") || lower.contains("read text") -> AanyaAgentRole.VISION
            lower.contains("remember") || lower.contains("backup") -> AanyaAgentRole.MEMORY
            lower.contains("research") || lower.contains("compare") -> AanyaAgentRole.RESEARCH
            else -> AanyaAgentRole.PERSONAL_ASSISTANT
        }
    }

    fun canExecute(step: AgentTaskStep): Boolean {
        return !step.role.requiresConsent || step.approvedByUser
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/voice/AanyaVoiceForegroundService.kt',
    category: 'Voice & Vision',
    language: 'kotlin',
    summary: 'Android 14-16 compliant microphone Foreground Service with Hindi/English SpeechRecognizer, TTS, Echo Guard, and Hey Aanya wake-word detection.',
    content: `package com.aanya.ai.voice

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import com.aanya.ai.AanyaApplication
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class AanyaVoiceForegroundService : Service(), TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    // Echo Guard prevents Aanya from hearing and triggering on her own TTS output
    private val isSpeaking = AtomicBoolean(false)
    private var continuousMode = true
    private var wakeWordRequired = true

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        startListeningForeground()
    }

    private fun startListeningForeground() {
        val notification: Notification = NotificationCompat.Builder(this, AanyaApplication.CHANNEL_VOICE)
            .setContentTitle("Aanya AI Voice Active")
            .setContentText("Listening for \"Hey Aanya\" · Echo Guard enabled")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        initSpeechRecognizer()
    }

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    if (isSpeaking.get()) return
                    val spoken = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()

                    if (spoken.isNotEmpty()) {
                        val lower = spoken.lowercase(Locale.ROOT)
                        val wakeMatched = !wakeWordRequired ||
                            lower.contains("hey aanya") ||
                            lower.contains("हे आन्या")

                        if (wakeMatched) {
                            broadcastTranscript(spoken)
                        }
                    }
                    if (continuousMode && !isSpeaking.get()) {
                        restartRecognition()
                    }
                }

                override fun onError(error: Int) {
                    if (continuousMode && !isSpeaking.get()) {
                        restartRecognition()
                    }
                }

                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        restartRecognition()
    }

    private fun restartRecognition() {
        if (isSpeaking.get()) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_EXTRA_LANGUAGE_PREFERENCE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer?.startListening(intent)
    }

    fun speakWithEchoGuard(text: String, pitch: Float = 1.05f, rate: Float = 1.0f) {
        isSpeaking.set(true)
        speechRecognizer?.cancel() // Echo Guard immediately suspends mic recognition
        tts?.setPitch(pitch)
        tts?.setSpeechRate(rate)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aanya_utterance")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("hi", "IN")
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    isSpeaking.set(true)
                }
                override fun onDone(utteranceId: String?) {
                    isSpeaking.set(false)
                    if (continuousMode) restartRecognition()
                }
                @Deprecated("Deprecated in API")
                override fun onError(utteranceId: String?) {
                    isSpeaking.set(false)
                }
            })
        }
    }

    private fun broadcastTranscript(text: String) {
        sendBroadcast(Intent(ACTION_VOICE_TRANSCRIPT).putExtra(EXTRA_TRANSCRIPT, text))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val NOTIFICATION_ID = 1001
        const val ACTION_VOICE_TRANSCRIPT = "com.aanya.ai.VOICE_TRANSCRIPT"
        const val EXTRA_TRANSCRIPT = "transcript"
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/vision/ScreenVisionMediaProjectionService.kt',
    category: 'Voice & Vision',
    language: 'kotlin',
    summary: 'Consent-gated MediaProjection screen capture service with Android 14-16 foreground mediaProjection compliance.',
    content: `package com.aanya.ai.vision

import android.app.Activity
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.aanya.ai.AanyaApplication

class ScreenVisionMediaProjectionService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: return START_NOT_STICKY
        val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        } ?: return START_NOT_STICKY

        val notification = NotificationCompat.Builder(this, AanyaApplication.CHANNEL_VISION)
            .setContentTitle("Aanya Screen Vision")
            .setContentText("Analyzing visible screen with Privacy Shield")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = manager.getMediaProjection(resultCode, data)
        val metrics = resources.displayMetrics
        imageReader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, 0x1, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "AanyaScreenVision",
            metrics.widthPixels,
            metrics.heightPixels,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        )

        return START_NOT_STICKY
    }

    override fun onDestroy() {
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val NOTIFICATION_ID = 1002
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/automation/AanyaAccessibilityService.kt',
    category: 'Automation & Calls',
    language: 'kotlin',
    summary: 'Explicit-consent AccessibilityService supporting clicking buttons, scrolling, typing text, opening apps, and enforcing confirmation before sending messages.',
    content: `package com.aanya.ai.automation

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AanyaAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Strictly passive unless executing a user-approved automation step.
    }

    override fun onInterrupt() {}

    fun openInstalledApp(packageName: String): Boolean {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launchIntent)
        return true
    }

    fun clickNodeByText(targetText: String, userApproved: Boolean): Boolean {
        if (!userApproved) return false
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(targetText)
        for (node in matches) {
            var clickable: AccessibilityNodeInfo? = node
            while (clickable != null && !clickable.isClickable) {
                clickable = clickable.parent
            }
            if (clickable != null && clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
        }
        return false
    }

    fun typeIntoFocusedField(text: String, userApproved: Boolean): Boolean {
        if (!userApproved) return false
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scrollForward(userApproved: Boolean): Boolean {
        if (!userApproved) return false
        val root = rootInActiveWindow ?: return false
        return findScrollableNode(root)?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) == true
    }

    private fun findScrollableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val found = findScrollableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: AanyaAccessibilityService? = null
            private set
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/calls/SmartCallAndSosManager.kt',
    category: 'Automation & Calls',
    language: 'kotlin',
    summary: 'User-confirmed outgoing calls, SOS emergency SMS with explicit consent, and strict ban on secret call recording.',
    content: `package com.aanya.ai.calls

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

data class SosContact(val name: String, val phone: String)

class SmartCallAndSosManager(private val context: Context) {

    @Volatile
    private var sosCancelled = false

    fun placeConfirmedCall(phoneNumber: String, userConfirmed: Boolean): Boolean {
        if (!userConfirmed) return false
        val hasPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        val action = if (hasPerm) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val intent = Intent(action, Uri.parse("tel:$phoneNumber")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true
    }

    fun dispatchConfirmedSosSms(
        contacts: List<SosContact>,
        userConfirmed: Boolean,
        locationLink: String? = null
    ): Int {
        if (!userConfirmed || sosCancelled) return 0
        val hasSms = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasSms) return 0

        val smsManager = context.getSystemService(SmsManager::class.java) ?: return 0
        val body = buildString {
            append("SOS Alert from Aanya AI: I need urgent assistance.")
            if (!locationLink.isNullOrBlank()) {
                append(" Shared location: ").append(locationLink)
            }
        }

        var sent = 0
        for (contact in contacts) {
            if (sosCancelled) break
            smsManager.sendTextMessage(contact.phone, null, body, null, null)
            sent++
        }
        return sent
    }

    fun emergencyStop() {
        sosCancelled = true
    }

    fun resetSosFlag() {
        sosCancelled = false
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/security/BiometricLockManager.kt',
    category: 'Security & Backup',
    language: 'kotlin',
    summary: 'Android BiometricPrompt (Fingerprint, Face, Device PIN/Pattern) without ever bypassing Android security or storing credentials.',
    content: `package com.aanya.ai.security

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

class BiometricLockManager(private val activity: FragmentActivity) {

    fun canAuthenticate(): Boolean {
        val manager = BiometricManager.from(activity)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        return manager.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun authenticate(
        title: String,
        subtitle: String,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    onFailure(errString.toString())
                }
            }
        )

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        prompt.authenticate(promptInfo)
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/security/EncryptedMemoryBackupManager.kt',
    category: 'Security & Backup',
    language: 'kotlin',
    summary: 'Android Keystore AES-256-GCM EncryptedSharedPreferences for secrets, memories, and user-controlled encrypted backup export/restore.',
    content: `package com.aanya.ai.security

import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class EncryptedMemoryBackupManager(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "aanya_secure_vault",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveProviderSecret(provider: String, value: String) {
        prefs.edit().putString("secret_$provider", value).apply()
    }

    fun getProviderSecret(provider: String): String? {
        return prefs.getString("secret_$provider", null)
    }

    fun saveMemoryJson(json: String) {
        prefs.edit().putString("memory_store", json).apply()
    }

    fun loadMemoryJson(): String {
        return prefs.getString("memory_store", "[]") ?: "[]"
    }

    fun eraseAllUserData() {
        prefs.edit().clear().apply()
    }

    fun exportEncryptedBackup(passphrase: CharArray): String {
        val plain = loadMemoryJson().toByteArray(Charsets.UTF_8)
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val key = deriveAesKey(passphrase, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val encrypted = cipher.doFinal(plain)

        return listOf(
            Base64.encodeToString(salt, Base64.NO_WRAP),
            Base64.encodeToString(iv, Base64.NO_WRAP),
            Base64.encodeToString(encrypted, Base64.NO_WRAP)
        ).joinToString(".")
    }

    private fun deriveAesKey(passphrase: CharArray, salt: ByteArray): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(passphrase, salt, 150_000, 256)
        return SecretKeySpec(factory.generateSecret(spec).encoded, "AES")
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/skills/MarkdownSkillLoader.kt',
    category: 'AI Brain & Agents',
    language: 'kotlin',
    summary: 'Loads, parses, saves, and replays custom Markdown (.md) automation skills from app files directory.',
    content: `package com.aanya.ai.skills

import android.content.Context
import java.io.File

data class CustomMarkdownSkill(
    val id: String,
    val title: String,
    val trigger: String,
    val markdownBody: String
)

class MarkdownSkillLoader(private val context: Context) {

    private val skillsDir: File
        get() = File(context.filesDir, "skills").apply { mkdirs() }

    fun loadAllSkills(): List<CustomMarkdownSkill> {
        return skillsDir.listFiles { file -> file.extension.equals("md", ignoreCase = true) }
            ?.map { file ->
                val raw = file.readText()
                val title = raw.lineSequence()
                    .firstOrNull { it.startsWith("# ") }
                    ?.removePrefix("# ")
                    ?.trim()
                    ?: file.nameWithoutExtension
                val trigger = raw.lineSequence()
                    .firstOrNull { it.startsWith("Trigger:", ignoreCase = true) }
                    ?.substringAfter(":")
                    ?.trim()
                    ?: title.lowercase()
                CustomMarkdownSkill(file.nameWithoutExtension, title, trigger, raw)
            }
            .orEmpty()
    }

    fun saveSkill(id: String, markdown: String): File {
        val safeId = id.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        return File(skillsDir, "$safeId.md").apply { writeText(markdown) }
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/overlay/FloatingOrbOverlayService.kt',
    category: 'Core UI & Orb',
    language: 'kotlin',
    summary: 'Draggable SYSTEM_ALERT_WINDOW Floating AI Orb overlay respecting Android overlay permission.',
    content: `package com.aanya.ai.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class FloatingOrbOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var orbView: View? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            144,
            144,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 260
        }

        orbView = View(this).apply {
            setBackgroundColor(0xCC0EA5E9.toInt())
            contentDescription = "Aanya AI Floating Orb"
        }

        windowManager?.addView(orbView, params)
    }

    override fun onDestroy() {
        orbView?.let { windowManager?.removeView(it) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
`,
  },
  {
    path: 'app/src/main/java/com/aanya/ai/receiver/BootCompletedReceiver.kt',
    category: 'Security & Backup',
    language: 'kotlin',
    summary: 'Android 15/16 compliant BOOT_COMPLETED receiver notifying the user to resume Aanya AI without violating background microphone restrictions.',
    content: `package com.aanya.ai.receiver

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.aanya.ai.AanyaApplication
import com.aanya.ai.MainActivity

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        // Android 15 & 16 prohibit starting microphone foreground services directly from BOOT_COMPLETED.
        // Instead, we post a clean user-tappable notification to resume Aanya AI Voice cleanly.
        val openApp = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, AanyaApplication.CHANNEL_VOICE)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Aanya AI Ready")
            .setContentText("Tap to activate Aanya Voice & Floating Orb after reboot")
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .build()

        val manager = context.getSystemService(NotificationManager::class.java)
        manager?.notify(2001, notification)
    }
}
`,
  },
  {
    path: 'README.md',
    category: 'Gradle & Build',
    language: 'markdown',
    summary: 'Step-by-step Android Studio setup, Gradle Debug APK build instructions, and OPPO K12 5G / Android 16 compatibility guide.',
    content: `# Aanya AI — Maximum Edition (Android Native Kotlin)

- **Package Name:** \`com.aanya.ai\`
- **Minimum SDK:** API 26 (Android 8.0 Oreo)
- **Target / Compile SDK:** API 36 (Android 16)
- **Target Device Profile:** OPPO K12 5G (ColorOS) & Android 16

## Build Debug APK in Android Studio

1. Extract this ZIP and open the folder in **Android Studio Ladybug / Meerkat (2024.3+)** with **JDK 17**.
2. Let Gradle sync all Jetpack Compose, CameraX, Biometric, Security-Crypto, and OkHttp dependencies.
3. Run the debug build from Android Studio (**Build > Build APK(s)**) or terminal:
   \`\`\`bash
   ./gradlew assembleDebug
   \`\`\`
4. Find the compiled APK at:
   \`app/build/outputs/apk/debug/app-debug.apk\`

## OPPO K12 5G (ColorOS) Setup Checklist

- **Battery Optimization:** Settings > Battery > App Battery Management > Aanya AI > Allow Background Activity.
- **Auto-Launch:** Settings > Apps > Auto-Launch > Enable Aanya AI.
- **Accessibility Automation:** Settings > Accessibility > Downloaded Apps > Aanya AI (Explicit consent required).
- **Floating Orb Overlay:** Settings > Apps > Special App Access > Display over other apps > Aanya AI.
`,
  },
];
